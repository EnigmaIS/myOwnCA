"""
Default mappings for various key types and mechanisms.

None of this is provided for in PKCS#11 and its correctness should not be
assumed.
"""

from __future__ import annotations

from typing import Final

from pkcs11.constants import MechanismFlag
from pkcs11.mechanisms import MGF, KeyType, Mechanism

DEFAULT_GENERATE_MECHANISMS: Final[dict[KeyType, Mechanism]] = {
    KeyType.AES: Mechanism.AES_KEY_GEN,
    KeyType.DES2: Mechanism.DES2_KEY_GEN,
    KeyType.DES3: Mechanism.DES3_KEY_GEN,
    KeyType.DH: Mechanism.DH_PKCS_KEY_PAIR_GEN,
    KeyType.DSA: Mechanism.DSA_KEY_PAIR_GEN,
    KeyType.EC: Mechanism.EC_KEY_PAIR_GEN,
    KeyType.RSA: Mechanism.RSA_PKCS_KEY_PAIR_GEN,
    KeyType.X9_42_DH: Mechanism.X9_42_DH_KEY_PAIR_GEN,
    KeyType.EC_EDWARDS: Mechanism.EC_EDWARDS_KEY_PAIR_GEN,
    KeyType.ML_KEM: Mechanism.ML_KEM_KEY_PAIR_GEN,
    KeyType.ML_DSA: Mechanism.ML_DSA_KEY_PAIR_GEN,
    KeyType.GENERIC_SECRET: Mechanism.GENERIC_SECRET_KEY_GEN,
}
"""
Default mechanisms for generating keys.
"""

_ENCRYPTION: Final[MechanismFlag] = MechanismFlag.ENCRYPT | MechanismFlag.DECRYPT
_SIGNING: Final[MechanismFlag] = MechanismFlag.SIGN | MechanismFlag.VERIFY
_WRAPPING: Final[MechanismFlag] = MechanismFlag.WRAP | MechanismFlag.UNWRAP
_ENCAPSULATING: Final[MechanismFlag] = MechanismFlag.ENCAPSULATE | MechanismFlag.DECAPSULATE

DEFAULT_KEY_CAPABILITIES: Final[dict[KeyType, MechanismFlag | int]] = {
    KeyType.AES: _ENCRYPTION | _SIGNING | _WRAPPING,
    KeyType.DES2: _ENCRYPTION | _SIGNING | _WRAPPING,
    KeyType.DES3: _ENCRYPTION | _SIGNING | _WRAPPING,
    KeyType.DH: MechanismFlag.DERIVE,
    KeyType.DSA: _SIGNING,
    KeyType.EC: _SIGNING | MechanismFlag.DERIVE,
    KeyType.RSA: _ENCRYPTION | _SIGNING | _WRAPPING,
    KeyType.GENERIC_SECRET: 0,
    KeyType.EC_EDWARDS: _SIGNING,
    KeyType.ML_KEM: _ENCAPSULATING,
    KeyType.ML_DSA: _SIGNING,
}
"""
Default capabilities for generating keys.
"""

DEFAULT_ENCRYPT_MECHANISMS: Final[dict[KeyType, Mechanism]] = {
    KeyType.AES: Mechanism.AES_CBC_PAD,
    KeyType.DES2: Mechanism.DES3_CBC_PAD,
    KeyType.DES3: Mechanism.DES3_CBC_PAD,
    KeyType.RSA: Mechanism.RSA_PKCS_OAEP,
}
"""
Default mechanisms for encrypt/decrypt.
"""

DEFAULT_SIGN_MECHANISMS: Final[dict[KeyType, Mechanism]] = {
    KeyType.AES: Mechanism.AES_MAC,
    KeyType.DES2: Mechanism.DES3_MAC,
    KeyType.DES3: Mechanism.DES3_MAC,
    KeyType.DSA: Mechanism.DSA_SHA512,
    KeyType.EC: Mechanism.ECDSA_SHA512,
    KeyType.RSA: Mechanism.SHA512_RSA_PKCS,
    KeyType.EC_EDWARDS: Mechanism.EDDSA,
    KeyType.ML_DSA: Mechanism.ML_DSA,
}
"""
Default mechanisms for sign/verify.
"""

DEFAULT_WRAP_MECHANISMS: Final[dict[KeyType, Mechanism]] = {
    KeyType.AES: Mechanism.AES_KEY_WRAP,
    KeyType.DES2: Mechanism.DES3_ECB,
    KeyType.DES3: Mechanism.DES3_ECB,
    KeyType.RSA: Mechanism.RSA_PKCS_OAEP,
}
"""
Default mechanism for wrap/unwrap.
"""

DEFAULT_ENCAPSULATE_MECHANISMS: Final[dict[KeyType, Mechanism]] = {
    KeyType.ML_KEM: Mechanism.ML_KEM,
}
"""Default mechanisms for ML-KEM encapsulate/decapsulate."""

DEFAULT_DERIVE_MECHANISMS: Final[dict[KeyType, Mechanism]] = {
    KeyType.DH: Mechanism.DH_PKCS_DERIVE,
    KeyType.EC: Mechanism.ECDH1_DERIVE,
    KeyType.X9_42_DH: Mechanism.X9_42_DH_DERIVE,
}
"""
Default mechanisms for key derivation
"""

DEFAULT_PARAM_GENERATE_MECHANISMS: Final[dict[KeyType, Mechanism]] = {
    KeyType.DH: Mechanism.DH_PKCS_PARAMETER_GEN,
    KeyType.DSA: Mechanism.DSA_PARAMETER_GEN,
    KeyType.X9_42_DH: Mechanism.X9_42_DH_PARAMETER_GEN,
}
"""
Default mechanisms for domain parameter generation
"""


DEFAULT_MECHANISM_PARAMS: Final[
    dict[Mechanism, tuple[Mechanism, MGF, None] | tuple[Mechanism, MGF, int]]
] = {
    Mechanism.RSA_PKCS_OAEP: (Mechanism.SHA_1, MGF.SHA1, None),
    Mechanism.RSA_PKCS_PSS: (Mechanism.SHA_1, MGF.SHA1, 20),
}
"""
Default mechanism parameters
"""
