"""One login-bearing session, reused without retaining login credentials."""
from contextlib import contextmanager


class AuthenticatedSession:
    def __init__(self, backend):
        self._backend = backend
        self._session = None
        self._pkcs11 = None
        self._serial = None

    def unlock(self, pin):
        from .pkcs11 import _load_pkcs11_library, PKCS11Error, HSMLockedError
        self.lock()
        if not pin:
            raise HSMLockedError()
        pkcs11, library = _load_pkcs11_library(self._backend._lib_path)
        try:
            token, _ = self._backend._resolve_token(library, pkcs11)
            session = token.open(user_pin=pin, rw=True)
            self._session, self._pkcs11, self._serial = session, pkcs11, token.serial
        except pkcs11.exceptions.PKCS11Error as exc:
            raise PKCS11Error("PKCS#11 PIN verification failed: " + type(exc).__name__) from None
        finally:
            pin = None

    @property
    def unlocked(self):
        if self._session is None:
            return False
        try:
            authenticated = session_is_authenticated(self._backend._lib_path, self._session)
        except (OSError, AttributeError, TypeError, ValueError):
            authenticated = False
        if not authenticated:
            self.lock()
        return authenticated

    def lock(self):
        session, self._session = self._session, None
        self._pkcs11 = None
        self._serial = None
        if session is not None:
            try:
                session.close()
            except Exception:
                # The owning process is also closed on explicit lock or failure.
                pass

    @contextmanager
    def session(self):
        from .pkcs11 import HSMLockedError, PKCS11Error
        if not self.unlocked:
            raise HSMLockedError()
        pkcs11 = self._pkcs11
        try:
            yield self._session, pkcs11
        except pkcs11.exceptions.PKCS11Error as exc:
            code = type(exc).__name__
            if code in {"UserNotLoggedIn", "SessionHandleInvalid", "SessionClosed", "DeviceRemoved",
                        "DeviceError", "TokenNotPresent", "TokenNotRecognised", "PinExpired", "UserPinNotInitialized"}:
                self.lock()
                raise HSMLockedError("HSM authentication lost; manually unlock the HSM again") from None
            raise PKCS11Error("PKCS#11 operation failed: " + code) from None


def session_is_authenticated(lib_path, session):
    """Query Cryptoki state; python-pkcs11's user_type records the original login.

    C_GetFunctionList is mandatory, including for providers which do not export
    individual entry points. Only the standard prefix through GetSessionInfo is
    read. No credentials cross this boundary.
    """
    import ctypes
    import os

    class SessionInfo(ctypes.Structure):
        _fields_ = [(name, ctypes.c_ulong) for name in ("slot", "state", "flags", "error")]

    class FunctionList(ctypes.Structure):
        _pack_ = 1 if os.name == "nt" else 0
        _fields_ = [("version", ctypes.c_ubyte * 2), ("functions", ctypes.c_void_p * 16)]

    library = ctypes.CDLL(lib_path)
    functions = ctypes.POINTER(FunctionList)()
    getter = library.C_GetFunctionList
    getter.argtypes = [ctypes.POINTER(ctypes.POINTER(FunctionList))]
    getter.restype = ctypes.c_ulong
    if getter(ctypes.byref(functions)) != 0:
        return False
    convention = ctypes.WINFUNCTYPE if os.name == "nt" else ctypes.CFUNCTYPE
    get_info = convention(ctypes.c_ulong, ctypes.c_ulong, ctypes.POINTER(SessionInfo))(
        functions.contents.functions[15])
    info = SessionInfo()
    handle = session._identity()[2]
    return get_info(handle, ctypes.byref(info)) == 0 and info.state in (1, 3)
