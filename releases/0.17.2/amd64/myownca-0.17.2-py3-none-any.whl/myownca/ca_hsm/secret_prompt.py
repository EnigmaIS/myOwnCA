"""Feed OpenSC secret prompts through a private terminal, never argv or env."""
from __future__ import annotations

import os
import re
import subprocess
from time import monotonic

MAX_OUTPUT = 2 * 1024 * 1024


def run_with_prompts(command, *, values, env, timeout):
    if os.name != "posix":
        raise OSError("Secure OpenSC prompting requires a POSIX terminal")
    import pty
    import select
    import termios

    master, slave = pty.openpty()
    process = None
    try:
        attributes = termios.tcgetattr(slave)
        attributes[3] &= ~(termios.ECHO | termios.ECHONL)
        termios.tcsetattr(slave, termios.TCSANOW, attributes)
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=slave, stderr=slave, env=env)
        os.close(slave)
        slave = None
        output = bytearray()
        pending = ""
        answers = 0
        deadline = monotonic() + timeout
        while True:
            remaining = deadline - monotonic()
            if remaining <= 0:
                raise subprocess.TimeoutExpired(command, timeout)
            readable, _, _ = select.select([master], [], [], min(remaining, 0.1))
            if readable:
                try:
                    block = os.read(master, 4096)
                except OSError:
                    break
                if not block:
                    break
                output.extend(block)
                if len(output) > MAX_OUTPUT:
                    raise OSError("OpenSC response exceeds the size limit")
                pending += block.decode("utf-8", errors="replace")
                prompt = pending.rsplit("\n", 1)[-1]
                if re.search(r"(?:enter|confirm|repeat|retype).*[:?]\s*$", prompt, re.I):
                    lower = prompt.lower()
                    if "so-pin" in lower or "so pin" in lower:
                        value = values.get("so_pin")
                    elif "pin" in lower:
                        value = values.get("user_pin")
                    elif "password" in lower:
                        value = values.get("password")
                    else:
                        value = None
                    answers += 1
                    if value is None or answers > 4 or any(c in value for c in "\r\n\x00"):
                        raise OSError("Unsupported OpenSC authentication prompt")
                    process.stdin.write(value.encode("utf-8") + b"\n")
                    process.stdin.flush()
                    value = None
                    pending = ""
            elif process.poll() is not None:
                break
        result = output.decode("utf-8", errors="replace")
        for value in values.values():
            if value:
                result = result.replace(value, "***")
        return subprocess.CompletedProcess(command, process.wait(timeout=max(0.1, deadline-monotonic())),
                                           stdout=result, stderr="")
    finally:
        values.clear()
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        if process is not None:
            process.stdin.close()
        os.close(master)
        if slave is not None:
            os.close(slave)
