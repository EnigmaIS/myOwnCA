from __future__ import annotations

import base64
import sys
from typing import Any

from cryptography import x509
from cryptography.hazmat.primitives import serialization

from myownca.ca_hsm.base import KeyImportError
from myownca.ca_hsm.pkcs11 import (
    PKCS11Error,
    PKCS11PartialImportError,
    PKCS11Unavailable,
    _InProcessPKCS11HSM,
)
from myownca.ca_hsm.pkcs11_protocol import (
    MAX_MESSAGE_BYTES,
    PKCS11ProtocolError,
    WorkerRequest,
    error_response,
    success_response,
)


def _argument(arguments: dict[str, Any], name: str, expected_type):
    value = arguments.get(name)
    if not isinstance(value, expected_type):
        raise PKCS11ProtocolError(f"Worker argument '{name}' is invalid")
    return value


def _decode(arguments: dict[str, Any], name: str) -> bytes:
    value = _argument(arguments, name, str)
    try:
        return base64.b64decode(value, validate=True)
    except ValueError as exc:
        raise PKCS11ProtocolError(f"Worker argument '{name}' is not valid base64") from exc


def _encode(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def _require_pin(request: WorkerRequest) -> str:
    if not request.pin:
        raise PKCS11Error("HSM PIN is locked; unlock the PIN before this operation")
    return request.pin


def dispatch(request: WorkerRequest, backend=None) -> Any:
    if backend is None:
        # Compatibility for one-shot callers: authenticate explicitly, discard
        # the credential before dispatch, and close the session before return.
        from dataclasses import replace
        backend = _InProcessPKCS11HSM(request.lib_path, request.token_label, pin_provider=None)
        try:
            if request.operation not in {"status", "verify_pin"} and request.pin:
                backend.verify_pin(request.pin)
                if getattr(backend, "_session_manager", None) is not None:
                    request = replace(request, pin=None)
            return dispatch(request, backend)
        finally:
            manager = getattr(backend, "_session_manager", None)
            if manager is not None:
                manager.lock()
    manager = getattr(backend, "_session_manager", None)
    if manager is not None:
        if request.operation == "unlock":
            manager.unlock(_require_pin(request))
            return True
        if request.operation == "lock":
            manager.lock()
            return True
        if request.operation == "authentication_status":
            return manager.unlocked
        if request.pin is not None and request.operation != "verify_pin":
            raise PKCS11ProtocolError("PINs are accepted only for explicit authentication")
    arguments = request.arguments

    if request.operation == "status":
        return backend.status()
    if request.operation == "verify_pin":
        backend.verify_pin(_require_pin(request))
        return True
    if request.operation == "generate_key":
        return backend.generate_key(
            _argument(arguments, "label", str),
            _argument(arguments, "algorithm", str),
        )
    if request.operation == "import_key":
        if manager is None:
            _require_pin(request)
        private_key = serialization.load_der_private_key(
            _decode(arguments, "private_key_der"),
            password=None,
        )
        certificate_der = arguments.get("certificate_der")
        certificate = (
            x509.load_der_x509_certificate(_decode(arguments, "certificate_der"))
            if certificate_der is not None
            else None
        )
        return backend.import_key(
            _argument(arguments, "label", str),
            private_key,
            certificate,
        )
    if request.operation == "public_key":
        public_key = backend.public_key(_argument(arguments, "key_ref", str))
        return _encode(
            public_key.public_bytes(
                serialization.Encoding.DER,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            )
        )
    if request.operation == "sign_x509":
        return _encode(
            backend.sign_x509_payload(
                _decode(arguments, "payload"),
                _argument(arguments, "key_ref", str),
                _decode(arguments, "expected_public_key_der"),
            )
        )
    if request.operation == "sign_data":
        return _encode(
            backend.sign_data(
                _decode(arguments, "payload"),
                _argument(arguments, "key_ref", str),
            )
        )
    if request.operation == "list_keys":
        return backend.list_keys()
    if request.operation == "delete_key":
        return backend.delete_key(_argument(arguments, "label", str))
    if request.operation == "delete_key_reference":
        key_reference = arguments.get("key_reference")
        if not isinstance(key_reference, (int, str)) or isinstance(key_reference, bool):
            raise PKCS11ProtocolError("Worker argument 'key_reference' is invalid")
        return backend.delete_key_reference(key_reference)
    if request.operation == "self_test":
        return backend.self_test()
    raise PKCS11ProtocolError(f"Unknown PKCS#11 worker operation: {request.operation}")


def handle(payload: str, backend=None) -> str:
    try:
        request = WorkerRequest.from_json(payload)
        return success_response(dispatch(request, backend))
    except PKCS11PartialImportError as exc:
        return error_response(
            "partial_import",
            exc.__class__.__name__,
            message="PKCS#11 key import rollback was incomplete",
            details={
                "key_ref": exc.key_ref,
                "remaining_objects": list(exc.remaining_objects),
            },
        )
    except PKCS11Unavailable as exc:
        return error_response("unavailable", exc.__class__.__name__, message=str(exc))
    except KeyError as exc:
        return error_response("key_error", exc.__class__.__name__, message=str(exc))
    except KeyImportError as exc:
        return error_response("key_import_error", exc.__class__.__name__, message=str(exc))
    except PKCS11ProtocolError as exc:
        return error_response("protocol_error", exc.__class__.__name__, message=str(exc))
    except ValueError as exc:
        return error_response("value_error", exc.__class__.__name__, message=str(exc))
    except PKCS11Error as exc:
        return error_response("pkcs11_error", exc.__class__.__name__, message=str(exc))
    except Exception as exc:  # noqa: BLE001 - never emit provider or secret-bearing text
        return error_response("internal_error", exc.__class__.__name__)


def persistent_main() -> int:
    import os
    from .pkcs11_session import AuthenticatedSession

    # Do not leave an authenticated orphan after the application is killed.
    if sys.platform == "linux":
        import ctypes
        parent = int(sys.argv[2]) if len(sys.argv) > 2 else os.getppid()
        if ctypes.CDLL(None).prctl(1, 9, 0, 0, 0) != 0 or os.getppid() != parent:
            return 1
    backend = None
    try:
        while True:
            payload = sys.stdin.buffer.readline(MAX_MESSAGE_BYTES + 2)
            if not payload:
                return 0
            if len(payload) > MAX_MESSAGE_BYTES + 1 or not payload.endswith(b"\n"):
                return 1
            try:
                decoded = payload.decode("utf-8")
                request = WorkerRequest.from_json(decoded)
                if backend is None:
                    backend = _InProcessPKCS11HSM(request.lib_path, request.token_label, lambda: None)
                    backend._session_manager = AuthenticatedSession(backend)
                if (request.lib_path, request.token_label) != (backend._lib_path, backend._token_label):
                    return 1
                request = None
                had_session = backend._session_manager._session is not None
                response = handle(decoded, backend)
            except (UnicodeError, PKCS11ProtocolError):
                return 1
            finally:
                payload = decoded = request = None
            sys.stdout.write(response + "\n")
            sys.stdout.flush()
            if had_session and backend._session_manager._session is None:
                # Some wrappers cannot close an invalid session after logout
                # fails. Exiting releases all provider resources in that case.
                return 0
    finally:
        if backend is not None:
            backend._session_manager.lock()


def main() -> int:
    if sys.argv[1:2] == ["--persistent"]:
        return persistent_main()
    payload = sys.stdin.buffer.read(MAX_MESSAGE_BYTES + 1)
    if len(payload) > MAX_MESSAGE_BYTES:
        return 1
    try:
        response = handle(payload.decode("utf-8"))
    except UnicodeError:
        return 1
    sys.stdout.write(response)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
