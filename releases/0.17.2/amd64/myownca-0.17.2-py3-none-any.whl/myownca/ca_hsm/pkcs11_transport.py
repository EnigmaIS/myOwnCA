"""Serialized, bounded IPC to an application-owned PKCS#11 worker."""
from __future__ import annotations

import os
from pathlib import Path
import queue
import subprocess
import sys
import threading

from .pkcs11_protocol import MAX_MESSAGE_BYTES, WORKER_TIMEOUT_SECONDS


class WorkerTransport:
    def __init__(self):
        self._process = None
        self._responses = None
        self._lock = threading.RLock()
        self._owner_pid = os.getpid()

    def _start(self):
        environment = os.environ.copy()
        # The configuration contains no secrets. OpenSC must not cache login PINs.
        environment["OPENSC_CONF"] = str(Path(__file__).with_name("opensc-runtime.conf"))
        environment.pop("OPENSC_DEBUG", None)
        self._process = subprocess.Popen(
            [sys.executable, "-B", "-m", "myownca.ca_hsm.pkcs11_worker", "--persistent", str(os.getpid())],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            env=environment,
        )
        responses = self._responses = queue.Queue(maxsize=1)
        process = self._process

        def read_responses():
            try:
                while True:
                    line = process.stdout.readline(MAX_MESSAGE_BYTES + 2)
                    if not line or len(line) > MAX_MESSAGE_BYTES + 1 or not line.endswith(b"\n"):
                        responses.put(None, timeout=1)
                        return
                    responses.put(line, timeout=1)
            except (OSError, ValueError, queue.Full):
                try:
                    responses.put(None, timeout=1)
                except queue.Full:
                    pass

        threading.Thread(target=read_responses, daemon=True, name="pkcs11-responses").start()

    def exchange(self, payload):
        from .pkcs11 import HSMLockedError
        with self._lock:
            if self._owner_pid != os.getpid():
                raise HSMLockedError("HSM sessions cannot be inherited across application processes")
            if self._process is not None and self._process.poll() is not None:
                self._close()
                raise HSMLockedError("HSM worker stopped; manually unlock the HSM again")
            try:
                if self._process is None:
                    self._start()
                self._process.stdin.write(payload.encode("utf-8") + b"\n")
                self._process.stdin.flush()
                response = self._responses.get(timeout=WORKER_TIMEOUT_SECONDS)
                if response is None:
                    raise OSError("worker disconnected")
                return response.decode("utf-8")
            except (OSError, ValueError, UnicodeError, queue.Empty):
                self._close()
                raise HSMLockedError("HSM worker unavailable; manually unlock the HSM again") from None

    def _close(self):
        process, self._process = self._process, None
        self._responses = None
        if process is not None:
            try:
                process.stdin.close()
                process.wait(timeout=1)
            except (OSError, subprocess.TimeoutExpired):
                process.kill()
                process.wait()
            finally:
                process.stdout.close()

    def close(self):
        with self._lock:
            self._close()
