"""Compatibility surface for the retired PIN vault; credentials cannot be stored."""


class HSMPinVault:
    """Deprecated: authenticate with the PKCS#11 backend's explicit unlock method."""

    def unlock(self, session_key, pin, *, expires_at=None):
        raise RuntimeError("PIN storage is disabled; use backend.unlock(pin)")

    def lock(self, session_key):
        pass

    def clear(self):
        pass

    def is_unlocked(self, session_key):
        return False

    def pin_for(self, session_key):
        return None

    def active_pin(self):
        return None
