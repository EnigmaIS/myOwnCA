-- Enrollment bindings are immutable; administrative disabling preserves history.
CREATE TABLE acme_server_authorizations (
    id TEXT PRIMARY KEY,
    names_json TEXT NOT NULL,
    template_id TEXT NOT NULL REFERENCES certificate_templates(id),
    owner_id TEXT NOT NULL REFERENCES users(id),
    device_id TEXT NOT NULL REFERENCES devices(id),
    enabled INTEGER NOT NULL DEFAULT 1,
    generation INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE TABLE acme_server_accounts (
    id TEXT PRIMARY KEY,
    thumbprint TEXT NOT NULL UNIQUE,
    jwk_json TEXT NOT NULL,
    authorization_id TEXT NOT NULL UNIQUE REFERENCES acme_server_authorizations(id),
    contact_json TEXT NOT NULL,
    status TEXT NOT NULL,
    generation INTEGER NOT NULL DEFAULT 0,
    rate_window INTEGER NOT NULL DEFAULT 0,
    rate_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE TABLE acme_server_credentials (
    id TEXT PRIMARY KEY,
    authorization_id TEXT NOT NULL REFERENCES acme_server_authorizations(id),
    secret_ciphertext TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    account_id TEXT REFERENCES acme_server_accounts(id),
    created_at TEXT NOT NULL
);
CREATE TABLE acme_server_nonces (
    nonce TEXT PRIMARY KEY,
    expires_at TEXT NOT NULL
);
CREATE TABLE acme_server_requests (
    request_id TEXT PRIMARY KEY REFERENCES certificate_requests(id),
    account_id TEXT NOT NULL REFERENCES acme_server_accounts(id),
    csr_sha256 TEXT NOT NULL,
    identity_sha256 TEXT NOT NULL,
    generation INTEGER NOT NULL DEFAULT 0,
    claim_token TEXT,
    claim_until TEXT,
    origin TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX idx_acme_server_request_identity
    ON acme_server_requests(account_id, identity_sha256);
CREATE TABLE acme_server_orders (
    id TEXT PRIMARY KEY,
    account_id TEXT NOT NULL REFERENCES acme_server_accounts(id),
    identifiers_json TEXT NOT NULL,
    status TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    csr_sha256 TEXT,
    request_id TEXT REFERENCES acme_server_requests(request_id),
    certificate_chain TEXT,
    error_json TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX idx_acme_server_orders_account ON acme_server_orders(account_id, status);
CREATE INDEX idx_acme_server_orders_expiry ON acme_server_orders(status, expires_at);
CREATE INDEX idx_acme_server_orders_request ON acme_server_orders(request_id);
CREATE TABLE acme_server_challenges (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL REFERENCES acme_server_orders(id),
    name TEXT NOT NULL,
    token TEXT NOT NULL,
    status TEXT NOT NULL,
    validated_at TEXT,
    error_json TEXT,
    claim_token TEXT,
    claim_until TEXT
);
CREATE TABLE acme_server_validation_slots (
    id INTEGER PRIMARY KEY,
    claim_token TEXT,
    claim_until TEXT
);
INSERT INTO acme_server_validation_slots(id) VALUES (1), (2), (3), (4);
CREATE TABLE acme_server_lineages (
    account_id TEXT NOT NULL REFERENCES acme_server_accounts(id),
    identity_sha256 TEXT NOT NULL,
    certificate_id TEXT NOT NULL REFERENCES certificate_inventory(certificate_id),
    PRIMARY KEY (account_id, identity_sha256)
);
