-- Existing installations opt into unattended ACME issuance on upgrade.
INSERT INTO online_settings(key, value)
SELECT 'acme_server_auto_approve', 'true'
WHERE NOT EXISTS (SELECT 1 FROM online_settings WHERE key = 'acme_server_auto_approve');
