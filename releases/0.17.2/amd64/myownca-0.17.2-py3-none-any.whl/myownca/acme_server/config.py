"""Fail-closed configuration for the private ACME listener."""
from dataclasses import dataclass
from ipaddress import ip_network, ip_address
from urllib.parse import urlsplit


@dataclass(frozen=True)
class ACMEConfig:
    origin: str
    networks: tuple

    @classmethod
    def parse(cls, origin: str | None, cidrs: str | None):
        parsed = urlsplit(origin or "")
        if (
            parsed.scheme != "https" or not origin or origin != "https://" + parsed.netloc
            or not origin.isascii() or any(char.isspace() for char in origin)
            or parsed.netloc.endswith(":") or not parsed.hostname or parsed.username
            or parsed.password or parsed.path or parsed.query or parsed.fragment
            or parsed.netloc != parsed.netloc.lower() or origin.endswith("/")
        ):
            raise ValueError("ACME base URL must be an explicit canonical HTTPS origin without a path")
        try:
            ip_address(parsed.hostname)
        except ValueError:
            from .protocol import dns_name
            dns_name(parsed.hostname)
        try:
            parsed.port
            networks = tuple(ip_network(item.strip(), strict=True)
                             for item in (cidrs or "").split(",") if item.strip())
        except ValueError as exc:
            raise ValueError("Invalid ACME origin port or validation CIDR") from exc
        if not networks:
            raise ValueError("ACME validation destination CIDRs are required")
        return cls(origin, networks)
