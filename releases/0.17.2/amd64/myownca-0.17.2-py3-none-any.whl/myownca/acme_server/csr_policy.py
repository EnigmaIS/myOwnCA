"""Private ACME CSR policy, shared by finalization and bound issuance checks."""

from __future__ import annotations

import hashlib
import json

from cryptography import x509
from cryptography.exceptions import UnsupportedAlgorithm
from cryptography.hazmat.primitives import serialization
from cryptography.x509.oid import NameOID

from myownca.ca_main.crypto import validate_end_entity_csr
from myownca.ca_main.identity import certificate_identity_digest
from myownca.domain import (
    CertificateTemplate,
    CertificateProfile,
    KeyUsageName,
    ExtendedKeyUsageName,
)
from myownca.storage.repositories import RepositoryError
from .protocol import Problem, dns_name, unb64, b64


def accepted_csr(encoded, names, template):
    try:
        raw = unb64(encoded)
        csr = x509.load_der_x509_csr(raw)
        if not csr.is_signature_valid:
            raise ValueError("Invalid CSR signature")
        common_names = csr.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
        sans = csr.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        if any(not isinstance(name, x509.DNSName) for name in sans):
            raise ValueError("Only DNS SANs are supported")
        actual_names = [dns_name(name.value.lower()) for name in sans]
        if len(actual_names) != len(set(actual_names)) or set(actual_names) != set(names):
            raise ValueError("CSR DNS SANs must exactly match the order identifiers")
        if len(csr.subject) and (
            len(common_names) != 1 or common_names[0].value.lower() not in names
        ):
            raise ValueError("CSR must have one Common Name belonging to the order")
        validate_end_entity_csr(csr, template, allow_empty_subject=True)
        return csr, hashlib.sha256(raw).hexdigest()
    except (ValueError, TypeError, x509.ExtensionNotFound, UnsupportedAlgorithm) as exc:
        raise Problem("badCSR", str(exc)) from exc


def template_from_row(row):
    """Hydrate the locking read; never open a second snapshot for policy checks."""

    return CertificateTemplate(
        id=row["id"],
        name=row["name"],
        profile=CertificateProfile(row["profile"]),
        validity_days=row["validity_days"],
        first_issuance_approvals=row["first_issuance_approvals"],
        renewal_approvals=row["renewal_approvals"],
        key_usages=tuple(KeyUsageName(v) for v in json.loads(row["key_usages_json"])),
        extended_key_usages=tuple(
            ExtendedKeyUsageName(v) for v in json.loads(row["extended_key_usages_json"])
        ),
        key_usage_critical=bool(row["key_usage_critical"]),
        extended_key_usage_critical=bool(row["extended_key_usage_critical"]),
        allowed_key_algorithms=tuple(json.loads(row["allowed_key_algorithms_json"])),
    )


def signing_controls(template):
    return (
        template.id,
        template.profile,
        template.validity_days,
        template.key_usages,
        template.extended_key_usages,
        template.key_usage_critical,
        template.extended_key_usage_critical,
        template.allowed_key_algorithms,
    )


def validate_bound_csr(c, binding, request, authorization, template, at):
    """Require live validated orders and persisted identity/CSR/account bindings."""

    try:
        csr = x509.load_pem_x509_csr(request["csr_pem"].encode())
        encoded = b64(csr.public_bytes(serialization.Encoding.DER))
        sql = (
            "SELECT * FROM acme_server_orders WHERE request_id = ? "
            "AND status = 'processing' AND expires_at > ?"
        )
        if c._dialect in {"mysql", "mariadb"}:
            sql += " FOR UPDATE"
        orders = c.execute(sql, (request["id"], at)).fetchall()
        if not orders:
            raise ValueError("No live bound order")
        for order in orders:
            names = json.loads(order["identifiers_json"])
            _, fingerprint = accepted_csr(encoded, names, template)
            challenges = c.execute(
                "SELECT name, status FROM acme_server_challenges WHERE order_id = ?", (order["id"],)
            ).fetchall()
            if (
                order["account_id"] != binding["account_id"]
                or order["csr_sha256"] != fingerprint
                or binding["csr_sha256"] != fingerprint
                or binding["identity_sha256"] != certificate_identity_digest(csr)
                or not set(names) <= set(json.loads(authorization["names_json"]))
                or sorted(r["name"] for r in challenges) != sorted(names)
                or any(r["status"] != "valid" for r in challenges)
            ):
                raise ValueError("ACME CSR or authorization binding changed")
    except (ValueError, TypeError, Problem) as exc:
        raise RepositoryError("ACME bound CSR policy is no longer eligible for issuance") from exc


def assert_csr_binding(csr, binding):

    if (
        hashlib.sha256(csr.public_bytes(serialization.Encoding.DER)).hexdigest()
        != binding["csr_sha256"]
        or certificate_identity_digest(csr) != binding["identity_sha256"]
    ):
        raise RepositoryError("ACME signing CSR does not match its persisted binding")
