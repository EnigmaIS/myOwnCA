"""Strict flattened JWS, public keys, EAB, and ACME problem documents."""
from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import re
from ipaddress import ip_address

import josepy as jose
from acme.jws import JWS
from cryptography.hazmat.primitives.asymmetric import ec, rsa


class Problem(ValueError):
    def __init__(self, code: str, detail: str, status: int = 400):
        super().__init__(detail)
        self.code, self.detail, self.status = code, detail, status

    def document(self):
        return {"type": f"urn:ietf:params:acme:error:{self.code}",
                "detail": self.detail, "status": self.status}


def b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def unb64(value: str) -> bytes:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]*", value):
        raise Problem("malformed", "Invalid base64url encoding")
    try:
        decoded = base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except (ValueError, binascii.Error) as exc:
        raise Problem("malformed", "Invalid base64url encoding") from exc
    if b64(decoded) != value:
        raise Problem("malformed", "Noncanonical base64url encoding")
    return decoded


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise Problem("malformed", "Duplicate JSON member")
        result[key] = value
    return result


def json_object(data: bytes | str) -> dict:
    try:
        value = json.loads(data, object_pairs_hook=_unique,
                           parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (ValueError, UnicodeError, TypeError) as exc:
        raise Problem("malformed", "Expected a JSON object") from exc
    if not isinstance(value, dict):
        raise Problem("malformed", "Expected a JSON object")
    return value


def public_key(value: dict):
    if not isinstance(value, dict):
        raise Problem("badPublicKey", "Expected a public JWK")
    fields = {"RSA": {"kty", "n", "e"}, "EC": {"kty", "crv", "x", "y"}}
    if value.get("kty") not in fields or set(value) != fields[value["kty"]]:
        raise Problem("badPublicKey", "Unsupported or private account JWK")
    try:
        key = jose.JWK.from_json(value)
        raw = key.key._wrapped
        if isinstance(raw, rsa.RSAPublicKey):
            if raw.key_size < 2048 or raw.public_numbers().e < 65537:
                raise ValueError()
        elif isinstance(raw, ec.EllipticCurvePublicKey):
            if not isinstance(raw.curve, (ec.SECP256R1, ec.SECP384R1)):
                raise ValueError()
        else:
            raise ValueError()
        return key
    except Exception as exc:
        raise Problem("badPublicKey", "Unsupported or weak account key") from exc


def thumbprint(jwk: dict) -> str:
    return b64(public_key(jwk).thumbprint())


def envelope(data: bytes):
    value = json_object(data)
    if set(value) != {"protected", "payload", "signature"}:
        raise Problem("malformed", "A single flattened protected JWS is required")
    protected = json_object(unb64(value["protected"]))
    unb64(value["signature"])
    payload = unb64(value["payload"])
    return value, protected, payload


def verify_jws(value: dict, header: dict, key):
    raw = key.key._wrapped
    expected = "RS256" if isinstance(raw, rsa.RSAPublicKey) else {
        "secp256r1": "ES256", "secp384r1": "ES384"
    }.get(raw.curve.name)
    if header.get("alg") != expected:
        raise Problem("badSignatureAlgorithm", "Supported algorithms are RS256, ES256, ES384")
    try:
        signed = JWS.from_json(value)
        if not signed.verify(key):
            raise ValueError()
    except Exception as exc:
        raise Problem("malformed", "Invalid JWS signature") from exc


def verify_eab(value: dict, jwk: dict, secret: str, kid: str, url: str):
    try:
        body, header, payload = envelope(json.dumps(value).encode())
        if header != {"alg": "HS256", "kid": kid, "url": url}:
            raise ValueError()
        if json_object(payload) != jwk:
            raise ValueError()
        actual = unb64(body["signature"])
        expected = hmac.new(unb64(secret),
                            f'{body["protected"]}.{body["payload"]}'.encode(),
                            hashlib.sha256).digest()
        if not hmac.compare_digest(actual, expected):
            raise ValueError()
    except (ValueError, TypeError, KeyError) as exc:
        raise Problem("unauthorized", "Invalid external account binding", 403) from exc


def dns_name(value: str) -> str:
    if not isinstance(value, str) or value != value.lower() or len(value) > 253:
        raise Problem("rejectedIdentifier", "DNS identifiers must be lowercase ASCII names")
    if not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?", value):
        raise Problem("rejectedIdentifier", "Only explicit DNS identifiers are supported")
    if any(not label or len(label) > 63 or label.startswith("-") or label.endswith("-")
           for label in value.split(".")):
        raise Problem("rejectedIdentifier", "Invalid DNS identifier")
    try:
        ip_address(value)
    except ValueError:
        return value
    raise Problem("rejectedIdentifier", "IP identifiers are not supported")
