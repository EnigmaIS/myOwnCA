"""Bounded HTTP-01 validation with address pinning and no redirects or proxies."""
from __future__ import annotations

import asyncio
import json
from datetime import timedelta
from ipaddress import ip_address, ip_network

import dns.asyncresolver
import dns.exception
import dns.resolver

from .protocol import Problem
from .repository import identifier, now, stamp

_PRIVATE = tuple(map(ip_network, ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "fc00::/7")))


def approved_address(value, networks):
    address = ip_address(value)
    if (
        getattr(address, "ipv4_mapped", None) is not None
        or getattr(address, "sixtofour", None) is not None
        or getattr(address, "teredo", None) is not None
        or address.is_loopback or address.is_link_local or address.is_unspecified
        or address.is_multicast or address.is_reserved
        or str(address) == "168.63.129.16"
        or not (address.is_global or any(address in net for net in _PRIVATE))
        or not any(address in net for net in networks)
    ):
        raise Problem("connection", "DNS returned a prohibited validation destination")
    return str(address)


async def resolve(name):
    resolver = dns.asyncresolver.Resolver()
    async def query(kind):
        try:
            answer = await resolver.resolve(name + ".", kind, search=False, lifetime=4)
            return [record.address for record in answer]
        except dns.resolver.NoAnswer:
            return []
    results = await asyncio.gather(query("A"), query("AAAA"))
    return results[0] + results[1]


async def response_body(reader):
    line = await reader.readline()
    parts = line.split()
    if len(parts) < 2 or parts[0] not in {b"HTTP/1.0", b"HTTP/1.1"} or parts[1] != b"200":
        raise Problem("unauthorized", "HTTP-01 requires a direct HTTP 200 response")
    headers, size = {}, len(line)
    while True:
        line = await reader.readline()
        size += len(line)
        if size > 8192 or not line:
            raise Problem("unauthorized", "Invalid HTTP-01 response headers")
        if line == b"\r\n":
            break
        key, sep, value = line.partition(b":")
        key = key.strip().lower()
        if not sep or key in headers:
            raise Problem("unauthorized", "Invalid HTTP-01 response headers")
        headers[key] = value.strip().lower()
    if b"transfer-encoding" in headers:
        if headers[b"transfer-encoding"] != b"chunked" or b"content-length" in headers:
            raise Problem("unauthorized", "Invalid HTTP-01 response framing")
        body = bytearray()
        while True:
            line = await reader.readline()
            if len(line) > 100:
                raise Problem("unauthorized", "Invalid HTTP-01 chunk")
            count = int(line.split(b";", 1)[0].strip(), 16)
            if count < 0 or len(body) + count > 1024:
                raise Problem("unauthorized", "HTTP-01 body exceeds 1 KiB")
            if count == 0:
                return bytes(body)
            body.extend(await reader.readexactly(count))
            if await reader.readexactly(2) != b"\r\n":
                raise Problem("unauthorized", "Invalid HTTP-01 chunk")
    if b"content-length" in headers:
        count = int(headers[b"content-length"])
        if count < 0 or count > 1024:
            raise Problem("unauthorized", "HTTP-01 body exceeds 1 KiB")
        return await reader.readexactly(count)
    body = await reader.read(1025)
    # read() may return early; continue until EOF, enforcing the bound.
    while len(body) <= 1024:
        more = await reader.read(1025 - len(body))
        if not more:
            return body
        body += more
    raise Problem("unauthorized", "HTTP-01 body exceeds 1 KiB")


async def validate(name, token, key_authorization, networks, resolver=resolve):
    try:
        async with asyncio.timeout(5):
            addresses = await resolver(name)
            if not addresses:
                raise Problem("dns", "No validation destination found")
            checked = [approved_address(address, networks) for address in addresses]
            # Pin the connection to a checked address; the original DNS name is only an HTTP Host.
            reader, writer = await asyncio.open_connection(checked[0], 80, limit=8193)
            try:
                writer.write((f"GET /.well-known/acme-challenge/{token} HTTP/1.1\r\n"
                              f"Host: {name}\r\nConnection: close\r\n\r\n").encode("ascii"))
                await writer.drain()
                body = await response_body(reader)
                if body.rstrip(b" \t\r\n") != key_authorization.encode("ascii"):
                    raise Problem("unauthorized", "HTTP-01 key authorization does not match")
            finally:
                writer.close()
    except Problem:
        raise
    except TimeoutError as exc:
        raise Problem("connection", "HTTP-01 validation exceeded five seconds") from exc
    except (OSError, ValueError, asyncio.IncompleteReadError, dns.exception.DNSException) as exc:
        raise Problem("connection", "HTTP-01 validation failed") from exc


class ChallengeWorker:
    def __init__(self, repository, networks, validator=validate):
        self.repository, self.networks, self.validator = repository, networks, validator

    def acknowledge(self, account_id, challenge_id):
        with self.repository.database.connect() as c:
            self.repository.lock_account(c, account_id)
            challenge = c.execute("SELECT h.*, o.status AS order_status, o.expires_at "
                                  "FROM acme_server_challenges h JOIN acme_server_orders o "
                                  "ON o.id = h.order_id WHERE h.id = ? AND o.account_id = ?",
                                  (challenge_id, account_id)).fetchone()
            if not challenge:
                raise Problem("unauthorized", "Unknown challenge", 403)
            if challenge["expires_at"] <= stamp() or challenge["order_status"] == "invalid":
                raise Problem("unauthorized", "Order is no longer live", 403)
            if challenge["status"] != "pending":
                return
            window = int(now().timestamp()) // 60
            account = c.execute("SELECT * FROM acme_server_accounts WHERE id = ?",
                                (account_id,)).fetchone()
            count = account["rate_count"] if account["rate_window"] == window else 0
            if count >= 60:
                raise Problem("rateLimited", "At most 60 validations per account per minute", 429)
            c.execute("UPDATE acme_server_accounts SET rate_window = ?, rate_count = ? WHERE id = ?",
                      (window, count + 1, account_id))
            c.execute("UPDATE acme_server_challenges SET status = 'processing' WHERE id = ?",
                      (challenge_id,))
        self.repository.event("acme_challenge_acknowledged", challenge_id)

    async def run(self):
        self.repository.expire()
        with self.repository.database.connect() as c:
            work = c.execute("SELECT h.*, a.thumbprint, a.id AS account_id FROM acme_server_challenges h "
                             "JOIN acme_server_orders o ON o.id = h.order_id "
                             "JOIN acme_server_accounts a ON a.id = o.account_id "
                             "WHERE h.status = 'processing' AND o.status = 'pending' "
                             "AND (h.claim_token IS NULL OR h.claim_until <= ?) LIMIT 4",
                             (stamp(),)).fetchall()
        await asyncio.gather(*(self._one(challenge) for challenge in work))

    async def _one(self, challenge):
        token, slot = identifier(), None
        until = stamp(now() + timedelta(seconds=10))
        with self.repository.database.connect() as c:
            for index in range(1, 5):
                changed = c.execute("UPDATE acme_server_validation_slots SET claim_token = ?, "
                                    "claim_until = ? WHERE id = ? "
                                    "AND (claim_token IS NULL OR claim_until <= ?)",
                                    (token, until, index, stamp())).rowcount
                if changed:
                    slot = index
                    break
            if slot is None:
                return
            changed = c.execute("UPDATE acme_server_challenges SET claim_token = ?, claim_until = ? "
                                "WHERE id = ? AND status = 'processing' "
                                "AND (claim_token IS NULL OR claim_until <= ?)",
                                (token, until, challenge["id"], stamp())).rowcount
            if not changed:
                c.execute("UPDATE acme_server_validation_slots SET claim_token = NULL WHERE id = ? "
                          "AND claim_token = ?", (slot, token))
                return
        error = None
        try:
            self.repository.active_account(challenge["account_id"])
            await self.validator(challenge["name"], challenge["token"],
                                 challenge["token"] + "." + challenge["thumbprint"], self.networks)
        except Problem as exc:
            error = exc.document()
        except Exception:
            error = Problem("serverInternal", "Challenge validation failed", 500).document()
        finally:
            with self.repository.database.connect() as c:
                changed = c.execute("UPDATE acme_server_challenges SET status = ?, validated_at = ?, "
                                    "error_json = ?, claim_token = NULL WHERE id = ? "
                                    "AND status = 'processing' AND claim_token = ? AND claim_until > ?",
                                    ("invalid" if error else "valid", None if error else stamp(),
                                     json.dumps(error) if error else None,
                                     challenge["id"], token, stamp())).rowcount
                if changed:
                    remaining = c.execute("SELECT status FROM acme_server_challenges WHERE order_id = ?",
                                          (challenge["order_id"],)).fetchall()
                    states = {item["status"] for item in remaining}
                    if "invalid" in states or states == {"valid"}:
                        c.execute("UPDATE acme_server_orders SET status = ?, error_json = ? "
                                  "WHERE id = ? AND status = 'pending' AND expires_at > ?",
                                  ("invalid" if "invalid" in states else "ready",
                                   json.dumps(error) if error else None, challenge["order_id"], stamp()))
                c.execute("UPDATE acme_server_validation_slots SET claim_token = NULL, claim_until = NULL "
                          "WHERE id = ? AND claim_token = ?", (slot, token))

        if changed:
            self.repository.event("acme_challenge_failed" if error else "acme_challenge_validated", challenge["id"])
