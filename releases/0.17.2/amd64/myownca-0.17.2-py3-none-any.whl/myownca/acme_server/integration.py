"""CSR acceptance and atomic association with the existing approval workflow."""
from __future__ import annotations

import json

from cryptography import x509
from cryptography.hazmat.primitives import serialization

from myownca.ca_main.identity import certificate_identity_digest, assert_same_certificate_identity
from myownca.domain import CertificateStatus
from .protocol import Problem
from .csr_policy import accepted_csr
from .repository import identifier, stamp


class CAIntegration:
    def __init__(self, repository, ca_repository, origin):
        self.repository, self.ca = repository, ca_repository
        self.origin = origin

    def finalize(self, account_id, order_id, encoded):
        self.repository.expire(account_id)
        order = self.repository.get("orders", order_id, account_id)
        _, authorization = self.repository.active_account(account_id)
        template = self.ca.get_template(authorization["template_id"])
        csr, fingerprint = accepted_csr(encoded, json.loads(order["identifiers_json"]), template)
        identity = certificate_identity_digest(csr)
        pem = csr.public_bytes(serialization.Encoding.PEM).decode()
        with self.repository.database.connect() as c:
            _, auth = self.repository.lock_account(c, account_id)
            order = c.execute("SELECT * FROM acme_server_orders WHERE id = ?", (order_id,)).fetchone()
            if order["csr_sha256"]:
                if order["csr_sha256"] != fingerprint:
                    raise Problem("badCSR", "A finalized order cannot change its CSR")
                if order["status"] not in {"processing", "valid"}:
                    raise Problem("orderNotReady", "Order is no longer live", 403)
                return order
            if order["status"] != "ready" or order["expires_at"] <= stamp():
                raise Problem("orderNotReady", "All authorizations must be valid before finalization", 403)
            failed = c.execute("SELECT id FROM acme_server_challenges "
                               "WHERE order_id = ? AND status <> 'valid'", (order_id,)).fetchone()
            if failed:
                raise Problem("orderNotReady", "All authorizations must be valid before finalization", 403)
            # Serialization on the account covers retry orders and CSR replacement.
            requests = c.execute(
                "SELECT a.*, r.status AS request_status FROM acme_server_requests a "
                "JOIN certificate_requests r ON r.id = a.request_id "
                "WHERE a.account_id = ? AND a.identity_sha256 = ?",
                (account_id, identity)).fetchall()
            live = [r for r in requests if r["request_status"] == "pending"]
            match = next((r for r in live if r["csr_sha256"] == fingerprint), None)
            if match:
                request_id = match["request_id"]
            else:
                for old in live:
                    if old["claim_token"] and old["claim_until"] > stamp():
                        raise Problem("orderNotReady", "Previous signing operation must reconcile first", 403)
                for old in live:
                    c.execute("UPDATE acme_server_requests SET generation = generation + 1, "
                              "claim_token = NULL WHERE request_id = ?", (old["request_id"],))
                    c.execute("UPDATE certificate_requests SET status = 'rejected' "
                              "WHERE id = ? AND status = 'pending'", (old["request_id"],))
                    c.execute("UPDATE acme_server_orders SET status = 'invalid', error_json = ? "
                              "WHERE request_id = ? AND status = 'processing'",
                              (json.dumps(Problem("unauthorized", "CSR superseded").document()),
                               old["request_id"]))
                anchor = c.execute("SELECT i.* FROM acme_server_lineages l "
                                   "JOIN certificate_inventory i ON i.certificate_id = l.certificate_id "
                                   "WHERE l.account_id = ? AND l.identity_sha256 = ?",
                                   (account_id, identity)).fetchone()
                kind, lineage_id, renewal_serial, renewal_id = "first_issuance", None, None, None
                if anchor:
                    if anchor["status"] != CertificateStatus.ACTIVE.value:
                        raise Problem("unauthorized", "The renewal anchor has been revoked", 403)
                    assert_same_certificate_identity(
                        x509.load_pem_x509_certificate(anchor["certificate_pem"].encode()), csr)
                    if (anchor["template_id"], anchor["holder_device_id"], anchor["holder_person_id"]) != (
                        auth["template_id"], auth["device_id"], None
                    ):
                        raise Problem("unauthorized", "The renewal binding has changed", 403)
                    original = c.execute("SELECT requested_by_user_id FROM certificate_requests "
                                         "WHERE id = ?", (anchor["request_id"],)).fetchone()
                    if original["requested_by_user_id"] != auth["owner_id"]:
                        raise Problem("unauthorized", "The renewal owner has changed", 403)
                    kind, lineage_id = "renewal", anchor["lineage_id"]
                    renewal_serial, renewal_id = anchor["serial_number"], anchor["certificate_id"]
                request_id = identifier()
                c.execute("INSERT INTO certificate_requests "
                          "(id, template_id, csr_pem, kind, status, created_at, requested_by_user_id, "
                          "holder_device_id, lineage_id, renewal_of_serial_number, source) "
                          "VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, 'request')",
                          (request_id, auth["template_id"], pem, kind, stamp(), auth["owner_id"],
                           auth["device_id"], lineage_id, renewal_serial))
                if renewal_id:
                    c.execute("INSERT INTO certificate_request_renewal_refs(request_id, certificate_id) "
                              "VALUES (?, ?)", (request_id, renewal_id))
                c.execute("INSERT INTO acme_server_requests "
                          "(request_id, account_id, csr_sha256, identity_sha256, origin, created_at) "
                          "VALUES (?, ?, ?, ?, ?, ?)",
                          (request_id, account_id, fingerprint, identity, self.origin, stamp()))
            c.execute("UPDATE acme_server_orders SET request_id = ?, csr_sha256 = ?, "
                      "status = 'processing' WHERE id = ?", (request_id, fingerprint, order_id))
        self.repository.event("acme_order_finalized", order_id)
        return self.repository.get("orders", order_id, account_id)

    def reconcile(self, issue):
        self.repository.expire()
        with self.repository.database.connect() as c:
            pending = c.execute("SELECT DISTINCT request_id FROM acme_server_orders "
                                "WHERE status = 'processing' AND request_id IS NOT NULL").fetchall()
        for entry in pending:
            request_id = entry["request_id"]
            certificate = self.ca.get_issued_certificate_by_request_id(request_id)
            if certificate:
                # Normal issuance updates orders atomically; this also recovers older committed work.
                with self.repository.database.connect() as c:
                    c.execute("UPDATE acme_server_orders SET status = 'valid', certificate_chain = ? "
                              "WHERE request_id = ? AND status = 'processing' AND expires_at > ?",
                              (certificate.certificate_pem + (certificate.chain_pem or ""),
                               request_id, stamp()))
                continue
            request = self.ca.get_request(request_id)
            if request.status.value == "rejected":
                with self.repository.database.connect() as c:
                    c.execute("UPDATE acme_server_orders SET status = 'invalid', error_json = ? "
                              "WHERE request_id = ? AND status = 'processing'",
                              (json.dumps(Problem("unauthorized", "Certificate request rejected")
                                          .document()), request_id))
                continue
            try:
                self.repository.active_account(self._request_account(request_id))
                template = self.ca.get_template(request.template_id)
                from .policy import effective_approvals
                needed = effective_approvals(self.ca, request, template)
                if len(self.ca.list_approvals(request_id)) >= needed:
                    issue(request_id)
            except Exception:
                # Existing issuance records signing/licensing failures; durable work remains retryable.
                continue

    def _request_account(self, request_id):
        with self.repository.database.connect() as c:
            return c.execute("SELECT account_id FROM acme_server_requests WHERE request_id = ?",
                             (request_id,)).fetchone()["account_id"]
