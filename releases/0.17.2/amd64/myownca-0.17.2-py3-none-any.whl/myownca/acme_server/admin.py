"""Administrator-only enrollment management with existing session and CSRF controls."""
import json

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field

from myownca.domain import CertificateProfile, Role
from myownca.storage.repositories import RepositoryError
from .protocol import Problem, dns_name
from .repository import identifier, stamp


class ACMEPolicyUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    auto_approve: bool


class EnrollmentCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    names: list[str] = Field(min_length=1, max_length=100)
    template_id: str
    owner_id: str
    device_id: str


def admin_router(repository, ca_repository, active_user, record):
    router = APIRouter(prefix="/internal/acme-server")

    @router.get("/policy")
    def policy(request: Request):
        active_user(request, Role.ADMIN)
        from .policy import SETTING
        return {"auto_approve": ca_repository.get_setting(SETTING) == "true"}

    @router.put("/policy")
    def update_policy(payload: ACMEPolicyUpdate, request: Request):
        active_user(request, Role.ADMIN, csrf=True)
        from .policy import SETTING
        ca_repository.set_setting(SETTING, "true" if payload.auto_approve else "false")
        record(request, "acme_automatic_approval_" + ("enabled" if payload.auto_approve else "disabled"),
               "setting", SETTING)
        return {"auto_approve": payload.auto_approve}

    @router.get("/authorizations")
    def authorizations(request: Request):
        active_user(request, Role.ADMIN)
        with repository.database.connect() as c:
            rows = c.execute("SELECT * FROM acme_server_authorizations ORDER BY created_at, id").fetchall()
        return [{**row, "names": json.loads(row["names_json"])} for row in rows]

    @router.post("/authorizations", status_code=201)
    def create(payload: EnrollmentCreate, request: Request):
        active_user(request, Role.ADMIN, csrf=True)
        try:
            names = sorted({dns_name(name) for name in payload.names})
            template = ca_repository.get_template(payload.template_id)
            if template.profile is not CertificateProfile.HOST_TLS or template.first_issuance_approvals < 1:
                raise ValueError("ACME requires a host/server template with at least one first-issuance approval")
            if not ca_repository.get_user(payload.owner_id).is_active:
                raise ValueError("An active request owner is required")
            ca_repository.get_device(payload.device_id)
        except (Problem, ValueError, RepositoryError) as exc:
            raise HTTPException(400, str(exc)) from exc
        auth_id = identifier()
        with repository.database.connect() as c:
            c.execute("INSERT INTO acme_server_authorizations "
                      "(id, names_json, template_id, owner_id, device_id, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                      (auth_id, json.dumps(names), template.id, payload.owner_id, payload.device_id, stamp()))
        record(request, "acme_authorization_created", "acme_authorization", auth_id)
        return {"id": auth_id, **payload.model_dump(), "names": names, "enabled": True}

    @router.get("/accounts")
    def accounts(request: Request):
        active_user(request, Role.ADMIN)
        with repository.database.connect() as c:
            return c.execute("SELECT id, thumbprint, authorization_id, contact_json, status, created_at "
                             "FROM acme_server_accounts ORDER BY created_at, id").fetchall()

    @router.get("/credentials")
    def credentials(request: Request):
        active_user(request, Role.ADMIN)
        with repository.database.connect() as c:
            return c.execute("SELECT id, authorization_id, enabled, account_id, created_at "
                             "FROM acme_server_credentials ORDER BY created_at, id").fetchall()

    @router.post("/authorizations/{authorization_id}/credentials", status_code=201)
    def credential(authorization_id: str, request: Request):
        active_user(request, Role.ADMIN, csrf=True)
        try:
            result = repository.create_credential(authorization_id)
        except Problem as exc:
            raise HTTPException(exc.status, exc.detail) from exc
        record(request, "acme_credential_created", "acme_credential", result["id"])
        # This response is the only place the plaintext secret is exposed.
        from fastapi.responses import JSONResponse
        return JSONResponse(result, status_code=201, headers={"Cache-Control": "no-store"})

    @router.post("/{kind}/{resource_id}/disable")
    def disable(kind: str, resource_id: str, request: Request):
        active_user(request, Role.ADMIN, csrf=True)
        if kind not in {"authorizations", "accounts", "credentials"}:
            raise HTTPException(404, "Unknown ACME enrollment resource")
        assignment = "status = 'revoked', generation = generation + 1" if kind == "accounts" else "enabled = 0"
        with repository.database.connect() as c:
            result = c.execute(f"UPDATE acme_server_{kind} SET {assignment} WHERE id = ?", (resource_id,))
            if result.rowcount != 1:
                raise HTTPException(404, "Unknown ACME enrollment resource")
        record(request, "acme_enrollment_disabled", "acme_" + kind, resource_id)
        return {"id": resource_id, "disabled": True}

    return router
