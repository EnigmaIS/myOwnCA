"""Approval policy for persisted private ACME enrollments only."""
from myownca.ca_main.policy import required_approvals

SETTING = "acme_server_auto_approve"


def automatic_approval(connection):
    # Lock the setting along with enrollment controls at certificate commit.
    from .repository import current_row
    row = current_row(connection, "SELECT value FROM online_settings WHERE key = ?", (SETTING,))
    return row is not None and row["value"] == "true"


def effective_approvals(repository, request, template):
    from .repository import request_binding
    with repository.database.connect() as connection:
        if request_binding(connection, request.id) and automatic_approval(connection):
            return 0
    return required_approvals(request, template)
