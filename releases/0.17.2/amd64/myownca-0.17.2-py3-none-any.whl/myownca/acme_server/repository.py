"""Durable enrollment and protocol state, with conditional writes for work ownership."""
from __future__ import annotations

import json
import logging
import secrets
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timedelta, timezone
from uuid import uuid4

from cryptography.fernet import Fernet

from myownca.secret_keys import derive_fernet_key
from myownca.storage.repositories import RepositoryError
from .protocol import Problem, b64

# Propagated only within one signing operation, never accepted from an HTTP client.
logger = logging.getLogger(__name__)

_signing_claim = ContextVar("acme_server_signing_claim", default=None)
_signing_template = ContextVar("acme_server_signing_template", default=None)


def bind_signing_template(template):
    from .csr_policy import signing_controls

    _signing_template.set(signing_controls(template))


def now():
    return datetime.now(timezone.utc)


def stamp(moment=None):
    return (moment or now()).isoformat()


def identifier():
    return str(uuid4())


def current_row(connection, sql, params):
    """Read mutable controls under a current row lock, including on InnoDB RR."""
    if connection._dialect in {"mysql", "mariadb"}:
        sql += " FOR UPDATE"
    return connection.execute(sql, params).fetchone()


class ACMERepository:
    def __init__(self, database, operator_secret: str):
        self.database = database
        self.event_listener = None
        self.cipher = Fernet(derive_fernet_key(operator_secret, "acme-server-eab-v1"))

    def event(self, action, object_id):
        logger.info("%s object_id=%s", action, object_id)
        if self.event_listener:
            try:
                self.event_listener(action, object_id)
            except Exception:
                logger.warning("ACME audit listener failed for %s object_id=%s", action, object_id)

    def nonce(self):
        value = secrets.token_urlsafe(32)
        with self.database.connect() as c:
            c.execute("DELETE FROM acme_server_nonces WHERE expires_at <= ?", (stamp(),))
            c.execute("INSERT INTO acme_server_nonces(nonce, expires_at) VALUES (?, ?)",
                      (value, stamp(now() + timedelta(minutes=5))))
        return value

    def consume_nonce(self, value):
        if not isinstance(value, str):
            raise Problem("badNonce", "Missing or invalid nonce")
        with self.database.connect() as c:
            changed = c.execute("DELETE FROM acme_server_nonces WHERE nonce = ? AND expires_at > ?",
                                (value, stamp())).rowcount
        if changed != 1:
            raise Problem("badNonce", "Nonce is expired, unknown, or already consumed")

    def account(self, account_id):
        with self.database.connect() as c:
            row = c.execute("SELECT * FROM acme_server_accounts WHERE id = ?",
                            (account_id,)).fetchone()
        if not row:
            raise Problem("accountDoesNotExist", "Unknown account")
        return row

    def active_account(self, account_id, c=None):
        if c is None:
            with self.database.connect() as connection:
                return self.active_account(account_id, connection)
        account = c.execute("SELECT * FROM acme_server_accounts WHERE id = ?",
                            (account_id,)).fetchone()
        auth = c.execute("SELECT * FROM acme_server_authorizations WHERE id = ?",
                         (account["authorization_id"],)).fetchone() if account else None
        if not account or account["status"] != "valid" or not auth or not auth["enabled"]:
            raise Problem("unauthorized", "Account or enrollment authorization is disabled", 403)
        template = current_row(c, "SELECT * FROM certificate_templates WHERE id = ?",
                               (auth["template_id"],))
        owner = current_row(c, "SELECT is_active FROM users WHERE id = ?", (auth["owner_id"],))
        if not owner or not owner["is_active"] or template["first_issuance_approvals"] < 1 or template["profile"] != "host_tls":
            raise Problem("unauthorized", "Enrollment owner or template is no longer eligible", 403)
        return account, auth

    def lock_account(self, c, account_id):
        c.execute("UPDATE acme_server_accounts SET generation = generation + 1 WHERE id = ?",
                  (account_id,))
        account, auth = self.active_account(account_id, c)
        c.execute("UPDATE acme_server_authorizations SET generation = generation + 1 WHERE id = ?",
                  (auth["id"],))
        return self.active_account(account_id, c)

    def get(self, table, resource_id, account_id):
        if table not in {"orders", "challenges"}:
            raise ValueError("Invalid resource table")
        with self.database.connect() as c:
            if table == "orders":
                row = c.execute("SELECT * FROM acme_server_orders WHERE id = ? AND account_id = ?",
                                (resource_id, account_id)).fetchone()
            else:
                row = c.execute("SELECT h.* FROM acme_server_challenges h "
                                "JOIN acme_server_orders o ON o.id = h.order_id "
                                "WHERE h.id = ? AND o.account_id = ?",
                                (resource_id, account_id)).fetchone()
        if not row:
            raise Problem("unauthorized", "Resource does not belong to this account", 403)
        return row

    def challenges(self, order_id):
        with self.database.connect() as c:
            return c.execute("SELECT * FROM acme_server_challenges WHERE order_id = ? ORDER BY id",
                             (order_id,)).fetchall()

    def create_order(self, account_id, names):
        order_id = identifier()
        with self.database.connect() as c:
            _, auth = self.lock_account(c, account_id)
            if not set(names) <= set(json.loads(auth["names_json"])):
                raise Problem("rejectedIdentifier", "Identifiers are outside enrollment authorization")
            c.execute("INSERT INTO acme_server_orders "
                      "(id, account_id, identifiers_json, status, expires_at, created_at) "
                      "VALUES (?, ?, ?, 'pending', ?, ?)",
                      (order_id, account_id, json.dumps(names),
                       stamp(now() + timedelta(days=7)), stamp()))
            for name in names:
                c.execute("INSERT INTO acme_server_challenges "
                          "(id, order_id, name, token, status) VALUES (?, ?, ?, ?, 'pending')",
                          (identifier(), order_id, name, secrets.token_urlsafe(32)))
        self.event("acme_order_created", order_id)
        return self.get("orders", order_id, account_id)

    def create_credential(self, authorization_id):
        kid, secret = identifier(), b64(secrets.token_bytes(32))
        with self.database.connect() as c:
            auth = c.execute("SELECT * FROM acme_server_authorizations WHERE id = ?",
                             (authorization_id,)).fetchone()
            if not auth or not auth["enabled"]:
                raise Problem("unauthorized", "Unknown or disabled enrollment authorization", 403)
            c.execute("INSERT INTO acme_server_credentials "
                      "(id, authorization_id, secret_ciphertext, created_at) VALUES (?, ?, ?, ?)",
                      (kid, authorization_id, self.cipher.encrypt(secret.encode()).decode(), stamp()))
        return {"id": kid, "hmac_key": secret}

    def expire(self, account_id=None):
        # Use the same account-first lock order as finalization and signing.
        # Whole-table UPDATEs here can deadlock with concurrent InnoDB finalizers.
        with self.database.connect() as c:
            accounts = c.execute(
                "SELECT DISTINCT account_id AS id FROM acme_server_orders "
                "WHERE expires_at <= ? AND status IN ('pending', 'ready', 'processing') "
                "UNION SELECT a.account_id AS id FROM acme_server_requests a "
                "JOIN certificate_requests r ON r.id = a.request_id WHERE r.status = 'pending' "
                "AND NOT EXISTS (SELECT 1 FROM acme_server_orders o WHERE o.request_id = a.request_id "
                "AND o.status = 'processing' AND o.expires_at > ?)", (stamp(), stamp()),
            ).fetchall()
        for account in accounts:
            if account_id is not None and account["id"] != account_id:
                continue
            expired_ids = []
            with self.database.connect() as c:
                account_id = account["id"]
                c.execute("UPDATE acme_server_accounts SET generation = generation + 1 WHERE id = ?",
                          (account_id,))
                expired_ids = [row["id"] for row in c.execute(
                    "SELECT id FROM acme_server_orders WHERE account_id = ? AND expires_at <= ? "
                    "AND status IN ('pending', 'ready', 'processing')", (account_id, stamp()),
                ).fetchall()]
                for order_id in expired_ids:
                    c.execute("UPDATE acme_server_orders SET status = 'invalid', error_json = ? WHERE id = ?",
                              (json.dumps(Problem("unauthorized", "Order expired").document()), order_id))
                    c.execute("UPDATE acme_server_challenges SET status = 'invalid', claim_token = NULL "
                              "WHERE order_id = ? AND status IN ('pending', 'processing')", (order_id,))
                requests = c.execute("SELECT request_id FROM acme_server_requests WHERE account_id = ?",
                                     (account_id,)).fetchall()
                for request in requests:
                    live = c.execute("SELECT id FROM acme_server_orders WHERE request_id = ? "
                                     "AND status = 'processing' AND expires_at > ?",
                                     (request["request_id"], stamp())).fetchone()
                    if not live:
                        c.execute("UPDATE certificate_requests SET status = 'rejected' "
                                  "WHERE id = ? AND status = 'pending'", (request["request_id"],))
            for order_id in expired_ids:
                self.event("acme_order_expired", order_id)

    def metadata(self, request_id):
        with self.database.connect() as c:
            row = c.execute("SELECT account_id, origin FROM acme_server_requests WHERE request_id = ?",
                            (request_id,)).fetchone()
            if not row:
                return None
            row["order_ids"] = [r["id"] for r in c.execute(
                "SELECT id FROM acme_server_orders WHERE request_id = ? ORDER BY created_at",
                (request_id,)).fetchall()]
            return row


def request_binding(c, request_id):
    return c.execute("SELECT * FROM acme_server_requests WHERE request_id = ?",
                     (request_id,)).fetchone()


def guard_request(c, request_id, *, require_claim=False):
    """Lock and recheck enrollment inside the certificate persistence transaction."""
    binding = request_binding(c, request_id)
    if not binding:
        return None
    account_id = binding["account_id"]
    c.execute("UPDATE acme_server_accounts SET generation = generation + 1 WHERE id = ?",
              (account_id,))
    account = c.execute("SELECT * FROM acme_server_accounts WHERE id = ?", (account_id,)).fetchone()
    c.execute("UPDATE acme_server_authorizations SET generation = generation + 1 WHERE id = ?",
              (account["authorization_id"],))
    auth = c.execute("SELECT * FROM acme_server_authorizations WHERE id = ?",
                     (account["authorization_id"],)).fetchone()
    c.execute("UPDATE acme_server_requests SET generation = generation + 1 WHERE request_id = ?",
              (request_id,))
    binding = request_binding(c, request_id)
    request = current_row(c, "SELECT * FROM certificate_requests WHERE id = ?", (request_id,))
    template = current_row(c, "SELECT * FROM certificate_templates WHERE id = ?",
                           (auth["template_id"],))
    owner = current_row(c, "SELECT is_active FROM users WHERE id = ?", (auth["owner_id"],))
    live = c.execute("SELECT id FROM acme_server_orders WHERE request_id = ? "
                     "AND status = 'processing' AND expires_at > ?", (request_id, stamp())).fetchone()
    if (
        account["status"] != "valid" or not auth["enabled"] or not owner["is_active"]
        or template["first_issuance_approvals"] < 1 or template["profile"] != "host_tls" or not live
        or request["status"] != "pending" or request["template_id"] != auth["template_id"]
        or request["requested_by_user_id"] != auth["owner_id"]
        or request["holder_device_id"] != auth["device_id"] or request["holder_person_id"]
    ):
        raise RepositoryError("ACME enrollment or request is no longer eligible for issuance")
    if require_claim and (
        _signing_claim.get() != (request_id, binding["claim_token"], binding["generation"] - 1)
        or not binding["claim_token"] or binding["claim_until"] <= stamp()
    ):
        raise RepositoryError("ACME signing claim was lost or expired")
    from .csr_policy import template_from_row, validate_bound_csr, signing_controls

    current_template = template_from_row(template)
    validate_bound_csr(c, binding, request, auth, current_template, stamp())
    if require_claim:
        if _signing_template.get() != signing_controls(current_template):
            raise RepositoryError("ACME signing template controls changed before commit")
        sql = "SELECT superuser_id FROM approvals WHERE request_id = ?"
        if c._dialect in {"mysql", "mariadb"}:
            sql += " FOR UPDATE"
        approvals = c.execute(sql, (request_id,)).fetchall()
        needed = (current_template.renewal_approvals if request["kind"] == "renewal"
                  else current_template.first_issuance_approvals)
        from .policy import automatic_approval
        if not automatic_approval(c) and len({row["superuser_id"] for row in approvals}) < needed:
            raise RepositoryError("ACME approvals are insufficient at commit")
    return binding


@contextmanager
def signing_claim(database, request_id):
    token = identifier()
    with database.connect() as c:
        binding = request_binding(c, request_id)
        if binding:
            binding = guard_request(c, request_id)
            changed = c.execute(
                "UPDATE acme_server_requests SET claim_token = ?, claim_until = ?, generation = generation + 1 "
                "WHERE request_id = ? AND (claim_token IS NULL OR claim_until <= ?)",
                (token, stamp(now() + timedelta(minutes=5)), request_id, stamp())).rowcount
            if changed != 1:
                raise RepositoryError("ACME signing is already in progress")
    context = _signing_claim.set((request_id, token, binding["generation"] + 1 if binding else None))
    template_context = _signing_template.set(None)
    try:
        yield binding
    finally:
        _signing_template.reset(template_context)
        _signing_claim.reset(context)
        if binding:
            with database.connect() as c:
                c.execute("UPDATE acme_server_requests SET claim_token = NULL, claim_until = NULL "
                          "WHERE request_id = ? AND claim_token = ?", (request_id, token))


def persist_lineage(c, certificate, binding):
    if not binding:
        return
    existing = c.execute("SELECT certificate_id FROM acme_server_lineages "
                         "WHERE account_id = ? AND identity_sha256 = ?",
                         (binding["account_id"], binding["identity_sha256"])).fetchone()
    if existing:
        c.execute("UPDATE acme_server_lineages SET certificate_id = ? "
                  "WHERE account_id = ? AND identity_sha256 = ?",
                  (certificate.certificate_id, binding["account_id"], binding["identity_sha256"]))
    else:
        c.execute("INSERT INTO acme_server_lineages(account_id, identity_sha256, certificate_id) "
                  "VALUES (?, ?, ?)",
                  (binding["account_id"], binding["identity_sha256"], certificate.certificate_id))
    c.execute("UPDATE acme_server_orders SET status = 'valid', certificate_chain = ? "
              "WHERE request_id = ? AND status = 'processing' AND expires_at > ?",
              (certificate.certificate_pem + (certificate.chain_pem or ""),
               certificate.request_id, stamp()))
