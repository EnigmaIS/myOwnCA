"""ACME HTTP resources; resource URLs always use the configured HTTPS origin."""
from __future__ import annotations

import json

from fastapi import APIRouter, Request, Response
from fastapi.responses import JSONResponse

from myownca.storage.database import IntegrityError
from .protocol import (Problem, envelope, json_object, public_key, thumbprint,
                       verify_eab, verify_jws, dns_name)
from .repository import identifier, stamp


class ACMEServer:
    def __init__(self, config, repository, integration, challenges):
        self.config, self.repository = config, repository
        self.integration, self.challenges = integration, challenges
        self.router = APIRouter()
        self.router.add_api_route("/acme", self.handle, methods=["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
        self.router.add_api_route("/acme/{path:path}", self.handle, methods=["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])

    def url(self, path):
        return self.config.origin + "/acme/" + path

    def account_body(self, account):
        return {"status": account["status"], "contact": json.loads(account["contact_json"]),
                "orders": self.url(f'account/{account["id"]}/orders')}

    def challenge_body(self, challenge):
        body = {"type": "http-01", "url": self.url("challenge/" + challenge["id"]),
                "status": challenge["status"], "token": challenge["token"]}
        if challenge["validated_at"]:
            body["validated"] = challenge["validated_at"]
        if challenge["error_json"]:
            body["error"] = json.loads(challenge["error_json"])
        return body

    def order_body(self, order):
        body = {"status": order["status"], "expires": order["expires_at"],
                "identifiers": [{"type": "dns", "value": name}
                                for name in json.loads(order["identifiers_json"])],
                "authorizations": [self.url("authz/" + challenge["id"])
                                   for challenge in self.repository.challenges(order["id"])],
                "finalize": self.url("finalize/" + order["id"])}
        if order["status"] == "valid":
            body["certificate"] = self.url("certificate/" + order["id"])
        if order["error_json"]:
            body["error"] = json.loads(order["error_json"])
        return body

    async def handle(self, request: Request):
        try:
            result = await self.dispatch(request)
        except Problem as exc:
            result = JSONResponse(exc.document(), status_code=exc.status,
                                  media_type="application/problem+json")
            if exc.code == "badSignatureAlgorithm":
                result.body = json.dumps({**exc.document(), "algorithms": ["RS256", "ES256", "ES384"]}) \
                    .encode()
                result.headers["content-length"] = str(len(result.body))
            if exc.code == "rateLimited":
                result.headers["Retry-After"] = "60"
        except Exception:
            result = JSONResponse(Problem("serverInternal", "ACME operation failed", 500).document(),
                                  status_code=500, media_type="application/problem+json")
        result.headers["Replay-Nonce"] = self.repository.nonce()
        result.headers["Cache-Control"] = "no-store"
        result.headers["Link"] = (result.headers.get("Link", "") + ", " if "Link" in result.headers else "") + f'<{self.url("directory")}>;rel="index"'
        return result

    async def authenticate(self, request):
        if request.headers.get("content-type", "").split(";", 1)[0] != "application/jose+json":
            raise Problem("malformed", "Content-Type must be application/jose+json", 415)
        raw = bytearray()
        async for chunk in request.stream():
            raw.extend(chunk)
            if len(raw) > 65536:
                raise Problem("malformed", "JWS body exceeds 64 KiB", 413)
        value, header, payload = envelope(bytes(raw))
        jwk = "jwk" in header
        expected = {"alg", "nonce", "url", "jwk" if jwk else "kid"}
        if set(header) != expected:
            raise Problem("malformed", "All JWS headers must be protected; use exactly one of jwk or kid")
        path = request.scope["raw_path"].decode("ascii")
        query = request.scope.get("query_string", b"").decode("ascii")
        if header.get("url") != self.config.origin + path + ("?" + query if query else ""):
            raise Problem("unauthorized", "JWS URL does not match the canonical request URL", 403)
        # One conditional DELETE makes replay protection independent of server process count.
        self.repository.consume_nonce(header.get("nonce"))
        if jwk:
            if path != "/acme/new-account":
                raise Problem("malformed", "This resource requires an account kid")
            key, account = public_key(header["jwk"]), None
        else:
            prefix = self.url("account/")
            kid = header.get("kid")
            if not isinstance(kid, str) or not kid.startswith(prefix) or "/" in kid[len(prefix):]:
                raise Problem("accountDoesNotExist", "Invalid account URL")
            account = self.repository.account(kid[len(prefix):])
            key = public_key(json.loads(account["jwk_json"]))
        verify_jws(value, header, key)
        if account:
            self.repository.active_account(account["id"])
        return account, header, payload

    async def dispatch(self, request):
        path = request.url.path
        if path == "/acme/directory" and request.method == "GET":
            return JSONResponse({"newNonce": self.url("new-nonce"),
                                 "newAccount": self.url("new-account"),
                                 "newOrder": self.url("new-order"),
                                 "meta": {"externalAccountRequired": True}})
        if path == "/acme/new-nonce" and request.method in {"GET", "HEAD"}:
            return Response(status_code=200 if request.method == "HEAD" else 204)
        if request.method != "POST":
            raise Problem("malformed", "Use a signed POST-as-GET for this resource", 405)
        account, header, payload = await self.authenticate(request)
        if path == "/acme/new-account":
            if account:
                raise Problem("malformed", "New-account requires a jwk")
            return self.register(header["jwk"], json_object(payload))
        if not account:
            raise Problem("accountDoesNotExist", "An account is required")
        account_id = account["id"]
        self.repository.expire(account_id)
        if path == "/acme/new-order":
            body = json_object(payload)
            if body.get("notBefore") is not None or body.get("notAfter") is not None:
                raise Problem("malformed", "Requested validity dates are unsupported")
            values = body.get("identifiers")
            if not isinstance(values, list) or not 1 <= len(values) <= 100:
                raise Problem("malformed", "An order requires between one and 100 DNS identifiers")
            names = []
            for item in values:
                if not isinstance(item, dict) or set(item) != {"type", "value"} or item["type"] != "dns":
                    raise Problem("unsupportedIdentifier", "Only explicit DNS identifiers are supported")
                names.append(dns_name(item["value"]))
            if len(names) != len(set(names)):
                raise Problem("malformed", "Duplicate order identifier")
            order = self.repository.create_order(account_id, sorted(names))
            return JSONResponse(self.order_body(order), status_code=201,
                                headers={"Location": self.url("order/" + order["id"]), "Retry-After": "10"})
        parts = path.removeprefix("/acme/").split("/")
        if len(parts) < 2:
            raise Problem("malformed", "Unknown ACME resource", 404)
        kind, resource_id = parts[:2]
        if kind == "account":
            if resource_id != account_id:
                raise Problem("unauthorized", "Resource belongs to another account", 403)
            if len(parts) == 3 and parts[2] == "orders":
                self.post_as_get(payload)
                with self.repository.database.connect() as c:
                    orders = c.execute("SELECT id FROM acme_server_orders WHERE account_id = ? "
                                       "AND status IN ('pending', 'ready', 'processing') "
                                       "ORDER BY created_at, id", (account_id,)).fetchall()
                return JSONResponse({"orders": [self.url("order/" + o["id"]) for o in orders]})
            if len(parts) != 2:
                raise Problem("malformed", "Unknown account resource", 404)
            if payload:
                body = json_object(payload)
                if set(body) - {"status", "contact"}:
                    raise Problem("malformed", "Unsupported account update")
                if "status" in body and body["status"] != "deactivated":
                    raise Problem("malformed", "Only account deactivation is supported")
                contact = contacts(body.get("contact", json.loads(account["contact_json"])))
                with self.repository.database.connect() as c:
                    self.repository.lock_account(c, account_id)
                    c.execute("UPDATE acme_server_accounts SET contact_json = ?, status = ? WHERE id = ?",
                              (json.dumps(contact), body.get("status", "valid"), account_id))
                account = self.repository.account(account_id)
            return JSONResponse(self.account_body(account), headers={"Location": self.url("account/" + account_id)})
        if len(parts) != 2:
            raise Problem("malformed", "Unknown ACME resource", 404)
        if kind in {"order", "certificate", "finalize"}:
            order = self.repository.get("orders", resource_id, account_id)
            if kind == "finalize":
                body = json_object(payload)
                if set(body) != {"csr"} or not isinstance(body["csr"], str):
                    raise Problem("malformed", "Finalization requires a DER CSR")
                order = self.integration.finalize(account_id, resource_id, body["csr"])
            else:
                self.post_as_get(payload)
            if kind == "certificate":
                if order["status"] != "valid" or not order["certificate_chain"]:
                    raise Problem("orderNotReady", "Certificate is not yet available", 403)
                return Response(order["certificate_chain"], media_type="application/pem-certificate-chain")
            headers = {"Location": self.url("order/" + order["id"])}
            if order["status"] in {"pending", "ready", "processing"}:
                headers["Retry-After"] = "10"
            return JSONResponse(self.order_body(order), headers=headers)
        if kind in {"authz", "challenge"}:
            challenge = self.repository.get("challenges", resource_id, account_id)
            order = self.repository.get("orders", challenge["order_id"], account_id)
            if kind == "challenge" and payload:
                if json_object(payload) != {}:
                    raise Problem("malformed", "Challenge acknowledgment must be an empty object")
                self.challenges.acknowledge(account_id, resource_id)
                challenge = self.repository.get("challenges", resource_id, account_id)
            elif kind == "authz" and payload:
                if json_object(payload) != {"status": "deactivated"}:
                    raise Problem("malformed", "Unsupported authorization update")
                with self.repository.database.connect() as c:
                    self.repository.lock_account(c, account_id)
                    c.execute("UPDATE acme_server_challenges SET status = 'deactivated', claim_token = NULL "
                              "WHERE id = ?", (resource_id,))
                    c.execute("UPDATE acme_server_orders SET status = 'invalid' WHERE id = ? "
                              "AND status <> 'valid'", (order["id"],))
                challenge = self.repository.get("challenges", resource_id, account_id)
            else:
                self.post_as_get(payload)
            if kind == "challenge":
                return JSONResponse(self.challenge_body(challenge),
                                    headers={"Link": f'<{self.url("authz/" + resource_id)}>;rel="up"'})
            status = challenge["status"]
            if order["expires_at"] <= stamp() and status != "deactivated":
                status = "expired"
            return JSONResponse({"identifier": {"type": "dns", "value": challenge["name"]},
                                 "status": "pending" if status == "processing" else status,
                                 "expires": order["expires_at"],
                                 "challenges": [self.challenge_body(challenge)]})
        raise Problem("malformed", "Unknown ACME resource", 404)

    @staticmethod
    def post_as_get(payload):
        if payload != b"":
            raise Problem("malformed", "POST-as-GET requires a zero-length JWS payload")

    def register(self, jwk, body):
        digest = thumbprint(jwk)
        with self.repository.database.connect() as c:
            existing = c.execute("SELECT * FROM acme_server_accounts WHERE thumbprint = ?",
                                 (digest,)).fetchone()
        if existing:
            return JSONResponse(self.account_body(existing),
                                headers={"Location": self.url("account/" + existing["id"])})
        if body.get("onlyReturnExisting"):
            raise Problem("accountDoesNotExist", "No account exists for this key")
        eab = body.get("externalAccountBinding")
        if not isinstance(eab, dict):
            raise Problem("externalAccountRequired", "External account binding is required")
        try:
            _, eab_header, _ = envelope(json.dumps(eab).encode())
            kid = eab_header.get("kid")
            if not isinstance(kid, str):
                raise ValueError()
        except ValueError as exc:
            raise Problem("unauthorized", "Invalid external account binding", 403) from exc
        contact = contacts(body.get("contact", []))
        try:
            with self.repository.database.connect() as c:
                c.execute("UPDATE acme_server_credentials SET enabled = enabled WHERE id = ?", (kid,))
                credential = c.execute("SELECT * FROM acme_server_credentials WHERE id = ?", (kid,)).fetchone()
                if not credential or not credential["enabled"] or credential["account_id"]:
                    raise Problem("unauthorized", "Enrollment credential is unavailable", 403)
                c.execute("UPDATE acme_server_authorizations SET generation = generation + 1 WHERE id = ?",
                          (credential["authorization_id"],))
                auth = c.execute("SELECT * FROM acme_server_authorizations WHERE id = ?",
                                 (credential["authorization_id"],)).fetchone()
                if not auth["enabled"]:
                    raise Problem("unauthorized", "Enrollment authorization is disabled", 403)
                secret = self.repository.cipher.decrypt(credential["secret_ciphertext"].encode()).decode()
                verify_eab(eab, jwk, secret, kid, self.url("new-account"))
                account_id = identifier()
                c.execute("INSERT INTO acme_server_accounts "
                          "(id, thumbprint, jwk_json, authorization_id, contact_json, status, created_at) "
                          "VALUES (?, ?, ?, ?, ?, 'valid', ?)",
                          (account_id, digest, json.dumps(jwk), auth["id"], json.dumps(contact), stamp()))
                c.execute("UPDATE acme_server_credentials SET account_id = ? WHERE id = ? AND account_id IS NULL",
                          (account_id, kid))
        except IntegrityError as exc:
            with self.repository.database.connect() as c:
                existing = c.execute("SELECT * FROM acme_server_accounts WHERE thumbprint = ?",
                                     (digest,)).fetchone()
            if existing:
                return JSONResponse(self.account_body(existing),
                                    headers={"Location": self.url("account/" + existing["id"])})
            raise Problem("unauthorized", "Enrollment authorization already has an account", 403) from exc
        account = self.repository.account(account_id)
        self.repository.event("acme_account_registered", account_id)
        return JSONResponse(self.account_body(account), status_code=201,
                            headers={"Location": self.url("account/" + account_id)})


def contacts(value):
    if not isinstance(value, list) or len(value) > 10 or any(
        not isinstance(item, str) or not item.startswith("mailto:") or "@" not in item
        or any(character.isspace() for character in item) or len(item) > 254
        for item in value
    ):
        raise Problem("invalidContact", "Only mailto contact addresses are supported")
    return value
