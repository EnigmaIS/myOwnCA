"""Starter certificate templates created only during new Test/Lab setup."""

from myownca.audit import AuditActor, AuditCategory, AuditService
from myownca.domain import CertificateProfile, CertificateTemplate
from myownca.storage.repositories import PKIRepository


LAB_TEMPLATES = (
    CertificateTemplate(
        id="lab-user-auth",
        name="Test/Lab — User authentication",
        profile=CertificateProfile.USER_AUTH,
        first_issuance_approvals=1,
        renewal_approvals=1,
    ),
    CertificateTemplate(
        id="lab-device-tls",
        name="Test/Lab — Device / server TLS",
        profile=CertificateProfile.HOST_TLS,
        first_issuance_approvals=1,
        renewal_approvals=1,
    ),
    CertificateTemplate(
        id="lab-smime",
        name="Test/Lab — S/MIME",
        profile=CertificateProfile.SMIME,
        first_issuance_approvals=1,
        renewal_approvals=1,
    ),
)


def create_lab_templates(repository: PKIRepository, audit: AuditService) -> None:
    """Add missing starters, preserving records from an interrupted setup."""
    existing_ids = {template.id for template in repository.list_templates()}
    for template in LAB_TEMPLATES:
        if template.id in existing_ids:
            continue
        repository.add_template(template)
        audit.record(
            AuditCategory.CERTIFICATE,
            "template_create",
            actor=AuditActor(id="bootstrap/setup", role="setup"),
            object_type="template",
            object_id=template.id,
            details={"profile": template.profile.value},
        )
