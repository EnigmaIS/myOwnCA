"""Operator-side Docker Hub publication and authenticated image inventory."""
from __future__ import annotations

import json
import re

from myownca_release.verify import VerificationError


_COMPONENT = r"[a-z0-9]+(?:(?:[._]|__|-+)[a-z0-9]+)*"
_HUB_IMAGE = re.compile(rf"docker\.io/[a-z0-9][a-z0-9_-]*/{_COMPONENT}\Z")
_DIGEST = re.compile(r"sha256:[0-9a-f]{64}\Z")


def normalize_image_reference(reference: str) -> str:
    """Match Docker's omitted Hub host without changing repository or digest."""
    repository, separator, digest = reference.partition("@")
    if separator and _HUB_IMAGE.fullmatch(repository) and _DIGEST.fullmatch(digest):
        return reference.removeprefix("docker.io/")
    return reference


def validate_docker_hub_image(reference):
    """Require an explicit Docker Hub namespace/repository, without a tag."""
    if not isinstance(reference, str) or not _HUB_IMAGE.fullmatch(reference):
        raise VerificationError("Provide a lowercase docker.io/namespace/image without a tag or digest")


def validate_inventory(info, images):
    """Bind the index, architecture images and proxy to the recorded destinations."""
    validate_workspace(info)
    if (not isinstance(images, dict) or set(images) != {"ca", "ca_amd64", "ca_arm64", "proxy"}
            or not all(isinstance(value, str) for value in images.values())):
        raise VerificationError("The index, both architectures and proxy must be recorded")
    for name in ("ca", "ca_amd64", "ca_arm64"):
        digest = images[name].rsplit("@", 1)[-1]
        if not _DIGEST.fullmatch(digest) or images[name] != f"{info['image']}@{digest}":
            raise VerificationError("Image inventory differs from the workspace destination")
    if images["proxy"] != info["proxy_image"]:
        raise VerificationError("Proxy image differs from the workspace destination")


def validate_workspace(info):
    if "docker_hub_image" in info or not str(info.get("image", "")).startswith("docker.io/"):
        raise VerificationError("Use the matching source tag's tools for an earlier release workspace")
    validate_docker_hub_image(info["image"])


def inspect_manifest(run, reference):
    descriptor = json.loads(run("docker", "buildx", "imagetools", "inspect", reference,
                                "--format", "{{json .Manifest}}", capture=True))
    if (not isinstance(descriptor, dict) or not isinstance(descriptor.get("digest"), str)
            or not _DIGEST.fullmatch(descriptor["digest"])):
        raise VerificationError("Registry did not return a sha256 image digest")
    return descriptor


def index_platforms(descriptor, arches):
    platforms = {}
    entries = descriptor.get("manifests")
    if not isinstance(entries, list):
        raise VerificationError("Registry did not return a multiarchitecture index")
    for entry in entries:
        if not isinstance(entry, dict) or not isinstance(entry.get("platform"), dict):
            raise VerificationError("Invalid architecture in registry index")
        platform = entry.get("platform", {})
        name = (platform.get("os"), platform.get("architecture"))
        if (not all(isinstance(part, str) for part in name)
                or name in platforms or not isinstance(entry.get("digest"), str)
                or not _DIGEST.fullmatch(entry["digest"])):
            raise VerificationError("Invalid or duplicate architecture in registry index")
        platforms[name] = entry["digest"]
    if set(platforms) != {("linux", arch) for arch in arches}:
        raise VerificationError("Registry index must contain both required Linux architectures only")
    return platforms


def push_images(info, images, arches, *, run, require_absent):
    """Push exactly the existing architecture images; never build or retry."""
    validate_workspace(info)
    repository = info["image"]
    version = info["version"]
    # Check every remote destination before the first local tag or remote write.
    for suffix in ("", *(f"-{arch}" for arch in arches)):
        require_absent(f"{repository}:{version}{suffix}")
    architecture_digests = {}
    for arch, image in zip(arches, images, strict=True):
        tag = f"{repository}:{version}-{arch}"
        run("docker", "tag", image["id"], tag)
        run("docker", "push", tag)
        print(f"Published image candidate: {tag}", flush=True)
        architecture_digests[arch] = inspect_manifest(run, tag)["digest"]
    tag = f"{repository}:{version}"
    run("docker", "buildx", "imagetools", "create", "--tag", tag,
        *(f"{repository}@{architecture_digests[arch]}" for arch in arches))
    print(f"Published image candidate: {tag}", flush=True)
    descriptor = inspect_manifest(run, tag)
    if index_platforms(descriptor, arches) != {
            ("linux", arch): architecture_digests[arch] for arch in arches}:
        raise VerificationError("Registry index differs from the pushed architecture images")
    result = {"ca": f"{repository}@{descriptor['digest']}", "proxy": info["proxy_image"],
              **{f"ca_{arch}": f"{repository}@{architecture_digests[arch]}" for arch in arches}}
    validate_inventory(info, result)
    return result


def verify_images(info, images, arches, *, run):
    """Check version and architecture tags against the signed index references."""
    validate_inventory(info, images)
    repository = info["image"]
    descriptor = inspect_manifest(run, f"{repository}:{info['version']}")
    if images["ca"] != f"{repository}@{descriptor['digest']}":
        raise VerificationError("Registry release tag differs from the recorded image digest")
    platforms = index_platforms(descriptor, arches)
    for arch in arches:
        image = inspect_manifest(run, f"{repository}:{info['version']}-{arch}")
        if (image["digest"] != platforms[("linux", arch)]
                or images[f"ca_{arch}"] != f"{repository}@{image['digest']}"):
            raise VerificationError("Registry architecture tag differs from the recorded index")
