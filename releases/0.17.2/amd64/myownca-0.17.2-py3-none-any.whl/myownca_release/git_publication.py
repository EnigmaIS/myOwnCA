"""Export accepted installation files and verify their signed public Git commit."""
from __future__ import annotations

import hashlib
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from myownca_release.verify import VerificationError, sha256, version_tuple


def release_path(info):
    version_tuple(info["version"])
    return Path("releases") / info["version"]


def source_files(work, arches):
    files = {"release-trust.json": work / "release-trust.json",
             "RELEASE-NOTES.md": work / "release-notes.md"}
    for arch in arches:
        for path in (work / arch / "bundle").iterdir():
            files[f"{arch}/{path.name}"] = path
    for path in files.values():
        if path.is_symlink() or not path.is_file():
            raise VerificationError("Installation export requires regular files")
        if path.stat().st_size >= 100 * 1024 * 1024:
            raise VerificationError("Installation file exceeds GitHub's Git file size limit")
    return files


def checksums(assets):
    return "".join(f"{digest}  {name}\n" for name, digest in sorted(assets.items()))


def export_release(work, info, arches):
    files = source_files(work, arches)
    root = work / "publication" / release_path(info)
    # An incomplete export is evidence, not a directory to overwrite or retry.
    root.mkdir(parents=True, exist_ok=False)
    for name, source in files.items():
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        target.chmod(0o644)
    assets = {name: sha256(root / name) for name in files}
    sums = root / "BOOTSTRAP-SHA256SUMS"
    sums.write_text(checksums(assets))
    sums.chmod(0o644)
    return {**assets, sums.name: sha256(sums)}


def verify_export(work, info, arches, expected):
    files = source_files(work, arches)
    root = work / "publication" / release_path(info)
    names = set(files) | {"BOOTSTRAP-SHA256SUMS"}
    if (not isinstance(expected, dict) or set(expected) != names or root.is_symlink()
            or (work / "publication").is_symlink() or root.parent.is_symlink()):
        raise VerificationError("Unexpected installation export inventory")
    actual = set()
    for path in root.rglob("*"):
        if path.is_symlink() or not (path.is_dir() or path.is_file()):
            raise VerificationError("Unsafe installation export file")
        if path.is_file():
            actual.add(path.relative_to(root).as_posix())
    if actual != names:
        raise VerificationError("Unexpected or missing installation export files")
    for name in names:
        if sha256(root / name) != expected[name]:
            raise VerificationError("Installation export changed")
    for name, source in files.items():
        if sha256(source) != expected[name]:
            raise VerificationError("Installation export differs from accepted bundle or notes")
    if (root / "BOOTSTRAP-SHA256SUMS").read_text() != checksums(
            {name: expected[name] for name in files}):
        raise VerificationError("Bootstrap checksums differ from installation files")
    return root


def verify_git_release(work, info, arches, assets, signing_key, *, run, recorded=None):
    """Read the public Git repository; never commit, tag, push or execute its code."""
    root = verify_export(work, info, arches, assets)
    key = serialization.load_ssh_public_key(signing_key.read_bytes())
    if not isinstance(key, ed25519.Ed25519PublicKey):
        raise VerificationError("Git publication requires a trusted SSH Ed25519 public key")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*",
                        info["public_repo"]):
        raise VerificationError("Invalid public Git repository")
    if info["tag"] != f"v{info['version']}":
        raise VerificationError("Public release tag differs from the release version")
    with tempfile.TemporaryDirectory(prefix="myownca-git-publication-") as directory:
        public = Path(directory) / "public"
        allowed = Path(directory) / "allowed_signers"
        allowed.write_bytes(b'* namespaces="git" ' + key.public_bytes(
            serialization.Encoding.OpenSSH, serialization.PublicFormat.OpenSSH) + b"\n")
        run("git", "init", "-q", public)
        run("git", "-C", public, "-c", "credential.helper=", "-c", "http.extraHeader=",
            "-c", "core.askPass=/bin/false", "fetch", "--no-tags",
            f"https://github.com/{info['public_repo']}.git",
            "refs/heads/main:refs/remotes/public/main",
            f"refs/tags/{info['tag']}:refs/tags/{info['tag']}",
            env={"GIT_TERMINAL_PROMPT": "0", "GIT_CONFIG_GLOBAL": "/dev/null",
                 "GIT_CONFIG_NOSYSTEM": "1"})
        def git(*args):
            return run("git", "-C", public, *args, capture=True)

        tag = f"refs/tags/{info['tag']}"
        if git("cat-file", "-t", tag) != "tag":
            raise VerificationError("Public release tag must be annotated")
        commit = git("rev-parse", f"{tag}^{{commit}}")
        identity = {"public_commit": commit, "tag_object": git("rev-parse", tag)}
        if recorded is not None and identity != recorded:
            raise VerificationError("Published Git tag differs from the accepted publication")
        git("merge-base", "--is-ancestor", commit, "refs/remotes/public/main")
        try:
            git("-c", "gpg.format=ssh", "-c", f"gpg.ssh.allowedSignersFile={allowed}",
                "verify-commit", commit)
        except subprocess.CalledProcessError as exc:
            # Keep the failed verification's diagnostics without treating it as trust.
            raise VerificationError("Public installation commit signature is invalid") from exc
        message = git("show", "--no-patch", "--format=%B", commit)
        for label, value in (("Release-Tag", info["tag"]), ("Release-Commit", info["commit"])):
            if re.findall(rf"^{label}: (.+)$", message, re.MULTILINE) != [value]:
                raise VerificationError("Public installation commit has incorrect release identity")
        private = set(run("git", "-C", work / "source", "rev-list", info["commit"],
                          capture=True).splitlines())
        if private & set(git("rev-list", "refs/remotes/public/main").splitlines()):
            raise VerificationError("Public repository includes private source history")
        prefix = release_path(info).as_posix() + "/"
        entries = {}
        for entry in git("ls-tree", "-rz", commit, "--", prefix).split("\0"):
            if entry:
                metadata, name = entry.split("\t", 1)
                mode, kind, digest = metadata.split()
                if mode != "100644" or kind != "blob" or not name.startswith(prefix):
                    raise VerificationError("Public installation files must be regular Git blobs")
                entries[name[len(prefix):]] = digest
        if set(entries) != set(assets):
            raise VerificationError("Unexpected or missing public installation files")
        algorithm = git("rev-parse", "--show-object-format")
        if algorithm not in ("sha1", "sha256"):
            raise VerificationError("Unsupported Git object format")
        for name, digest in entries.items():
            raw = (root / name).read_bytes()
            blob = hashlib.new(algorithm, f"blob {len(raw)}\0".encode() + raw).hexdigest()
            if blob != digest:
                raise VerificationError(f"Public installation file differs from accepted bytes: {name}")
        return identity
