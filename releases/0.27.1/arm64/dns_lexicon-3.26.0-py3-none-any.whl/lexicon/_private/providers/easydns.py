"""Module provider for EasyDNS"""

import json
import logging
from argparse import ArgumentParser

import requests

from lexicon.exceptions import AuthenticationError
from lexicon.interfaces import Provider as BaseProvider

LOGGER = logging.getLogger(__name__)


class Provider(BaseProvider):
    """Provider class for EasyDNS"""

    @staticmethod
    def get_nameservers() -> list[str]:
        return ["easydns.net"]

    @staticmethod
    def configure_parser(parser: ArgumentParser) -> None:
        parser.add_argument(
            "--auth-username", help="specify username for authentication"
        )
        parser.add_argument("--auth-token", help="specify token for authentication")

    def __init__(self, config):
        super().__init__(config)
        self.domain_id = None
        self.api_endpoint = (
            self._get_provider_option("api_endpoint") or "https://rest.easydns.net"
        )

    def authenticate(self):
        payload = self._get(f"/domain/{self.domain}")
        if "error" in payload:
            raise AuthenticationError(
                f"{payload['error']['code']} {payload['error']['message']}"
            )

        if payload["data"]["exists"] == "N":
            raise AuthenticationError("No domain found")

        self.domain_id = payload["data"]["id"]

    def cleanup(self) -> None:
        pass

    # Create record. If record already exists with the same content, do nothing'

    def create_record(self, rtype, name, content):
        priority, content = self._split_priority(rtype, content)
        record = {
            "type": rtype,
            "domain": self.domain_id,
            "host": self._relative_name(name),
            "ttl": self._get_lexicon_option("ttl"),
            "prio": priority,
            "rdata": content,
        }
        try:
            self._put(f"/zones/records/add/{self.domain_id}/{rtype}", record)
        except requests.exceptions.HTTPError as error:
            # FIXME: adferrand 06/01/2019: Broken provider needs fixes.
            # In fact, this except block will silently hide every HTTP error, as an except
            # block without raise statement will implicitly hide the exception.
            # In reality, tests of Easy DNS are failing...
            # So this provider needs to be corrected.
            if error.response.status_code == 400:
                pass
            # http 400 is ok here, because the record probably already exists
        LOGGER.debug("create_record: %s", True)
        return True

    # List all records. Return an empty list if no records found
    # type, name and content are used to filter records.
    # If possible filter during the query, otherwise filter after response is received.
    def list_records(self, rtype=None, name=None, content=None):
        payload = self._get(f"/zones/records/all/{self.domain_id}")
        records = []
        for record in payload["data"]:
            processed_record = {
                "type": record["type"],
                "name": f"{record['host']}.{record['domain']}",
                "ttl": record["ttl"],
                "content": self._join_priority(record),
                "id": record["id"],
            }
            records.append(processed_record)

        if rtype:
            records = [record for record in records if record["type"] == rtype]
        if name:
            records = [
                record for record in records if record["name"] == self._full_name(name)
            ]
        if content:
            records = [record for record in records if record["content"] == content]

        LOGGER.debug("list_records: %s", records)
        return records

    # Create or update a record.
    def update_record(self, identifier, rtype=None, name=None, content=None):
        data = {"ttl": self._get_lexicon_option("ttl")}
        if rtype:
            data["type"] = rtype
        if name:
            data["host"] = self._relative_name(name)
        if content:
            priority, data["rdata"] = self._split_priority(rtype, content)
            if rtype in ("MX", "SRV"):
                data["prio"] = priority

        self._post(f"/zones/records/{identifier}", data)

        LOGGER.debug("update_record: %s", True)
        return True

    # Delete an existing record.
    # If record does not exist, do nothing.
    def delete_record(self, identifier=None, rtype=None, name=None, content=None):
        delete_record_id = []
        if not identifier:
            records = self.list_records(rtype, name, content)
            delete_record_id = [record["id"] for record in records]
        else:
            delete_record_id.append(identifier)

        LOGGER.debug("delete_records: %s", delete_record_id)

        for record_id in delete_record_id:
            self._delete(f"/zones/records/{self.domain_id}/{record_id}")

        # is always True at this point, if a non 200 response is returned an error is raised.
        LOGGER.debug("delete_record: %s", True)
        return True

    # Helpers

    # easyDNS keeps the priority of an MX or SRV record in "prio".  The content
    # of such a record is its whole RDATA, with the priority in front, as in
    # "10 mail.example.com.", unless --priority gives the priority.  The rdata
    # of an MX is its target alone, but the rdata of an SRV is its whole RDATA,
    # priority included, as the easyDNS console writes it.
    def _split_priority(self, rtype, content):
        priority = self._get_lexicon_option("priority")
        if rtype == "SRV" and content:
            if priority is not None:
                return int(priority), f"{priority} {content}"
            first = content.partition(" ")[0]
            return int(first) if first.isdigit() else 0, content
        if priority is None and rtype == "MX" and content:
            first, _, rest = content.partition(" ")
            if rest and first.isdigit():
                return int(first), rest
        return int(priority) if priority else 0, content

    # The content of a record that easyDNS lists, with the priority of an MX
    # in front again, so that the content reads as it was given.  The rdata of
    # an SRV holds its priority already.
    def _join_priority(self, record):
        if record["type"] == "MX" and record.get("prio") is not None:
            return f"{record['prio']} {record['rdata']}"
        return record["rdata"]

    def _request(self, action="GET", url="/", data=None, query_params=None):
        if data is None:
            data = {}
        if query_params is None:
            query_params = {}
        query_params["format"] = "json"
        default_headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

        response = requests.request(
            action,
            self.api_endpoint + url,
            params=query_params,
            data=json.dumps(data),
            headers=default_headers,
            auth=(
                self._get_provider_option("auth_username"),
                self._get_provider_option("auth_token"),
            ),
        )
        # if the request fails for any reason, throw an error.
        response.raise_for_status()
        return response.json()
