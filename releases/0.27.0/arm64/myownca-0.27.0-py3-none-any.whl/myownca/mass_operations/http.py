"""Superuser API for confirmed, immutable bulk jobs."""

from uuid import UUID
from typing import Literal

from fastapi import APIRouter, HTTPException, Request, Query
from pydantic import BaseModel, Field
from myownca.audit.base import AuditCategory
from myownca.domain import Role
from myownca.storage.repositories import RepositoryError
from .service import ACTIONS


class Submission(BaseModel):
    idempotency_key: UUID
    action: str
    target_ids: list[str] = Field(min_length=1, max_length=10000)
    reason: str = Field(min_length=10, max_length=500)
    confirmation: str


def register(app, jobs, active_user, audit_actor, destructive):
    router = APIRouter(prefix="/internal/mass-operations")

    @router.post("", status_code=202)
    def create(payload: Submission, request: Request):
        if payload.action not in ACTIONS or any(not x or len(x) > 191 for x in payload.target_ids):
            raise HTTPException(422, "Invalid action or target ID")
        if len(set(payload.target_ids)) != len(payload.target_ids):
            raise HTTPException(422, "Duplicate target IDs")
        destructive(
            request,
            payload,
            expected_confirmation=f"{payload.action.upper()} {len(payload.target_ids)}",
            category=AuditCategory.CERTIFICATE,
            action="mass_operation",
            object_type="mass_job",
            object_id=str(payload.idempotency_key),
            roles=(Role.SUPERUSER,),
        )
        try:
            jid = jobs.create(
                str(payload.idempotency_key),
                audit_actor(request),
                payload.action,
                payload.target_ids,
                payload.reason.strip(),
            )
            return jobs.detail(jid)
        except RepositoryError as exc:
            raise HTTPException(409, str(exc)) from exc

    @router.get("")
    def listing(
        request: Request,
        limit: int = Query(50, ge=1, le=100),
        offset: int = Query(0, ge=0),
        status: Literal["all", "active", "history"] = "all",
    ):
        active_user(request, Role.SUPERUSER)
        with jobs.database.connect() as c:
            where = ""
            if status != "all":
                where = (
                    " WHERE state "
                    + ("IN" if status == "active" else "NOT IN")
                    + " ('queued','running')"
                )
            rows = c.execute(
                "SELECT id FROM mass_jobs"
                + where
                + " ORDER BY created_at DESC, id LIMIT ? OFFSET ?",
                (limit, offset),
            ).fetchall()
        return [jobs.detail(r["id"]) for r in rows]

    @router.get("/{job_id}")
    def detail(job_id: str, request: Request):
        active_user(request, Role.SUPERUSER)
        try:
            return jobs.detail(job_id)
        except RepositoryError as exc:
            raise HTTPException(404, str(exc)) from exc

    @router.get("/{job_id}/items")
    def items(
        job_id: str,
        request: Request,
        state: str | None = None,
        limit: int = Query(100, ge=1, le=10000),
        offset: int = Query(0, ge=0),
    ):
        detail(job_id, request)
        with jobs.database.connect() as c:
            sql = "SELECT target_id, state, message FROM mass_items WHERE job_id = ?"
            args = [job_id]
            if state:
                sql += " AND state = ?"
                args.append(state)
            return c.execute(
                sql + " ORDER BY target_id LIMIT ? OFFSET ?", (*args, limit, offset)
            ).fetchall()

    @router.post("/{job_id}/cancel")
    def cancel(job_id: str, request: Request):
        active_user(request, Role.SUPERUSER, csrf=True)
        try:
            jobs.cancel(job_id, audit_actor(request))
            return jobs.detail(job_id)
        except RepositoryError as exc:
            raise HTTPException(404, str(exc)) from exc

    app.include_router(router)
