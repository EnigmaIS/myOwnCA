"""Transactional job execution with durable per-record outcomes."""

import copy
import hashlib
import json
from datetime import datetime, timezone

from myownca.audit.base import AuditActor, AuditCategory, AuditOutcome
from myownca.batch_import.repository import TransactionDatabase
from myownca.domain import CertificateStatus, RevocationReason
from myownca.device_archive import archive_device
from myownca.person_archive import archive_person
from myownca.storage.repositories import PKIRepository, RepositoryError
from myownca.key_lifecycle.repository import KeyLifecycleRepository
from myownca.key_lifecycle.service import KeyLifecycleService
from myownca.key_lifecycle.base import KeyOwnership, KeyStatus

ACTIONS = {"revoke", "archive_certificates", "archive_people", "archive_devices"}


def stamp():
    return datetime.now(timezone.utc).isoformat()


class MassOperations:
    def __init__(self, repository, service, audit):
        self.repository, self.service, self.audit = repository, service, audit
        self.database = repository.database

    def create(self, job_id, actor, action, ids, reason):
        digest = hashlib.sha256(json.dumps([action, sorted(ids), reason]).encode()).hexdigest()
        with self.audit.transaction() as tx:
            c = tx.connection
            # Serialize idempotent creation on the submitting account.
            c.execute("UPDATE users SET id = id WHERE id = ?", (actor.id,))
            old = c.execute("SELECT * FROM mass_jobs WHERE id = ?", (job_id,)).fetchone()
            if old:
                if old["actor_id"] != actor.id or old["payload_hash"] != digest:
                    raise RepositoryError("Idempotency key already used for a different operation")
                return job_id
            now = stamp()
            c.execute(
                "INSERT INTO mass_jobs VALUES (?, ?, ?, ?, ?, 'queued', ?, ?)",
                (job_id, actor.id, action, reason, digest, now, now),
            )
            for target in ids:
                c.execute("INSERT INTO mass_items VALUES (?, ?, 'pending', '')", (job_id, target))
            tx.record(
                AuditCategory.CERTIFICATE,
                "mass_operation_created",
                actor=actor,
                object_type="mass_job",
                object_id=job_id,
                details={"action": action, "count": len(ids), "reason": reason},
            )
        return job_id

    def detail(self, job_id):
        with self.database.connect() as c:
            job = c.execute("SELECT * FROM mass_jobs WHERE id = ?", (job_id,)).fetchone()
            if not job:
                raise RepositoryError("Unknown mass operation")
            job.pop("payload_hash")
            job["counts"] = {
                r["state"]: r["n"]
                for r in c.execute(
                    "SELECT state, count(*) AS n FROM mass_items WHERE job_id = ? GROUP BY state",
                    (job_id,),
                ).fetchall()
            }
            job["total"] = sum(job["counts"].values())
            return job

    def cancel(self, job_id, actor):
        with self.audit.transaction() as tx:
            c = tx.connection
            c.execute("UPDATE mass_jobs SET updated_at = ? WHERE id = ?", (stamp(), job_id))
            job = c.execute("SELECT * FROM mass_jobs WHERE id = ?", (job_id,)).fetchone()
            if not job:
                raise RepositoryError("Unknown mass operation")
            if job["state"] not in {"queued", "running"}:
                return
            c.execute(
                "UPDATE mass_items SET state = 'canceled' WHERE job_id = ? AND state = 'pending'",
                (job_id,),
            )
            c.execute("UPDATE mass_jobs SET state = 'canceled' WHERE id = ?", (job_id,))
            tx.record(
                AuditCategory.CERTIFICATE,
                "mass_operation_canceled",
                actor=actor,
                object_type="mass_job",
                object_id=job_id,
            )

    def execute(self, tx, job, target, actor):
        c = tx.connection
        db = TransactionDatabase(c)
        repo = PKIRepository(db)
        action = job["action"]
        details = {"job_id": job["id"], "reason": job["reason"]}
        if action == "archive_people":
            person = archive_person(repo, target, connection=c, actor_id=actor.id)
            details["archived_at"] = person.archived_at.isoformat()
            details["disabled_account_ids"] = [
                row["id"]
                for row in c.execute(
                    "SELECT id FROM users WHERE person_id = ?", (target,)
                ).fetchall()
            ]
            event, kind = "person_archived", "person"
        elif action == "archive_devices":
            _, impact = archive_device(repo, target, connection=c, actor_id=actor.id)
            details.update(impact)
            event, kind = "device_archived", "device"
        else:
            cert = repo.get_certificate_by_id(target)
            if cert.archived_at or (
                action == "revoke" and cert.status is CertificateStatus.REVOKED
            ):
                return "skipped", "Already archived or revoked"
            service = copy.copy(self.service)
            service.repository = repo
            # Publish cache notifications only after the transaction commits.
            service.cert_change_listener = service.crl_change_listener = None
            now = datetime.now(timezone.utc)
            if action == "revoke" or (
                cert.status is CertificateStatus.ACTIVE and cert.expires_at > now
            ):
                reason = (
                    RevocationReason.UNSPECIFIED
                    if action == "revoke"
                    else RevocationReason.CESSATION_OF_OPERATION
                )
                service.revoke_certificate_by_id(target, reason, now=now)
            if action == "archive_certificates":
                repo.archive_certificate_by_id(target, now)
            keys = KeyLifecycleRepository(db)
            lifecycle = KeyLifecycleService(keys)
            key_id = cert.key_registry_id
            if key_id is None and repo.get_request_private_key(cert.request_id) is not None:
                registered = keys.find(
                    backend="request_vault", key_ref=cert.request_id
                ) or keys.register(
                    backend="request_vault",
                    key_ref=cert.request_id,
                    purpose="leaf_certificate",
                    ownership=KeyOwnership.MANAGED,
                )
                key_id = registered.id
                repo.set_certificate_key_registry_id_by_id(target, key_id)
            if key_id:
                bindings = keys.list_bindings(key_id)
                if any(
                    b.resource_type == "certificate" and b.resource_id == target for b in bindings
                ):
                    lifecycle.unbind_key(
                        key_id, resource_type="certificate", resource_id=target, now=now
                    )
                elif not bindings and keys.get(key_id).status is KeyStatus.ACTIVE:
                    lifecycle.orphan_key(key_id, now=now)
            details["serial_number"] = cert.serial_number
            details["revocation_reason"] = (
                "unspecified" if action == "revoke" else "cessationOfOperation"
            )
            event, kind = (
                ("revoke" if action == "revoke" else "certificate_archived"),
                "certificate",
            )
        tx.record(
            AuditCategory.PERMISSION if kind != "certificate" else AuditCategory.CERTIFICATE,
            event,
            actor=actor,
            object_type=kind,
            object_id=target,
            details=details,
        )
        return "succeeded", "Completed"

    def tick(self):
        for _ in range(25):
            changed = None
            with self.database.connect() as lookup:
                candidate = lookup.execute(
                    "SELECT id FROM mass_jobs WHERE state IN ('queued','running') ORDER BY created_at, id LIMIT 1"
                ).fetchone()
            if not candidate:
                return
            jid = candidate["id"]
            with self.audit.transaction() as tx:
                c = tx.connection
                # Acquire a write lock before reading work, including SQLite.
                c.execute("UPDATE mass_jobs SET updated_at = ? WHERE id = ?", (stamp(), jid))
                job = c.execute("SELECT * FROM mass_jobs WHERE id = ?", (jid,)).fetchone()
                if job["state"] not in {"queued", "running"}:
                    continue
                user = c.execute("SELECT * FROM users WHERE id = ?", (job["actor_id"],)).fetchone()
                if not user or not user["is_active"] or user["role"] != "superuser":
                    c.execute(
                        "UPDATE mass_items SET state = 'canceled', message = 'Submitting account is no longer authorized' WHERE job_id = ? AND state = 'pending'",
                        (jid,),
                    )
                    c.execute("UPDATE mass_jobs SET state = 'canceled' WHERE id = ?", (jid,))
                    continue
                actor = AuditActor(id=user["id"], email=user["email"], role=user["role"])
                item = c.execute(
                    "SELECT * FROM mass_items WHERE job_id = ? AND state = 'pending' ORDER BY target_id LIMIT 1",
                    (jid,),
                ).fetchone()
                if not item:
                    failed = c.execute(
                        "SELECT target_id FROM mass_items WHERE job_id = ? AND state = 'failed' LIMIT 1",
                        (jid,),
                    ).fetchone()
                    c.execute(
                        "UPDATE mass_jobs SET state = ? WHERE id = ?",
                        ("completed_with_errors" if failed else "completed", jid),
                    )
                    continue
                c.execute("SAVEPOINT mass_target")
                try:
                    state, message = self.execute(tx, job, item["target_id"], actor)
                    if state == "succeeded" and job["action"] in {"revoke", "archive_certificates"}:
                        changed = PKIRepository(TransactionDatabase(c)).get_certificate_by_id(
                            item["target_id"]
                        )
                except RepositoryError as exc:
                    c.execute("ROLLBACK TO SAVEPOINT mass_target")
                    # Blocker text from retirement is operational, not provider error text.
                    state = "failed"
                    message = (
                        str(exc)
                        if str(exc).startswith(
                            (
                                "Cannot archive",
                                "Unknown",
                                "You cannot",
                                "Only an admin",
                                "Archiving requires",
                            )
                        )
                        else "Record could not be processed; check holder dependencies and current state"
                    )
                c.execute("RELEASE SAVEPOINT mass_target")
                if state == "failed":
                    tx.record(
                        AuditCategory.CERTIFICATE,
                        "mass_operation_item_failed",
                        actor=actor,
                        outcome=AuditOutcome.FAILURE,
                        object_type="mass_job",
                        object_id=jid,
                        details={"target_id": item["target_id"], "message": message},
                    )
                c.execute(
                    "UPDATE mass_items SET state = ?, message = ? WHERE job_id = ? AND target_id = ?",
                    (state, message, jid, item["target_id"]),
                )
                c.execute("UPDATE mass_jobs SET state = 'running' WHERE id = ?", (jid,))
            if changed:
                self.service._notify_cert_change(changed.serial_number)
                self.service._notify_crl_change(changed.issuer_id)
