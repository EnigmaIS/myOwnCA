"""Persistent, operator-authorized inventory operations."""
