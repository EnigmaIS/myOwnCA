"""Validate restored references and retired identities before publishing data."""
from sqlalchemy import and_, exists, or_, select


def validate_restored_database(connection, metadata) -> None:
    # MySQL does not retrospectively check rows when FOREIGN_KEY_CHECKS is enabled.
    # Check every reference inside the restore transaction on both backends.
    for table in metadata.tables.values():
        for constraint in table.foreign_key_constraints:
            parent = constraint.referred_table.alias()
            present = and_(*(element.parent.is_not(None) for element in constraint.elements))
            matching = and_(*(
                element.parent == parent.c[element.column.name]
                for element in constraint.elements
            ))
            missing = ~exists(select(1).select_from(parent).where(matching).correlate(table))
            if connection.execute(select(1).select_from(table).where(present, missing).limit(1)).first():
                raise ValueError(f"Restored database has foreign-key violations: {table.name}")

    people = metadata.tables["people"]
    retired = people.c.archived_at.is_not(None)
    checks = (
        ("devices", "admin_id", lambda t: t.c.archived_at.is_(None)),
        ("certificate_requests", "holder_person_id", lambda t: t.c.status == "pending"),
        ("certificate_inventory", "holder_person_id", lambda t: t.c.archived_at.is_(None)),
        ("secure_links", "person_id", lambda t: or_(
            t.c.revoked_at.is_(None), t.c.otp_hash.is_not(None), t.c.otp_expires_at.is_not(None),
            t.c.session_token_hash.is_not(None), t.c.session_expires_at.is_not(None),
        )),
    )
    for name, person_column, invalid in checks:
        table = metadata.tables[name]
        statement = select(1).select_from(table.join(people, table.c[person_column] == people.c.id))
        statement = statement.where(retired)
        if invalid is not None:
            statement = statement.where(invalid(table))
        if connection.execute(statement.limit(1)).first():
            raise ValueError(f"Restored database violates person archive rules: {name}")

    devices = metadata.tables["devices"]
    for name, column, live in (
        ("certificate_requests", "holder_device_id", lambda t: t.c.status == "pending"),
        ("certificate_inventory", "holder_device_id", lambda t: t.c.archived_at.is_(None)),
        ("acme_server_authorizations", "device_id", lambda t: t.c.enabled == 1),
    ):
        table = metadata.tables[name]
        invalid = select(1).select_from(table.join(devices, table.c[column] == devices.c.id)).where(
            devices.c.archived_at.is_not(None), live(table))
        if connection.execute(invalid.limit(1)).first():
            raise ValueError(f"Restored database violates device archive rules: {name}")

    links = metadata.tables["secure_links"]
    inventory = metadata.tables["certificate_inventory"]
    invalid_links = select(1).select_from(links.join(inventory, links.c.certificate_id == inventory.c.certificate_id)
                                        .join(devices, inventory.c.holder_device_id == devices.c.id)).where(
        devices.c.archived_at.is_not(None), or_(links.c.revoked_at.is_(None),
        links.c.otp_hash.is_not(None), links.c.otp_expires_at.is_not(None),
        links.c.session_token_hash.is_not(None), links.c.session_expires_at.is_not(None)))
    if connection.execute(invalid_links.limit(1)).first():
        raise ValueError("Restored database violates device archive rules: secure_links")

    credentials = metadata.tables["acme_server_credentials"]
    authorizations = metadata.tables["acme_server_authorizations"]
    invalid_credentials = select(1).select_from(credentials.join(
        authorizations, credentials.c.authorization_id == authorizations.c.id).join(
        devices, authorizations.c.device_id == devices.c.id)).where(
        devices.c.archived_at.is_not(None), credentials.c.enabled == 1)
    if connection.execute(invalid_credentials.limit(1)).first():
        raise ValueError("Restored database violates device archive rules: acme_server_credentials")
