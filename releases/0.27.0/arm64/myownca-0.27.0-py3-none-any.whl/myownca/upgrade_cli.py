"""Operator-facing pre-cutover diagnostics; no provisioning or remediation."""

import json
import sys
from pathlib import Path

from myownca.config import Settings
from myownca.storage.upgrade_checks import check_active_email_conflicts


def run_upgrade_check(state_dir: str | Path) -> int:
    try:
        settings = Settings.load(state_dir)
        conflicts = check_active_email_conflicts(settings.database_url or settings.database_path)
    except Exception as exc:  # noqa: BLE001 - driver/configuration errors may contain credentials
        print(
            f"Cannot check upgrade compatibility ({type(exc).__name__}). "
            "Check configuration, existing database schema and access. No changes made.",
            file=sys.stderr,
        )
        return 2
    if conflicts:
        print("Conflicting active People emails:")
        for conflict in conflicts:
            print(f"  email={json.dumps(conflict.email)} "
                  f"person_ids={json.dumps(conflict.person_ids)}")
        print(
            "Do not stop or replace the running service. Resolve these conflicts with "
            "operator review, preserving Person identities and history, then rerun this check. "
            "No changes made."
        )
        return 1
    print(
        "No active People email conflicts found. This checks email compatibility only; "
        "startup still rechecks before migrating. No changes made."
    )
    return 0
