"""Transactional retirement of a holder while retaining historical identity."""
import json
from datetime import datetime, timezone
from contextlib import nullcontext

from myownca.storage.repositories import RepositoryError, _person_from_row


def archive_person(repository, person_id, *, connection=None, actor_id=None):
    moment = datetime.now(timezone.utc).isoformat()
    with (nullcontext(connection) if connection is not None else repository.database.connect()) as connection:
        from myownca.ca_auth.repository import AuthRepository
        auth = AuthRepository(repository.database)
        governance = auth._lock_governance_row(connection)
        # A write lock on the identity serializes archiving with new assignments.
        connection.execute("UPDATE people SET id = id WHERE id = ?", (person_id,))
        suffix = "" if connection._dialect == "sqlite" else " FOR UPDATE"
        person = connection.execute("SELECT * FROM people WHERE id = ?" + suffix, (person_id,)).fetchone()
        if person is None:
            raise RepositoryError(f"Unknown person: {person_id}")
        if person["archived_at"]:
            raise RepositoryError("Person is already archived")
        suffix = "" if connection._dialect == "sqlite" else " FOR UPDATE"
        target = connection.execute(
            "SELECT * FROM users WHERE person_id = ?" + suffix, (person_id,)
        ).fetchone()
        if actor_id is not None:
            actor = auth._locked_user_row(connection, actor_id)
            if not actor or not actor["is_active"] or actor["role"] not in {"admin", "superuser"}:
                raise RepositoryError("An active authorized account is required")
            if target and target["id"] == actor_id:
                raise RepositoryError("You cannot archive your own account")
            if target and target["role"] in {"admin", "superuser"} and actor["role"] != "admin":
                raise RepositoryError("Only an admin may archive a privileged account")
        if target and target["is_active"] and target["role"] == "admin":
            if governance is None:
                raise RepositoryError("Governance is unavailable")
            admins = connection.execute(
                "SELECT id FROM users WHERE role = 'admin' AND is_active = 1" + suffix
            ).fetchall()
            minimum = 2 if governance["mode"] == "dual_control" else 1
            if len(admins) <= minimum:
                raise RepositoryError(f"Archiving requires at least {minimum} active administrators to remain")
        blockers = []
        for query, reason in (
            ("SELECT id FROM devices WHERE admin_id = ? AND archived_at IS NULL", "assigned devices must be reassigned"),
            ("SELECT certificate_id FROM certificate_inventory WHERE holder_person_id = ? AND archived_at IS NULL",
             "certificates must be archived"),
            ("SELECT id FROM certificate_requests WHERE holder_person_id = ? AND status = 'pending'",
             "pending requests must be resolved"),
        ):
            if connection.execute(query + suffix, (person_id,)).fetchone():
                blockers.append(reason)
        # Locking reads see committed worker/cancellation changes on InnoDB too.
        suffix = " FOR UPDATE" if connection._dialect != "sqlite" else ""
        work = connection.execute(
            "SELECT record FROM batch_records WHERE state NOT IN ('completed', 'canceled')" + suffix
        ).fetchall()
        if any(json.loads(row["record"])["holder"]["unique_id"] == person_id
               and "email" in json.loads(row["record"])["holder"] for row in work):
            blockers.append("unfinished batch work must be completed or canceled")
        if blockers:
            raise RepositoryError("Cannot archive person: " + "; ".join(blockers))
        connection.execute(
            "UPDATE secure_links SET revoked_at = ?, session_token_hash = NULL, "
            "session_expires_at = NULL, otp_hash = NULL, otp_expires_at = NULL WHERE person_id = ?",
            (moment, person_id),
        )
        if target:
            connection.execute("UPDATE users SET is_active = 0 WHERE id = ?", (target["id"],))
            connection.execute(
                "UPDATE auth_sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL",
                (moment, target["id"]),
            )
        connection.execute("UPDATE people SET archived_at = ? WHERE id = ?", (moment, person_id))
        return _person_from_row(
            connection.execute("SELECT * FROM people WHERE id = ?", (person_id,)).fetchone()
        )
