/* Persistent bulk selection and job monitoring for the Superuser inventory. */
const MassUI = (() => {
  const states = new Map();
  const labels = { revoke: 'Revoke', archive_certificates: 'Revoke & archive', archive_people: 'Archive', archive_devices: 'Archive' };
  const id = row => row.certificate_id || row.id;
  const label = row => row.subject || row.displayName || row.device_name || id(row);
  const node = (tag, text) => { const el = document.createElement(tag); el.textContent = text; return el; };
  function columns(type, rows, resetKey, refresh) {
    let state = states.get(type);
    const table = BB.$(`#${type}-table`);
    if (!state) {
      state = { selected: new Map(), key: resetKey, refresh };
      states.set(type, state);
      state.bar = node('div', ''); state.bar.className = 'actions';
      table.before(state.bar);
    }
    if (state.key !== resetKey) state.selected.clear();
    state.key = resetKey;
    const eligible = rows.filter(row => !row.archived_at);
    const valid = new Set(eligible.map(id));
    for (const key of state.selected.keys()) if (!valid.has(key)) state.selected.delete(key);
    function toolbar() {
      state.bar.replaceChildren(node('span', `${state.selected.size} selected. Changing filters clears selection.`));
      state.bar.append(BB.actionButton('Select current page', () => {
        table.querySelectorAll('input[data-mass-id]').forEach(input => { input.checked = true; input.dispatchEvent(new Event('change')); });
      }));
      state.bar.append(BB.actionButton(`Select all matching (${eligible.length})`, () => {
        eligible.forEach(row => state.selected.set(id(row), row)); state.refreshView();
      }));
      state.bar.append(BB.actionButton('Clear selection', () => { state.selected.clear(); state.refreshView(); }));
      const actions = type === 'certs' ? ['revoke', 'archive_certificates'] : [type === 'people' ? 'archive_people' : 'archive_devices'];
      for (const action of actions) {
        const button = BB.actionButton(`${labels[action]} selected`, () => submit(action, [...state.selected.values()], state.refresh).catch(BB.showError), 'danger');
        button.disabled = !state.selected.size; state.bar.append(button);
      }
      state.bar.append(BB.actionButton('Mass operations', () => monitor(state.refresh).catch(BB.showError)));
    }
    state.refreshView = () => {
      table.querySelectorAll('input[data-mass-id]').forEach(input => { input.checked = state.selected.has(input.dataset.massId); });
      toolbar();
    };
    toolbar();
    return [{ header: 'Select', render: row => {
      if (row.archived_at) return '';
      const input = document.createElement('input'); input.type = 'checkbox';
      input.dataset.massId = id(row); input.checked = state.selected.has(id(row));
      input.setAttribute('aria-label', `Select ${label(row)}`);
      input.addEventListener('keydown', event => event.stopPropagation());
      input.addEventListener('change', () => {
        if (input.checked) state.selected.set(id(row), row); else state.selected.delete(id(row));
        toolbar();
      });
      return input;
    } }];
  }
  async function submit(action, rows, refresh, canOpen = () => true) {
    const ids = rows.map(id);
    const key = crypto.randomUUID();
    const confirmation = `${action.toUpperCase()} ${ids.length}`;
    const form = document.createElement('form');
    form.append(node('p', `${labels[action]} ${ids.length} records. Completed changes cannot be undone. Existing archive blockers apply; related records are not automatically archived. Jobs continue after logout or browser closure.`));
    const records = node('details', ''); records.append(node('summary', 'Selected records'));
    records.append(node('pre', rows.map(label).join('\n'))); form.append(records);
    const field = (title, tag = 'input') => { const wrap = node('label', title); const input = document.createElement(tag); wrap.append(input); form.append(wrap); return input; };
    const reason = field('Operational reason', 'textarea'); reason.required = true; reason.minLength = 10; reason.maxLength = 500;
    const typed = field(`Type ${confirmation}`); typed.required = true; typed.autocomplete = 'off';
    const me = await BB.api('/internal/auth/me');
    if (!canOpen()) return;
    const auth = me.sensitive_auth || { method: 'password', recent: false };
    const credential = field(auth.method === 'totp' ? 'Current TOTP code' : 'Current password');
    credential.type = auth.method === 'totp' ? 'text' : 'password'; credential.required = !auth.recent;
    credential.parentElement.hidden = auth.recent;
    credential.autocomplete = auth.method === 'totp' ? 'one-time-code' : 'current-password';
    const error = node('p', ''); error.setAttribute('role', 'alert'); form.append(error);
    const button = node('button', 'Start background operation'); button.type = 'submit'; form.append(button);
    const dialog = BB.modal({ title: labels[action], content: form });
    form.addEventListener('submit', async event => {
      event.preventDefault();
      if (typed.value !== confirmation || reason.value.trim().length < 10) { error.textContent = 'Check the reason and exact confirmation.'; return; }
      button.disabled = true;
      try {
        let csrf = me.csrf_token;
        if (!auth.recent) {
          const verified = await BB.api(auth.method === 'totp' ? '/internal/auth/totp/reauthenticate' : '/internal/auth/password/reauthenticate', {
            method: 'POST', body: JSON.stringify(auth.method === 'totp' ? { code: credential.value } : { password: credential.value }),
          });
          csrf = verified.csrf_token;
        }
        await BB.api('/internal/mass-operations', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ idempotency_key: key, action, target_ids: ids, reason: reason.value.trim(), confirmation }) });
        dialog.close(); await monitor(refresh);
      } catch (failure) { error.textContent = failure.message; button.disabled = false; }
    });
  }
  async function monitor(refresh) {
    const content = node('div', 'Loading…');
    let closed = false, timer;
    const seen = new Map();
    const pollError = node('p', '');
    pollError.setAttribute('role', 'alert');
    const focusKey = descriptor => JSON.stringify(descriptor);
    const identify = (element, descriptor, targets) => {
      const key = focusKey(descriptor);
      element.dataset.massFocus = key;
      targets.set(key, element);
      return element;
    };
    const pages = { active: 0, history: 0 };
    let generation = 0;
    let pendingChildren = 0;
    const dialog = BB.modal({ title: 'Mass operations', content, onClose: () => { closed = true; clearTimeout(timer); refresh().catch(BB.showError); } });
    const suspended = () => pendingChildren > 0
      || Array.from(document.querySelectorAll('.modal-card')).at(-1) !== dialog.card;
    async function childRequest(open) {
      pendingChildren++;
      try { await open(); }
      catch (error) { if (!closed) BB.showError(error); }
      finally { pendingChildren--; }
    }
    async function poll() {
      clearTimeout(timer);
      const current = ++generation;
      try {
        if (closed || suspended()) return;
        const load = async status => {
          let jobs;
          do {
            jobs = await BB.api(`/internal/mass-operations?status=${status}&limit=51&offset=${pages[status] * 50}`);
            if (closed || current !== generation || suspended()) return null;
            if (jobs.length || !pages[status]) break;
            pages[status]--;
          } while (true);
          return jobs;
        };
        const lists = await Promise.all([load('active'), load('history')]);
        if (closed || current !== generation || suspended() || lists.some(list => list === null)) return;
        const visible = new Map(lists.flat().map(job => [job.id, job]));
        let finished = false;
        for (const [id, oldState] of seen) {
          if (!['queued', 'running'].includes(oldState)) continue;
          const job = visible.get(id) || await BB.api(`/internal/mass-operations/${id}`);
          if (closed || current !== generation || suspended()) return;
          if (!['queued', 'running'].includes(job.state)) finished = true;
          seen.set(id, job.state);
        }
        seen.clear();
        lists[0].slice(0, 50).forEach(job => seen.set(job.id, job.state));
        if (finished) await refresh();
        if (closed || current !== generation || suspended()) return;
        // Capture at render time so a slow response cannot steal focus from another dialog.
        const active = document.activeElement;
        const focusedGroup = content.contains(active) ? active.dataset.massGroup : null;
        const focused = content.contains(active) && active.dataset.massFocus
          ? JSON.parse(active.dataset.massFocus) : null;
        const targets = new Map();
        content.replaceChildren();
        for (const [index, status] of ['active', 'history'].entries()) {
          const group = node('section', '');
          const heading = identify(node('h2', status === 'active' ? 'Active jobs' : 'History'), { group: status }, targets);
          heading.tabIndex = -1;
          group.append(heading);
          const jobs = lists[index];
          const previous = BB.actionButton('Previous', () => { pages[status]--; return poll(); });
          identify(previous, { group: status, page: 'previous' }, targets);
          previous.disabled = pages[status] === 0;
          const next = BB.actionButton('Next', () => { pages[status]++; return poll(); });
          identify(next, { group: status, page: 'next' }, targets);
          next.disabled = jobs.length <= 50;
          group.append(previous, node('span', `Page ${pages[status] + 1}`), next);
          if (!jobs.length) group.append(node('p', 'No jobs.'));
          for (const job of jobs.slice(0, 50)) {
            const section = node('section', '');
            section.append(node('h3', `${labels[job.action]} — ${job.state}`));
            section.append(node('p', `${job.total - (job.counts.pending || 0)}/${job.total} processed: ${Object.entries(job.counts).map(([k,v]) => `${v} ${k}`).join(', ')}`));
            const jobButton = (action, title, handler) => {
              const button = identify(BB.actionButton(title, handler), { job: job.id, action }, targets);
              button.dataset.massGroup = status;
              return button;
            };
            section.append(jobButton('results', 'Results', async () => {
              await childRequest(async () => {
                const results = await BB.api(`/internal/mass-operations/${job.id}/items?limit=10000`);
                if (!closed) BB.showResultDetails(results);
              });
            }));
            if (['queued', 'running'].includes(job.state)) section.append(jobButton('cancel', 'Cancel remaining', async () => {
              try { await BB.api(`/internal/mass-operations/${job.id}/cancel`, { method: 'POST' }); await poll(); } catch (e) { BB.showError(e); }
            }));
            if (job.counts.failed) section.append(jobButton('retry', 'Retry failed records', async () => {
              await childRequest(async () => {
                const failures = await BB.api(`/internal/mass-operations/${job.id}/items?state=failed&limit=10000`);
                if (!closed) await submit(job.action, failures.map(row => ({ id: row.target_id })), refresh, () => !closed);
              });
            }));
            group.append(section);
          }
          content.append(group);
        }
        if (focused) {
          const enabled = descriptor => {
            const target = targets.get(focusKey(descriptor));
            return target && !target.disabled ? target : null;
          };
          const replacement = enabled(focused)
            || (focused.job && enabled({ job: focused.job, action: 'results' }))
            || (focused.page && enabled({ group: focused.group, page: focused.page === 'next' ? 'previous' : 'next' }))
            || enabled({ group: focused.group || focusedGroup });
          replacement?.focus({ preventScroll: true });
        }
      } catch (error) {
        if (!closed && current === generation && !suspended()) {
          pollError.textContent = error.message;
          if (!content.contains(pollError)) content.append(pollError);
        }
      } finally {
        if (!closed && current === generation) timer = setTimeout(poll, 5000);
      }
    }
    await poll();
  }
  return { columns };
})();
