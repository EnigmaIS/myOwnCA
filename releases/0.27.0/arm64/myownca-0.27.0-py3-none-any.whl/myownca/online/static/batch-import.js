/* Authenticated portal view. All displayed results come from persisted operations. */
(() => {
  const base = "/internal/batch-import";
  let selected = null;
  let offset = 0;
  let timer = null;
  const runVisibility = new Map([
    ["draft", true], ["review", true], ["ready", true], ["running", true],
    ["paused", true], ["completed", false], ["rejected", false],
  ]);
  let generation = 0;
  // User navigation invalidates actions; action refreshes only supersede reads.
  let navigationGeneration = 0;
  let feedback = null;
  const executions = new Map();
  let refreshExecutionButton = () => {};
  const api = (...args) => myOwnCA.api(...args);
  const node = (tag, text, parent) => {
    const el = document.createElement(tag);
    if (text !== undefined) el.textContent = text;
    if (parent) parent.append(el);
    return el;
  };
  const confirmations = {
    "Upload and validate": "CSV uploaded and validation results saved.",
    "Approve revision": "Approval recorded.",
    "Confirm CSV and approve": "CSV confirmation and approval recorded.",
    "Reject revision": "Rejection recorded.",
    "Replace CSV": "Replacement CSV saved.",
    "Change certificate settings": "Certificate settings saved.",
    "Import & pre-generate certificates": "Import request accepted.",
    "Resume paused work": "Resume request accepted.",
    "Retry failed or paused work": "Retry request accepted.",
    "Cancel record": "Record cancellation saved.",
  };
  const visible = context => context.navigation === navigationGeneration &&
    !document.querySelector("#view-batch-import").hidden;
  function clearFeedback() {
    feedback = null;
    const host = document.querySelector("#batch-import-feedback");
    host.replaceChildren(); host.hidden = true;
  }
  function showFeedback(context, title, message, error = false) {
    if (!visible(context)) return;
    feedback = { ...context, title, message, error };
    const host = document.querySelector("#batch-import-feedback");
    host.replaceChildren(); host.hidden = false;
    const box = panel(feedback.title, feedback.error ? "error" : "success", host);
    box.id = error ? "batch-import-error" : "batch-import-result";
    box.setAttribute("role", error ? "alert" : "status");
    box.setAttribute("aria-live", error ? "assertive" : "polite");
    box.tabIndex = -1;
    node("p", feedback.message, box);
    if (context.record) node("p", `Record ${context.record}`, box);
    if (context.sessionId) node("p", `Session ${context.sessionId} · Revision ${context.revision}`, box);
    if (message === "Inventory conflicts require a new revision") {
      node("p", "Review existing holders, then use Edit revision to replace conflicting records. Both approvals will be required again.", box);
    }
    if (error) box.focus({ preventScroll: true });
    box.scrollIntoView({ block: "nearest" });
  }
  async function sendMutation(context, path, options, createdRevision = null) {
    context.sent = true;
    const result = await api(path, options);
    context.confirmed = true;
    if (createdRevision !== null && result?.id) {
      // The response snapshot may already include another operator's later revision.
      context.sessionId = result.id; context.revision = createdRevision;
    }
    return result;
  }
  async function refreshView(id, context) {
    if (!visible(context)) return false;
    try { return Boolean(await open(id)); }
    catch (error) {
      if (!visible(context)) return;
      const host = document.querySelector("#batch-import-feedback");
      host.hidden = false;
      document.querySelector("#batch-refresh-warning")?.remove();
      const warning = panel("Session refresh unavailable", "error", host);
      warning.id = "batch-refresh-warning"; warning.setAttribute("role", "alert");
      node("p", `Displayed session data may be out of date. ${error.message || error}`, warning);
      return false;
    }
  }
  const panel = (title, kind, parent) => {
    const el = node("div", undefined, parent);
    el.className = `batch-notice batch-notice-${kind}`;
    node("strong", title, el);
    return el;
  };
  const button = (label, parent, run, available = () => true, inputs = []) => {
    const el = node("button", label, parent);
    el.type = "button";
    let busy = false;
    const update = () => { el.disabled = busy || !available(); };
    for (const input of inputs) {
      input.addEventListener("input", update);
      input.addEventListener("change", update);
    }
    update();
    el.onclick = async () => {
      update();
      if (el.disabled) return;
      clearFeedback();
      const context = { navigation: navigationGeneration, sessionId: selected?.id,
        revision: selected?.revision, sent: false, confirmed: false };
      busy = true; update();
      try {
        const outcome = await run(context);
        if (confirmations[label] && outcome && visible(context)) {
          if (outcome.sessionId !== selected?.id) {
            navigationGeneration++; context.navigation = navigationGeneration;
          }
          showFeedback(context, `${label} — result`, confirmations[label]);
          await refreshView(outcome.sessionId, context);
        }
      } catch (error) {
        const unknown = context.sent && !context.confirmed && !(error.status >= 400 && error.status < 500);
        const suffix = unknown ? "outcome unconfirmed" : context.confirmed ? "response check failed" : "failed";
        showFeedback(context, `${label} — ${suffix}`, error.message || String(error), true);
      }
      finally { busy = false; update(); }
    };
    return el;
  };
  const canMutate = () => Boolean(myOwnCA.currentUser?.user_id && myOwnCA.currentUser.role === "superuser");
  const mutationButton = (label, parent, run, available = () => true, inputs = []) =>
    button(label, parent, run, () => canMutate() && available(), inputs);
  const input = (label, parent, type = "text") => {
    const wrap = node("label", label, parent);
    const el = node("input", undefined, wrap);
    el.type = type;
    return el;
  };
  function certificateSettings(parent, templates, current = null) {
    const prefix = current ? "Revision " : "";
    const template = node("select", undefined, node("label", `${prefix}Certificate template`, parent));
    template.setAttribute("aria-label", `${prefix}Certificate template`);
    for (const item of templates) {
      const option = node("option", `${item.name} (${item.id})`, template); option.value = item.id;
    }
    if (current && !templates.some(item => item.id === current.template.id)) {
      const missing = node("option", `${current.template.id} (unavailable)`, template);
      missing.value = current.template.id;
    }
    if (current) template.value = current.template.id;
    const algorithm = node("select", undefined, node("label", `${prefix}Key algorithm`, parent));
    algorithm.setAttribute("aria-label", `${prefix}Key algorithm`);
    const refreshAlgorithms = () => {
      const allowed = templates.find(item => item.id === template.value)?.allowed_key_algorithms || [];
      algorithm.replaceChildren();
      for (const name of allowed) {
        const option = node("option", name, algorithm); option.value = name;
      }
      if (allowed.includes("ecdsa-p256")) algorithm.value = "ecdsa-p256";
    };
    template.onchange = refreshAlgorithms;
    refreshAlgorithms();
    if (current) {
      if (![...algorithm.options].some(option => option.value === current.algorithm)) {
        const missing = node("option", `${current.algorithm} (unavailable)`, algorithm);
        missing.value = current.algorithm;
      }
      algorithm.value = current.algorithm;
    }
    return { template, algorithm };
  }
  function renderHistory(evidence, root) {
    const history = node("details", undefined, root); node("summary", "Review history", history);
    if (!evidence.length) { node("p", "No review history yet.", history); return; }
    const scroll = node("div", undefined, history); scroll.className = "table-scroll";
    const table = node("table", undefined, scroll); table.setAttribute("aria-label", "Review history");
    const head = node("tr", undefined, node("thead", undefined, table));
    for (const label of ["Revision", "Action", "Operator ID", "Time", "Statement"]) node("th", label, head).scope = "col";
    const body = node("tbody", undefined, table);
    const labels = {
      first_approval: "First approval", second_approval: "Second approval", rejected: "Rejected",
      duplicate_operator_denied: "Same-operator confirmation denied", file_mismatch: "CSV mismatch — rejected",
      execute: "Import started", retry: "Retry requested", record_canceled: "Record canceled",
    };
    for (const entry of evidence) {
      const row = node("tr", undefined, body);
      for (const value of [entry.revision, labels[entry.action] || entry.action, entry.operator_id, entry.created_at, entry.statement]) {
        node("td", value || "", row);
      }
    }
  }
  function renderRevisionEditor(session, templates, root, toggle) {
    const editor = node("section", undefined, root); editor.className = "batch-revision-editor";
    editor.id = "batch-revision-editor";
    editor.hidden = true;
    toggle.type = "button";
    toggle.disabled = !canMutate();
    toggle.setAttribute("aria-controls", editor.id);
    toggle.setAttribute("aria-expanded", "false");
    toggle.onclick = () => {
      if (!canMutate()) return;
      editor.hidden = !editor.hidden;
      toggle.setAttribute("aria-expanded", String(!editor.hidden));
    };
    node("h3", "Edit revision", editor);
    node("p", "Saving changes creates a new revision. Both approvals will be required again.", editor);
    const replacement = node("div", undefined, editor); replacement.className = "batch-revision-section";
    node("h3", "Replace CSV", replacement);
    const source = input("Replacement CSV", replacement, "file"); source.accept = ".csv,text/csv";
    const replaceActions = node("div", undefined, replacement); replaceActions.className = "actions";
    mutationButton("Replace CSV", replaceActions, async (operation) => {
      const file = await fileBytes(source.files[0]);
      await sendMutation(operation, `${base}/${session.id}/source?revision=${session.revision}`, { method: "PUT", body: file.bytes }, session.revision + 1);
      return operationResult(session.id, operation);
    }, () => Boolean(source.files?.length), [source]);
    const settings = node("div", undefined, editor); settings.className = "batch-revision-section";
    node("h3", "Change certificate settings", settings);
    const fields = node("div", undefined, settings); fields.className = "batch-fields";
    const { template, algorithm } = certificateSettings(fields, templates, session.manifest);
    const actions = node("div", undefined, settings); actions.className = "actions";
    mutationButton("Change certificate settings", actions, async (operation) => {
      await sendMutation(operation, `${base}/${session.id}/settings`, { method: "PUT", body: JSON.stringify({
        revision: session.revision, template_id: template.value, algorithm: algorithm.value,
      }) }, session.revision + 1);
      return operationResult(session.id, operation);
    }, () => Boolean(templates.find(item => item.id === template.value)?.allowed_key_algorithms?.includes(algorithm.value)), [template, algorithm]);
  }
  async function fileBytes(file) {
    if (!file || file.size > 10 * 1024 * 1024) throw new Error("Choose a CSV up to 10 MiB");
    const bytes = new Uint8Array(await file.arrayBuffer());
    const sum = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
    return { bytes, digest: Array.from(sum, b => b.toString(16).padStart(2, "0")).join("") };
  }
  async function open(id) {
    const requestEpoch = ++generation;
    let result;
    try { result = await api(`${base}/${encodeURIComponent(id)}`); }
    catch (error) { if (requestEpoch !== generation) return; throw error; }
    if (requestEpoch !== generation) return;
    if (executions.get(id)?.unknown) executions.delete(id);
    selected = result;
    offset = 0;
    const rendering = render();
    const renderEpoch = generation;
    try { await rendering; }
    catch (error) { if (renderEpoch !== generation) return; throw error; }
    if (renderEpoch !== generation) return;
    document.querySelector("#batch-refresh-warning")?.remove();
    return { sessionId: result.id, revision: result.revision, generation: renderEpoch };
  }
  function operationResult(id, context) {
    return { sessionId: id, revision: context.revision };
  }
  async function render() {
    clearTimeout(timer);
    const epoch = ++generation;
    refreshExecutionButton = () => {};
    const root = document.querySelector("#batch-import-root");
    root.replaceChildren();
    node("p", "Loading batch import…", root);
    const capability = await api(`${base}/capability`);
    if (epoch !== generation) return;
    root.replaceChildren();
    if (!capability.batch_import) {
      node("p", "Batch import requires a currently valid commercial license.", root);
      return;
    }
    if (capability.test_environment) node("p", "Test environment", root).className = "status-pill";
    const create = node("section", undefined, root);
    node("h2", "New batch import", create);
    const fields = node("div", undefined, create); fields.className = "batch-fields";
    const entity = node("select", undefined, node("label", "Entity type", fields));
    for (const kind of ["devices", "people"]) {
      const option = node("option", kind, entity); option.value = kind;
    }
    entity.setAttribute("aria-label", "Entity type");
    const templates = await api("/internal/templates");
    if (epoch !== generation) return;
    const { template, algorithm } = certificateSettings(fields, templates);
    const source = input("Source CSV", fields, "file"); source.accept = ".csv,text/csv";
    const createActions = node("div", undefined, create); createActions.className = "actions";
    mutationButton("Upload and validate", createActions, async (operation) => {
      const file = await fileBytes(source.files[0]);
      const query = new URLSearchParams({ entity_type: entity.value, template_id: template.value, algorithm: algorithm.value });
      const result = await sendMutation(operation, `${base}?${query}`, { method: "POST", body: file.bytes }, 1);
      if (file.digest !== result.digest) throw new Error("Browser and backend digests differ");
      return operationResult(result.id, operation);
    });
    const list = node("section", undefined, root); node("h2", "Sessions", list);
    const sessions = await api(base);
    if (epoch !== generation) return;
    const filters = node("div", undefined, list); filters.className = "batch-run-filters";
    for (const [state, shown] of runVisibility) {
      const control = input(`Show ${state} runs`, filters, "checkbox");
      control.parentElement.className = "batch-checkbox";
      control.checked = shown;
      control.onchange = () => { runVisibility.set(state, control.checked); renderSessions(); };
    }
    const sessionRows = node("div", undefined, list); sessionRows.className = "table-scroll";
    const renderSessions = () => {
      sessionRows.replaceChildren();
      const visible = sessions.filter(session => runVisibility.get(session.state) !== false);
      if (!visible.length) {
        node("p", "No sessions match the current filter.", sessionRows);
        return;
      }
      const table = node("table", undefined, sessionRows);
      table.setAttribute("aria-label", "Batch import sessions");
      const head = node("tr", undefined, node("thead", undefined, table));
      for (const label of ["Session ID", "Revision", "Status", "Action"]) {
        node("th", label, head).scope = "col";
      }
      const body = node("tbody", undefined, table);
      for (const session of visible) {
        const row = node("tr", undefined, body);
        for (const value of [session.id, session.revision, session.state]) node("td", value, row);
        const openButton = button("Open", node("td", undefined, row), (context) => {
          navigationGeneration++; clearFeedback();
          context.navigation = navigationGeneration;
          context.sessionId = session.id; context.revision = session.revision;
          return open(session.id);
        });
        openButton.setAttribute("aria-label", `Open session ${session.id}`);
      }
    };
    renderSessions();
    if (!selected) return;
    const s = selected;
    node("h2", "Dual-control review", root);
    const sessionHeading = node("p", `Session ${s.id} · Revision ${s.revision} · ${s.state}`, root);
    const hash = node("p", `SHA-256: ${s.digest}`, root); hash.style.overflowWrap = "anywhere";
    const invalidRows = new Set(s.issues.flatMap(issue => issue.rows || (issue.row ? [issue.row] : [])));
    const validCount = s.manifest.records.filter(record => !invalidRows.has(record.row)).length;
    const validation = panel(s.issues.length ? "Validation issues" : "Validation results", s.issues.length ? "error" : "info", root);
    node("p", `${s.manifest.records.length} records · ${validCount} valid · ${s.issues.length} validation issues`, validation);
    if (s.issues.length) node("pre", JSON.stringify(s.issues, null, 2), validation);
    const preview = node("details", undefined, root); node("summary", "Resolved certificate identities and configuration", preview);
    const review = node("pre", JSON.stringify(s.manifest, null, 2), preview); review.style.maxHeight = "24rem"; review.style.overflow = "auto";
    renderHistory(s.evidence, root);
    const first = s.evidence.find(e => e.revision === s.revision && e.action === "first_approval");
    const selfApproved = Boolean(first && first.operator_id === myOwnCA.currentUser?.user_id);
    let stage;
    if (s.state === "draft") stage = "Awaiting first approval.";
    else if (s.state === "review") stage = selfApproved
      ? "You approved this revision. A different Certificate Operator must confirm it."
      : `First approval: ${first?.operator_id || "unavailable"}. Independently review this revision and upload the identical CSV.`;
    else if (s.state === "ready") stage = "Both approvals complete. Ready to import.";
    else if (s.state === "rejected") stage = "Rejected. Use Edit revision to continue.";
    else if (s.state === "running") stage = "Import and certificate generation are in progress.";
    else if (s.state === "paused") stage = "Processing is paused. Inspect the report, resolve the cause, then resume paused work.";
    else stage = "Processing pass finished. Inspect the report for failed or uncertain outcomes.";
    const workflow = panel("Workflow status", "info", root);
    const status = node("p", stage, workflow);
    status.id = "batch-review-status"; status.setAttribute("role", "status");
    if (first && (selfApproved || s.state !== "review")) node("p", `First approval: ${first.operator_id}`, root);
    if (s.issues.length && ["draft", "review"].includes(s.state)) {
      node("p", "Resolve validation issues before approval.", root);
    }
    if (!canMutate()) node("p", myOwnCA.currentUser?.user_id
      ? "Only Certificate Operators can change batch imports."
      : "Your operator identity is unavailable. Reload the page or sign in again.", root);
    let statement;
    let editToggle;
    const action = async (path, operation) => {
      if (path === "execute" && executions.has(s.id)) return;
      const executing = path === "execute";
      let elapsedTimer;
      const execution = { unknown: false };
      if (executing) {
        executions.set(s.id, execution);
        const began = Date.now();
        status.textContent = "";
        const importing = node("progress", undefined, status);
        importing.setAttribute("aria-label", `Importing ${s.manifest.entity_type || "devices"}`);
        const elapsed = node("span", ` Importing ${s.manifest.entity_type || "devices"}… 0s elapsed`, status);
        const updateElapsed = () => {
          elapsed.textContent = ` Importing ${s.manifest.entity_type || "devices"}… ${Math.floor((Date.now() - began) / 1000)}s elapsed`;
          elapsedTimer = setTimeout(updateElapsed, 1000);
        };
        updateElapsed();
      }
      try {
        await sendMutation(operation, `${base}/${s.id}/${path}`, { method: "POST", body: JSON.stringify({ revision: s.revision, statement: statement?.value || "" }) });
        return operationResult(s.id, operation);
      } catch (error) {
        if (executing) {
          try {
            const current = await api(`${base}/${s.id}/progress`);
            if (current.state !== "ready") {
              if (!await refreshView(s.id, operation)) {
                execution.unknown = true;
                status.textContent = "Import status is unavailable. Reopen this session to check before trying again.";
              }
              return false;
            }
            status.textContent = "Import did not start. Review the error before trying again.";
          } catch (_) {
            status.textContent = "Import status is unavailable. Reopen this session to check before trying again.";
            // Keep execution disabled until the session has been reloaded.
            execution.unknown = true;
            throw error;
          }
        }
        throw error;
      } finally {
        clearTimeout(elapsedTimer);
        if (executing && executions.get(s.id) === execution && !execution.unknown) {
          executions.delete(s.id);
        }
        refreshExecutionButton();
      }
    };
    if (["draft", "review", "ready"].includes(s.state)) {
      statement = input("Review statement (required for approval or rejection)", root);
      statement.maxLength = 2000;
      const validStatement = () => Boolean(statement.value.trim()) && statement.value.length <= 2000;
      let confirmation;
      if (s.state === "review" && first && !selfApproved && canMutate()) {
        confirmation = input("Identical CSV for second approval", root, "file");
        confirmation.accept = ".csv,text/csv";
        node("p", "The CSV must match byte for byte, including line endings and BOM. A mismatch rejects this revision.", root);
      }
      const requirements = node("p", undefined, root);
      requirements.id = "batch-review-requirements";
      requirements.setAttribute("aria-live", "polite");
      statement.setAttribute("aria-describedby", requirements.id);
      confirmation?.setAttribute("aria-describedby", requirements.id);
      const updateRequirements = () => {
        const reasons = [];
        if (!statement.value.trim()) reasons.push(s.state === "draft" || confirmation
          ? "Enter a review statement to enable approval or rejection."
          : "Enter a review statement to enable rejection.");
        else if (statement.value.length > 2000) reasons.push("The review statement must be at most 2,000 characters.");
        if (confirmation && !confirmation.files?.length) reasons.push("Choose the identical CSV to enable confirmation.");
        requirements.textContent = reasons.join(" ");
        requirements.hidden = !reasons.length;
      };
      statement.addEventListener("input", updateRequirements);
      confirmation?.addEventListener("change", updateRequirements);
      updateRequirements();
      const actions = node("div", undefined, root); actions.className = "actions";
      if (s.state === "draft" && !first) {
        mutationButton("Approve revision", actions, (operation) => action("approve", operation),
          () => validStatement() && !s.issues.length, [statement]);
      }
      if (confirmation) {
        mutationButton("Confirm CSV and approve", actions, async (operation) => {
          const file = await fileBytes(confirmation.files[0]);
          const query = new URLSearchParams({ revision: s.revision, statement: statement.value });
          try { await sendMutation(operation, `${base}/${s.id}/confirm?${query}`, { method: "POST", body: file.bytes }); }
          catch (error) { await refreshView(s.id, operation); throw error; }
          return operationResult(s.id, operation);
        }, () => validStatement() && !s.issues.length && Boolean(confirmation.files?.length), [statement, confirmation]);
      }
      mutationButton("Reject revision", actions, (operation) => action("reject", operation), validStatement, [statement]);
      editToggle = node("button", "Edit revision", actions);
      if (s.state === "ready") {
        const execute = mutationButton("Import & pre-generate certificates", actions, (operation) => action("execute", operation), () => !executions.has(s.id));
        refreshExecutionButton = () => { execute.disabled = !canMutate() || executions.has(s.id); };
      }
    }
    if (["draft", "review", "ready", "rejected"].includes(s.state)) {
      if (!editToggle) {
        const actions = node("div", undefined, root); actions.className = "actions";
        editToggle = node("button", "Edit revision", actions);
      }
      renderRevisionEditor(s, templates, root, editToggle);
    }
    if (!["running", "paused", "completed"].includes(s.state)) return;
    const recovery = node("div", undefined, root); recovery.className = "actions";
    const updateRecovery = () => {
      recovery.replaceChildren();
      if (s.state === "paused" || (s.state === "completed" && ((s.progress?.failed || 0) + (s.progress?.paused || 0) > 0))) {
        mutationButton(s.state === "paused" ? "Resume paused work" : "Retry failed or paused work", recovery, (operation) => action("retry", operation));
      }
    };
    updateRecovery();
    const progressPanel = node("div", undefined, root);
    const meter = node("progress", undefined, progressPanel);
    meter.setAttribute("aria-label", "Certificates generated");
    const counts = node("p", undefined, progressPanel);
    counts.setAttribute("role", "status");
    const freshness = node("p", undefined, progressPanel);
    let lastUpdate = null;
    const updateProgress = (current) => {
      const total = current.total ?? s.manifest.records.length;
      meter.max = total || 1;
      meter.value = current.progress?.completed || 0;
      counts.textContent = `${meter.value} of ${total} certificates generated · ` +
        Object.entries(current.progress || {}).map(([state, count]) => `${count} ${state}`).join(" · ");
      lastUpdate = new Date().toLocaleTimeString();
      freshness.className = "batch-notice batch-notice-info";
      freshness.textContent = `Progress updates available · Last updated ${lastUpdate}`;
    };
    updateProgress(s);
    node("h2", "Generation report", root);
    node("p", "Completed records remain unchanged. Uncertain signing outcomes require operator reconciliation through existing certificate workflows.", root);
    const reportFields = node("div", undefined, root); reportFields.className = "batch-fields";
    const search = input("Search holder records", reportFields);
    const filter = node("select", undefined, node("label", "Record status", reportFields)); filter.setAttribute("aria-label", "Record status");
    for (const state of ["", "pending", "preparing", "signing", "cloud_queued", "completed", "failed", "paused", "uncertain", "canceled"]) {
      const option = node("option", state || "All statuses", filter); option.value = state;
    }
    const searchActions = node("div", undefined, reportFields); searchActions.className = "actions";
    const rows = node("div", undefined, root); rows.style.overflowX = "auto";
    const load = async () => {
      const query = new URLSearchParams({ search: search.value, state: filter.value, limit: 100, offset });
      const result = await api(`${base}/${s.id}/records?${query}`);
      if (epoch !== generation || document.querySelector("#view-batch-import").hidden ||
          rows.contains(document.activeElement) ||
          query.get("search") !== search.value || query.get("state") !== filter.value ||
          Number(query.get("offset")) !== offset) return false;
      rows.replaceChildren();
      node("p", `${result.total} matching records · offset ${offset}`, rows);
      const table = node("table", undefined, rows); table.style.minWidth = "760px";
      const head = node("tr", undefined, node("thead", undefined, table));
      for (const label of ["Holder", "Status", "Attempts", "Certificate ID", "Failure reason", "Cancellation"]) node("th", label, head);
      const body = node("tbody", undefined, table);
      for (const record of result.records) {
        const tr = node("tr", undefined, body);
        for (const value of [record.record.holder.unique_id, record.state, record.attempts, record.certificate_id || "", record.failure_reason]) node("td", value, tr);
        const cancellation = node("td", undefined, tr);
        if (canMutate() && ["pending", "preparing", "failed", "paused"].includes(record.state)) {
          const reason = input(`Cancellation reason for ${record.record.holder.unique_id}`, cancellation);
          reason.maxLength = 2000;
          const leased = record.lease_until && Date.parse(record.lease_until) > Date.now();
          if (leased) node("p", "An active worker lease must finish before cancellation.", cancellation);
          mutationButton("Cancel record", cancellation, async (operation) => {
            operation.record = record.record.holder.unique_id;
            await sendMutation(operation, `${base}/${s.id}/records/${record.id}/cancel`, { method: "POST", body: JSON.stringify({
              revision: s.revision, statement: reason.value,
            }) });
            return operationResult(s.id, operation);
          }, () => !leased && Boolean(reason.value.trim()), [reason]);
        }

      }
      return true;
    };
    button("Search / filter", searchActions, async () => { offset = 0; await load(); });
    const pagination = node("div", undefined, root); pagination.className = "actions";
    button("Previous page", pagination, async () => { offset = Math.max(0, offset - 100); await load(); });
    button("Next page", pagination, async () => { offset += 100; await load(); });
    const download = async (filtered) => {
      const query = new URLSearchParams(filtered ? { search: search.value, state: filter.value } : {});
      const result = await myOwnCA.apiDownload(`${base}/${s.id}/report.csv?${query}`);
      myOwnCA.fileDownload(result.filename, result.blob);
    };
    const downloads = node("div", undefined, root); downloads.className = "actions";
    button("Download all records CSV", downloads, () => download(false));
    button("Download filtered CSV", downloads, () => download(true));
    await load();
    if (epoch !== generation || document.querySelector("#view-batch-import").hidden) return;
    const poll = async () => {
      if (epoch !== generation || document.querySelector("#view-batch-import").hidden) return;
      let again = true;
      try {
        const current = await api(`${base}/${s.id}/progress`);
        if (epoch !== generation || document.querySelector("#view-batch-import").hidden) return;
        updateProgress(current);
        const editing = rows.contains(document.activeElement);
        if (current.revision !== s.revision) { await open(s.id); return; }
        if (current.state !== s.state) {
          s.state = current.state;
          s.progress = current.progress;
          selected = s;
          sessionHeading.textContent = `Session ${s.id} · Revision ${s.revision} · ${s.state}`;
          status.textContent = s.state === "completed"
            ? "Processing finished. Inspect the report for failed or uncertain outcomes."
            : s.state === "paused" ? "Processing is paused. Inspect the report, resolve the cause, then resume paused work."
            : "Import and certificate generation are in progress.";
        }
        s.progress = current.progress;
        updateRecovery();
        const reportApplied = !editing && await load();
        again = current.state === "running" || !reportApplied;
      } catch (error) {
        if (epoch !== generation) return;
        freshness.className = "batch-notice batch-notice-error";
        freshness.textContent = `Updates unavailable: ${error.message || error}. Last updated ${lastUpdate || "never"}. Retrying…`;
      } finally {
        if (again && epoch === generation && !document.querySelector("#view-batch-import").hidden) {
          timer = setTimeout(poll, 5000);
        }
      }
    };
    if (s.state === "running") timer = setTimeout(poll, 5000);
  }
  window.loadBatchImport = async () => {
    const navigation = ++navigationGeneration;
    clearFeedback();
    const opening = Boolean(selected);
    let loadGeneration;
    try {
      const loading = opening ? open(selected.id) : render();
      loadGeneration = generation;
      await loading;
    } catch (error) {
      if ((!opening && loadGeneration !== generation) ||
          navigation !== navigationGeneration ||
          document.querySelector("#view-batch-import").hidden) return;
      const root = document.querySelector("#batch-import-root");
      root.textContent = `Batch import could not load: ${error.message || error}. Select Batch import again to retry.`;
      throw error;
    }
  };
})();
