"""Request-local, ID-scoped display lookups; never used for authorization."""
from collections import defaultdict
import json
from types import SimpleNamespace

from myownca.domain import (
    ApprovalRecord, CertificateTemplate, CertificateProfile, KeyUsageName, ExtendedKeyUsageName,
    User, Role,
)
from myownca.storage.repositories import (
    RepositoryError, _load_dt, _person_from_row, _device_from_row,
)

CHUNK_SIZE = 500


def _rows(connection, select, column, ids, order=""):
    ids = sorted({value for value in ids if value is not None})
    result = []
    for offset in range(0, len(ids), CHUNK_SIZE):
        chunk = ids[offset:offset + CHUNK_SIZE]
        placeholders = ",".join("?" for _ in chunk)
        result.extend(connection.execute(
            f"{select} WHERE {column} IN ({placeholders}) {order}", chunk
        ).fetchall())
    return result


def _template(row):
    return CertificateTemplate(
        id=row['id'], name=row['name'], profile=CertificateProfile(row['profile']),
        validity_days=row['validity_days'],
        first_issuance_approvals=row['first_issuance_approvals'],
        renewal_approvals=row['renewal_approvals'],
        key_usages=tuple(KeyUsageName(v) for v in json.loads(row['key_usages_json'])),
        extended_key_usages=tuple(ExtendedKeyUsageName(v) for v in
                                 json.loads(row['extended_key_usages_json'])),
        key_usage_critical=bool(row['key_usage_critical']),
        extended_key_usage_critical=bool(row['extended_key_usage_critical']),
        allowed_key_algorithms=tuple(json.loads(row['allowed_key_algorithms_json'])),
    )


class ListDisplay:
    def __init__(self, repository, records, *, requests=False):
        records = list(records)
        self.templates = {}
        self.users = {}
        self.people = {}
        self.devices = {}
        self.requests = {v.id: v for v in records} if requests else {}
        self.approvals = defaultdict(list)
        self.issued = {}
        self.acme = {}
        self.batch = {}
        self.orders = defaultdict(list)
        self.auto_approve = False
        self.held = set()
        if not records:
            return
        request_ids = [v.id if requests else v.request_id for v in records]
        user_ids = set()
        with repository.database.connect() as c:
            if not requests:
                for r in _rows(c, 'SELECT id, requested_by_user_id FROM certificate_requests',
                               'id', request_ids):
                    self.requests[r['id']] = SimpleNamespace(**dict(r))
            for v in self.requests.values():
                user_ids.add(v.requested_by_user_id)
            for r in _rows(c, 'SELECT * FROM certificate_templates', 'id',
                           [v.template_id for v in records]):
                self.templates[r['id']] = _template(r)
            person_ids = {v.holder_person_id for v in records}
            for r in _rows(c, 'SELECT * FROM devices', 'id',
                           [v.holder_device_id for v in records]):
                self.devices[r['id']] = _device_from_row(r)
                person_ids.add(r['admin_id'])
            for r in _rows(c, 'SELECT * FROM people', 'id', person_ids):
                self.people[r['id']] = _person_from_row(r)
            held = _rows(c,
                "SELECT r.request_id FROM request_private_keys r "
                "LEFT JOIN certificate_requests q ON q.id = r.request_id "
                "LEFT JOIN key_lifecycle_keys k ON k.id = q.key_registry_id",
                'r.request_id', request_ids,
                "AND (k.id IS NULL OR k.status = 'active')")
            self.held = {r['request_id'] for r in held}
            if requests:
                for r in _rows(c, 'SELECT * FROM approvals', 'request_id', request_ids,
                               'ORDER BY approved_at'):
                    self.approvals[r['request_id']].append(ApprovalRecord(
                        request_id=r['request_id'], superuser_id=r['superuser_id'],
                        approved_at=_load_dt(r['approved_at'])))
                    user_ids.add(r['superuser_id'])
                for r in _rows(c, 'SELECT request_id, serial_number FROM certificate_inventory',
                               'request_id', request_ids):
                    self.issued[r['request_id']] = SimpleNamespace(**dict(r))
                for r in _rows(c, 'SELECT request_id, origin, account_id FROM acme_server_requests',
                               'request_id', request_ids):
                    self.acme[r['request_id']] = dict(r)
                for r in _rows(c, 'SELECT id, request_id FROM acme_server_orders',
                               'request_id', request_ids, 'ORDER BY created_at, id'):
                    self.orders[r['request_id']].append(r['id'])
                for r in _rows(c, 'SELECT request_id, session_id, revision, row_number '
                               'FROM batch_records', 'request_id', request_ids):
                    self.batch[r['request_id']] = dict(r)
                if self.acme:
                    row = c.execute("SELECT value FROM online_settings "
                                    "WHERE key = 'acme_server_auto_approve'").fetchone()
                    self.auto_approve = row is not None and row['value'] == 'true'
            for r in _rows(c, 'SELECT * FROM users', 'id', user_ids):
                self.users[r['id']] = User(id=r['id'], email=r['email'], role=Role(r['role']),
                                          is_active=bool(r['is_active']))

    @staticmethod
    def _get(values, key):
        try:
            return values[key]
        except KeyError as exc:
            raise RepositoryError(f'Unknown display record: {key}') from exc

    def get_template(self, key):
        return self._get(self.templates, key)

    def get_user(self, key):
        return self._get(self.users, key)

    def get_person(self, key):
        return self._get(self.people, key)

    def get_device(self, key):
        return self._get(self.devices, key)

    def get_request(self, key):
        return self._get(self.requests, key)

    def list_approvals(self, key):
        return self.approvals[key]

    def get_issued_certificate_by_request_id(self, key):
        return self.issued.get(key)

    def has_request_private_key(self, key):
        return key in self.held
