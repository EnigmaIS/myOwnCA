CREATE TABLE mass_jobs (
 id TEXT PRIMARY KEY,
 actor_id TEXT NOT NULL REFERENCES users(id),
 action TEXT NOT NULL,
 reason TEXT NOT NULL,
 payload_hash TEXT NOT NULL,
 state TEXT NOT NULL,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE TABLE mass_items (
 job_id TEXT NOT NULL REFERENCES mass_jobs(id),
 target_id TEXT NOT NULL,
 state TEXT NOT NULL,
 message TEXT NOT NULL,
 PRIMARY KEY(job_id, target_id)
);
CREATE INDEX idx_mass_items_pending ON mass_items(job_id, state, target_id);
CREATE INDEX idx_mass_jobs_queue ON mass_jobs(state, created_at, id);
