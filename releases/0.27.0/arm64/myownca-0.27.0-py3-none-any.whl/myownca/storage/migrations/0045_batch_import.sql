CREATE TABLE batch_sessions (
    id TEXT PRIMARY KEY,
    revision INTEGER NOT NULL,
    state TEXT NOT NULL,
    created_at TEXT NOT NULL,
    created_by TEXT NOT NULL REFERENCES users(id)
);
CREATE TABLE batch_revisions (
    session_id TEXT NOT NULL REFERENCES batch_sessions(id),
    revision INTEGER NOT NULL,
    digest TEXT NOT NULL,
    manifest TEXT NOT NULL,
    manifest_digest TEXT NOT NULL,
    issues TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY(session_id, revision)
);
CREATE TABLE batch_evidence (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL REFERENCES batch_sessions(id),
    revision INTEGER NOT NULL,
    action TEXT NOT NULL,
    operator_id TEXT NOT NULL REFERENCES users(id),
    digest TEXT NOT NULL,
    manifest_digest TEXT NOT NULL,
    statement TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE batch_records (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL REFERENCES batch_sessions(id),
    revision INTEGER NOT NULL,
    row_number INTEGER NOT NULL,
    record TEXT NOT NULL,
    state TEXT NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    request_id TEXT UNIQUE REFERENCES certificate_requests(id),
    lease_token TEXT,
    lease_until TEXT,
    failure_reason TEXT NOT NULL DEFAULT '',
    certificate_id TEXT,
    certificate_serial TEXT,
    generated_at TEXT,
    UNIQUE(session_id, revision, row_number)
);
CREATE INDEX idx_batch_records_work ON batch_records(state, lease_until);
CREATE INDEX idx_batch_evidence_revision ON batch_evidence(session_id, revision);
