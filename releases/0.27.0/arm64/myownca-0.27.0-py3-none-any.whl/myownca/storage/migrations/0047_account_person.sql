-- Permanent holder identity; email reuse never transfers account ownership.
ALTER TABLE users ADD COLUMN person_id TEXT REFERENCES people(id);
CREATE UNIQUE INDEX idx_users_person ON users(person_id);
