"""Resumable device archive schema and guards for active assignments."""


def migrate_devices(c, dialect):
    columns = (
        {r["name"] for r in c.execute("PRAGMA table_info(devices)").fetchall()}
        if dialect == "sqlite"
        else {r["Field"] for r in c.execute("SHOW COLUMNS FROM devices").fetchall()}
    )
    if "archived_at" not in columns:
        c.execute(
            "ALTER TABLE devices ADD COLUMN archived_at "
            + ("TEXT" if dialect == "sqlite" else "LONGTEXT NULL")
        )
    existing = (
        set()
        if dialect == "sqlite"
        else {
            r["TRIGGER_NAME"]
            for r in c.execute(
                "SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE()"
            ).fetchall()
        }
    )
    for table, column, live in (
        ("certificate_requests", "holder_device_id", "NEW.status = 'pending'"),
        ("certificate_inventory", "holder_device_id", "NEW.archived_at IS NULL"),
        ("acme_server_authorizations", "device_id", "NEW.enabled = 1"),
        ("acme_server_credentials", "authorization_id", "NEW.enabled = 1"),
        (
            "secure_links",
            "certificate_id",
            "NEW.revoked_at IS NULL OR NEW.otp_hash IS NOT NULL OR NEW.session_token_hash IS NOT NULL",
        ),
    ):
        for operation in ("INSERT", "UPDATE"):
            name = f"active_device_{table}_{operation.lower()}"
            condition = (
                "1 = 1"
                if operation == "INSERT"
                else f"(OLD.{column} IS NULL OR NEW.{column} <> OLD.{column} OR {live})"
            )
            reference = f"NEW.{column}"
            if table == "acme_server_credentials":
                reference = "(SELECT device_id FROM acme_server_authorizations WHERE id = NEW.authorization_id)"
            elif table == "secure_links":
                reference = "(SELECT holder_device_id FROM certificate_inventory WHERE certificate_id = NEW.certificate_id)"
            if name in existing:
                continue
            if dialect == "sqlite":
                c.execute(
                    f"CREATE TRIGGER IF NOT EXISTS {name} BEFORE {operation} ON {table} "
                    f"WHEN {condition} AND EXISTS (SELECT 1 FROM devices WHERE id = {reference} "
                    "AND archived_at IS NOT NULL) BEGIN SELECT RAISE(ABORT, 'Archived devices are read-only'); END"
                )
            else:
                c.execute(
                    f"CREATE TRIGGER {name} BEFORE {operation} ON {table} FOR EACH ROW BEGIN "
                    "DECLARE retired LONGTEXT; "
                    f"SELECT archived_at INTO retired FROM devices WHERE id = {reference} FOR UPDATE; "
                    f"IF retired IS NOT NULL AND {condition} THEN SIGNAL SQLSTATE '23000' SET MYSQL_ERRNO = 1452, "
                    "MESSAGE_TEXT = 'Archived devices are read-only'; END IF; END"
                )
    name = "archived_device_immutable"
    if name not in existing:
        if dialect == "sqlite":
            c.execute(
                f"CREATE TRIGGER IF NOT EXISTS {name} BEFORE UPDATE ON devices WHEN OLD.archived_at IS NOT NULL "
                "BEGIN SELECT RAISE(ABORT, 'Archived devices are read-only'); END"
            )
        else:
            c.execute(
                f"CREATE TRIGGER {name} BEFORE UPDATE ON devices FOR EACH ROW BEGIN "
                "IF OLD.archived_at IS NOT NULL THEN SIGNAL SQLSTATE '23000' SET MYSQL_ERRNO = 1452, "
                "MESSAGE_TEXT = 'Archived devices are read-only'; END IF; END"
            )
