"""Read-only People email compatibility checks shared with startup migration."""

from dataclasses import dataclass
from pathlib import Path
import sqlite3

from sqlalchemy import create_engine, inspect
from sqlalchemy.engine import make_url
from sqlalchemy.pool import NullPool

from myownca_core.storage.database import _Connection, sqlite_file_path


@dataclass(frozen=True)
class EmailConflict:
    email: str
    person_ids: tuple[str, ...]


def active_email_conflicts(connection, *, has_archived_at: bool) -> list[EmailConflict]:
    """Use the database's own comparison rules, exactly as the migration does."""
    active = " WHERE archived_at IS NULL" if has_archived_at else ""
    outer_active = " WHERE p.archived_at IS NULL" if has_archived_at else ""
    rows = connection.execute(
        "SELECT duplicates.email AS email, p.id FROM people p JOIN ("
        "SELECT lower(email) AS email FROM people" + active
        + " GROUP BY lower(email) HAVING count(*) > 1) duplicates "
        "ON lower(p.email) = duplicates.email" + outer_active
        + " ORDER BY duplicates.email, p.id"
    ).fetchall()
    groups = {}
    for row in rows:
        groups.setdefault(row["email"], []).append(row["id"])
    return [EmailConflict(email, tuple(ids)) for email, ids in groups.items()]


def check_active_email_conflicts(target: str | Path) -> list[EmailConflict]:
    """Inspect existing storage without creating files, migrating, or loading the app."""
    url = make_url(str(target)) if "://" in str(target) else make_url("sqlite://").set(
        database=str(Path(target).resolve())
    )
    dialect = url.get_backend_name()
    if dialect == "sqlite":
        args, kwargs = url.get_dialect()().create_connect_args(url)
        path = sqlite_file_path(args[0], uri=bool(kwargs.get("uri")))
        if path is None or not path.is_file():
            raise ValueError("Existing SQLite storage is required")
        # Rebuild the URI ourselves: never honor a supplied rwc/memory/immutable
        # mode, and include the live WAL while refusing to create a missing DB.
        uri = path.resolve().as_uri() + "?mode=ro"
        engine = create_engine(
            "sqlite://", creator=lambda: sqlite3.connect(uri, uri=True), poolclass=NullPool,
        )
    elif dialect in {"mysql", "mariadb"}:
        if not url.database:
            raise ValueError("An existing database must be configured")
        engine = create_engine(url, poolclass=NullPool)
    else:
        raise ValueError("Unsupported database backend")
    try:
        with engine.connect() as raw:
            if dialect == "sqlite":
                raw.exec_driver_sql("PRAGMA query_only = ON")
                raw.exec_driver_sql("BEGIN")
            else:
                raw.exec_driver_sql("SET TRANSACTION READ ONLY")
                raw.exec_driver_sql("START TRANSACTION WITH CONSISTENT SNAPSHOT")
            metadata = inspect(raw)
            columns = {column["name"] for column in metadata.get_columns("people")}
            if not {"id", "email"} <= columns:
                raise ValueError("People identity columns are missing")
            connection = _Connection(raw, dialect)
            applied = {row["version"] for row in connection.execute(
                "SELECT version FROM schema_migrations"
            ).fetchall()}
            if "0046_archive_people.sql" in applied and "archived_at" not in columns:
                raise ValueError("People migration is incomplete")
            return active_email_conflicts(connection, has_archived_at="archived_at" in columns)
    finally:
        engine.dispose()
