"""Backend-specific upgrade preserving the People primary keys and references."""
from myownca_core.storage.database import _Connection
from myownca.storage.database import IntegrityError
from myownca.storage.upgrade_checks import active_email_conflicts

VERSION = "0046_archive_people.sql"


def migrate_people(connection, dialect):
    columns = set()
    if dialect != "sqlite":
        columns = {row["Field"] for row in connection.execute("SHOW COLUMNS FROM people").fetchall()}
    conflicts = active_email_conflicts(connection, has_archived_at="archived_at" in columns)
    if conflicts:
        raise IntegrityError("Conflicting active People emails; resolve before migration")
    if dialect == "sqlite":
        connection.execute("CREATE TABLE people_archive_upgrade ("
                           "id TEXT PRIMARY KEY, name TEXT NOT NULL, surname TEXT NOT NULL, "
                           "email TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', "
                           "slack_handle TEXT NOT NULL DEFAULT '', company TEXT NOT NULL DEFAULT '', "
                           "comments TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, archived_at TEXT)")
        connection.execute("INSERT INTO people_archive_upgrade SELECT *, NULL FROM people")
        connection.execute("DROP TABLE people")
        connection.execute("ALTER TABLE people_archive_upgrade RENAME TO people")
        connection.execute("CREATE UNIQUE INDEX idx_people_active_email ON people(lower(email)) "
                           "WHERE archived_at IS NULL")
    else:
        # MySQL DDL commits implicitly; allow a startup interrupted between steps to resume.
        if "archived_at" not in columns:
            connection.execute("ALTER TABLE people ADD COLUMN archived_at LONGTEXT NULL")
        if "active_email" not in columns:
            connection.execute("ALTER TABLE people ADD COLUMN active_email VARCHAR(191) "
                               "GENERATED ALWAYS AS (CASE WHEN archived_at IS NULL "
                               "THEN lower(email) ELSE NULL END) STORED")
        indexes = connection.execute("SHOW INDEX FROM people").fetchall()
        if not any(row["Key_name"] == "idx_people_active_email" for row in indexes):
            connection.execute("CREATE UNIQUE INDEX idx_people_active_email ON people(active_email)")
        for row in indexes:
            if row["Column_name"] == "email" and not row["Non_unique"]:
                name = row["Key_name"].replace("`", "``")
                connection.execute(f"ALTER TABLE people DROP INDEX `{name}`")
    existing_triggers = set()
    if dialect != "sqlite":
        existing_triggers = {row["TRIGGER_NAME"] for row in connection.execute(
            "SELECT TRIGGER_NAME FROM information_schema.TRIGGERS "
            "WHERE TRIGGER_SCHEMA = DATABASE()"
        ).fetchall()}
    # These guards also serialize new assignments against archiving at the database boundary.
    for table, column in (("devices", "admin_id"), ("certificate_requests", "holder_person_id"),
                          ("certificate_inventory", "holder_person_id"), ("secure_links", "person_id")):
        for operation in ("INSERT", "UPDATE"):
            name = f"active_person_{table}_{operation.lower()}"
            if name in existing_triggers:
                continue
            condition = "1 = 1"
            if operation == "UPDATE":
                changed = (f"(OLD.{column} IS NULL OR NEW.{column} <> OLD.{column})")
                if table == "certificate_inventory":
                    condition = f"({changed} OR NEW.archived_at IS NULL)"
                elif table == "certificate_requests":
                    condition = f"({changed} OR NEW.status = 'pending')"
                elif table == "secure_links":
                    condition = (f"({changed} OR NEW.session_token_hash IS NOT NULL "
                                 "OR NEW.otp_hash IS NOT NULL)")
            if dialect == "sqlite":
                connection.execute(
                    f"CREATE TRIGGER {name} BEFORE {operation} ON {table} "
                    f"WHEN EXISTS (SELECT 1 FROM people WHERE id = NEW.{column} "
                    f"AND archived_at IS NOT NULL) AND {condition} BEGIN "
                    "SELECT RAISE(ABORT, 'Archived people are read-only'); END"
                )
            else:
                connection.execute(
                    f"CREATE TRIGGER {name} BEFORE {operation} ON {table} FOR EACH ROW BEGIN "
                    "DECLARE retired LONGTEXT; "
                    f"SELECT archived_at INTO retired FROM people WHERE id = NEW.{column} FOR UPDATE; "
                    f"IF retired IS NOT NULL AND {condition} THEN SIGNAL SQLSTATE '23000' SET MYSQL_ERRNO = 1452, "
                    "MESSAGE_TEXT = 'Archived people are read-only'; END IF; END"
                )


def migrate(database, directory):
    """Disable SQLite FKs before beginning the table rebuild, then validate before commit."""
    from myownca_core.storage.dialect import key_columns_for_scripts

    files = sorted(directory.glob("*.sql"))
    keys = key_columns_for_scripts(path.read_text() for path in files)
    with database._engine.connect() as raw:
        if database.dialect == "sqlite":
            raw.exec_driver_sql("PRAGMA foreign_keys = OFF")
            raw.commit()
            raw.exec_driver_sql("BEGIN IMMEDIATE")
        else:
            raw.begin()
        connection = _Connection(raw, database.dialect)
        try:
            connection.executescript(database._schema_migrations_ddl())
            applied = {row["version"] for row in connection.execute(
                "SELECT version FROM schema_migrations").fetchall()}
            for path in files:
                if path.name in applied:
                    continue
                if path.name == VERSION:
                    migrate_people(connection, database.dialect)
                elif path.name == "0048_archive_devices.sql":
                    from myownca.storage.device_migration import migrate_devices
                    migrate_devices(connection, database.dialect)
                elif path.name == "0047_account_person.sql" and database.dialect != "sqlite":
                    columns = {row["Field"] for row in connection.execute("SHOW COLUMNS FROM users").fetchall()}
                    if "person_id" not in columns:
                        connection.execute("ALTER TABLE users ADD COLUMN person_id VARCHAR(191), "
                                           "ADD CONSTRAINT fk_users_person FOREIGN KEY (person_id) REFERENCES people(id)")
                    indexes = connection.execute("SHOW INDEX FROM users").fetchall()
                    if not any(row["Key_name"] == "idx_users_person" for row in indexes):
                        connection.execute("CREATE UNIQUE INDEX idx_users_person ON users(person_id)")
                else:
                    connection.executescript(path.read_text(), key_columns=keys)
                if path.name == "0047_account_person.sql":
                    from myownca.account_person import backfill_accounts
                    backfill_accounts(connection)
                connection.execute("INSERT INTO schema_migrations(version) VALUES (?)", (path.name,))
            if database.dialect == "sqlite" and connection.execute("PRAGMA foreign_key_check").fetchall():
                raise IntegrityError("Foreign-key validation failed during migration")
            raw.commit()
        except Exception:
            raw.rollback()
            raise
        finally:
            if database.dialect == "sqlite":
                raw.exec_driver_sql("PRAGMA foreign_keys = ON")
                raw.commit()
