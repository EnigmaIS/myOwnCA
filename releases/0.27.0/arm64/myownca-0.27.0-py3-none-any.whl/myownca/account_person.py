"""Permanent account/holder association and legacy-account reporting."""
import logging
from datetime import datetime, timezone
from uuid import uuid4

from myownca.storage.repositories import RepositoryError


def bind_account(connection, user_id, *, include_archived=False):
    """Bind once, preferring an active email match. Return whether a person was created."""
    user = connection.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if user is None or user["person_id"] is not None:
        return False
    suffix = "" if connection._dialect == "sqlite" else " FOR UPDATE"
    connection.execute("UPDATE users SET id = id WHERE id = ?", (user_id,))
    # Another binder may have completed while we waited for the write lock.
    user = connection.execute(
        "SELECT * FROM users WHERE id = ?" + suffix, (user_id,)
    ).fetchone()
    if user is None or user["person_id"] is not None:
        return False
    matches = connection.execute(
        "SELECT id, archived_at FROM people WHERE lower(email) = lower(?)" + suffix,
        (user["email"],),
    ).fetchall()
    active = [row for row in matches if row["archived_at"] is None]
    candidates = active or (matches if include_archived else [])
    if len(candidates) > 1:
        raise RepositoryError(f"Ambiguous Person association for account {user_id}; resolve before upgrade")
    created = not candidates
    person_id = candidates[0]["id"] if candidates else str(uuid4())
    if created:
        connection.execute(
            "INSERT INTO people(id,name,surname,email,created_at) VALUES (?,?,'',?,?)",
            (person_id, user["email"].split("@", 1)[0], user["email"],
             datetime.now(timezone.utc).isoformat()),
        )
    connection.execute("UPDATE users SET person_id = ? WHERE id = ?", (person_id, user_id))
    return created


def backfill_accounts(connection):
    for row in connection.execute("SELECT id FROM users ORDER BY id").fetchall():
        bind_account(connection, row["id"], include_archived=True)


def report_legacy_accounts(repository):
    with repository.database.connect() as connection:
        rows = connection.execute(
            "SELECT u.id FROM users u JOIN people p ON p.id = u.person_id "
            "WHERE u.is_active = 1 AND p.archived_at IS NOT NULL"
        ).fetchall()
    for row in rows:
        logging.getLogger(__name__).warning(
            "Account %s remains active with an archived Person; explicit access review required", row["id"]
        )
