"""Authenticated internal operator endpoints and formula-safe generation reports."""

import csv
import io

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import Response
from starlette.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from myownca.domain import Role
from myownca.licensing import LicenseStateError
from myownca.storage.database import IntegrityError
from myownca.storage.repositories import RepositoryError
from .csv_input import MAX_BYTES
from .entitlement import require_entitlement


class Action(BaseModel):
    revision: int = Field(ge=1)
    statement: str = ""


class Settings(Action):
    template_id: str
    algorithm: str = "ecdsa-p256"


async def bounded_body(request):
    data = bytearray()
    async for part in request.stream():
        data.extend(part)
        if len(data) > MAX_BYTES:
            raise HTTPException(413, "CSV exceeds 10 MiB")
    return bytes(data)


def register(app, batch, active_user, audit_actor):
    router = APIRouter(prefix="/internal/batch-import", tags=["batch-import"])

    def authorize(request, mutation=False):
        roles = (Role.SUPERUSER,) if mutation else (Role.SUPERUSER, Role.AUDITOR)
        _, user = active_user(request, *roles, csrf=mutation)
        try:
            require_entitlement(batch.licensing)
        except LicenseStateError as exc:
            raise HTTPException(403, str(exc)) from exc
        return user

    def call(fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except LicenseStateError as exc:
            raise HTTPException(403, str(exc)) from exc
        except (RepositoryError, IntegrityError) as exc:
            raise HTTPException(
                409,
                str(exc)
                if not isinstance(exc, IntegrityError)
                else "Inventory conflict; import rolled back",
            ) from exc
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @router.get("/capability")
    def capability(request: Request):
        active_user(request, Role.SUPERUSER, Role.AUDITOR)
        try:
            require_entitlement(batch.licensing)
            enabled = True
        except LicenseStateError:
            enabled = False
        return {
            "batch_import": enabled,
            "test_environment": getattr(batch, "test_environment", False),
        }

    @router.get("")
    def sessions(request: Request):
        authorize(request)
        return batch.repository.list_sessions()

    @router.post("", status_code=201)
    async def create(
        request: Request, entity_type: str, template_id: str, algorithm: str = "ecdsa-p256"
    ):
        user = authorize(request, True)
        raw = await bounded_body(request)
        return await run_in_threadpool(
            call, batch.revision, raw, entity_type, template_id, algorithm, user.id
        )

    @router.get("/{session_id}")
    def detail(session_id: str, request: Request):
        authorize(request)
        return call(batch.repository.session, session_id)

    @router.get("/{session_id}/progress")
    def progress(session_id: str, request: Request):
        authorize(request)
        return call(batch.repository.progress, session_id)

    @router.get("/{session_id}/revisions/{revision}")
    def revision_detail(session_id: str, revision: int, request: Request):
        authorize(request)
        return call(batch.repository.revision, session_id, revision)

    @router.put("/{session_id}/source")
    async def replace(session_id: str, request: Request, revision: int):
        user = authorize(request, True)
        previous = call(batch.repository.session, session_id)
        raw = await bounded_body(request)
        manifest = previous["manifest"]
        return await run_in_threadpool(
            call,
            batch.revision,
            raw,
            manifest["entity_type"],
            manifest["template"]["id"],
            manifest["algorithm"],
            user.id,
            session_id,
            revision,
        )

    @router.put("/{session_id}/settings")
    def settings(session_id: str, payload: Settings, request: Request):
        user = authorize(request, True)
        return call(
            batch.settings,
            session_id,
            payload.revision,
            payload.template_id,
            payload.algorithm,
            user.id,
        )

    @router.post("/{session_id}/approve")
    def approve(session_id: str, payload: Action, request: Request):
        user = authorize(request, True)
        return call(batch.approve, session_id, payload.revision, user.id, payload.statement)

    @router.post("/{session_id}/confirm")
    async def confirm(session_id: str, request: Request, revision: int, statement: str):
        user = authorize(request, True)
        raw = await bounded_body(request)
        return await run_in_threadpool(
            call, batch.approve, session_id, revision, user.id, statement, raw=raw
        )

    @router.post("/{session_id}/reject")
    def reject(session_id: str, payload: Action, request: Request):
        user = authorize(request, True)
        return call(
            batch.approve, session_id, payload.revision, user.id, payload.statement, reject=True
        )

    @router.post("/{session_id}/execute")
    def execute(session_id: str, payload: Action, request: Request):
        user = authorize(request, True)
        return call(batch.execute, session_id, payload.revision, user.id)

    @router.post("/{session_id}/retry")
    def retry(session_id: str, payload: Action, request: Request):
        user = authorize(request, True)
        return call(batch.execute, session_id, payload.revision, user.id, retry=True)

    @router.post("/{session_id}/records/{record_id}/cancel")
    def cancel(session_id: str, record_id: str, payload: Action, request: Request):
        user = authorize(request, True)
        return call(batch.cancel, session_id, payload.revision, record_id, user.id,
                    payload.statement, actor=audit_actor(request))

    @router.get("/{session_id}/records")
    def records(
        session_id: str,
        request: Request,
        search: str = "",
        state: str = "",
        limit: int = 100,
        offset: int = 0,
    ):
        authorize(request)
        if not 1 <= limit <= 1000 or offset < 0:
            raise HTTPException(400, "Invalid page bounds")
        call(batch.repository.session, session_id)
        return batch.repository.records(
            session_id, search=search, state=state, limit=limit, offset=offset
        )

    @router.get("/{session_id}/report.csv")
    def report(session_id: str, request: Request, search: str = "", state: str = ""):
        authorize(request)
        session = call(batch.repository.session, session_id)
        rows = batch.repository.records(session_id, search=search, state=state, limit=10000)[
            "records"
        ]
        stream = io.StringIO(newline="")
        writer = csv.writer(stream)
        writer.writerow(
            [
                "entity_type",
                "holder_id",
                "device_serial_number",
                "session_id",
                "revision",
                "sha256",
                "first_operator",
                "first_approved_at",
                "second_operator",
                "second_approved_at",
                "template",
                "issuer_fingerprint",
                "status",
                "attempts",
                "certificate_id",
                "certificate_serial",
                "generated_at",
                "failure_reason",
            ]
        )
        approvals = [
            e
            for e in session["evidence"]
            if e["revision"] == session["revision"]
            and e["action"] in {"first_approval", "second_approval"}
        ]
        first = next((e for e in approvals if e["action"] == "first_approval"), {})
        second = next((e for e in approvals if e["action"] == "second_approval"), {})
        manifest = session["manifest"]
        for row in rows:
            holder = row["record"]["holder"]
            values = [
                manifest["entity_type"],
                holder["unique_id"],
                holder.get("device_serial_number", ""),
                session_id,
                session["revision"],
                session["digest"],
                first.get("operator_id", ""),
                first.get("created_at", ""),
                second.get("operator_id", ""),
                second.get("created_at", ""),
                manifest["template"]["id"],
                manifest["issuer_fingerprint"],
                row["state"],
                row["attempts"],
                row["certificate_id"],
                row["certificate_serial"],
                row["generated_at"],
                row["failure_reason"],
            ]
            writer.writerow([safe_cell(v) for v in values])
        return Response(
            stream.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="batch-{session_id}.csv"'},
        )

    app.include_router(router)


def safe_cell(value):
    value = "" if value is None else str(value)
    if value.lstrip().startswith(("=", "+", "-", "@")) or value.startswith(("\t", "\r", "\n")):
        return "'" + value
    return value
