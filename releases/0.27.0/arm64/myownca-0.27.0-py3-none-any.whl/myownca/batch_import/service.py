"""Revision-bound dual control and atomic create-only inventory import."""

from dataclasses import asdict
from uuid import uuid4

from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.x509.oid import NameOID

from myownca.ca_main.crypto import _san_rules_for_profile, validate_end_entity_validity
from myownca.domain import Role
from myownca.storage.repositories import RepositoryError
from .csv_input import parse_csv
from .entitlement import require_entitlement
from .repository import BatchRepository, digest, encode, stamp


class BatchService:
    def __init__(self, repository, licensing, issuer, *, audit=None):
        self.audit = audit
        self.pki = repository
        self.repository = BatchRepository(repository.database)
        self.licensing = licensing
        self.issuer = issuer

    def controls(self, template_id, algorithm):
        template = self.pki.get_template(template_id)
        if template.first_issuance_approvals > 2:
            raise ValueError("Batch import supports templates requiring at most two approvals")
        if algorithm not in template.allowed_key_algorithms:
            raise ValueError("Key algorithm is not allowed by the selected template")
        issuer = self.issuer()
        if issuer is None:
            raise ValueError("No active issuer configured")
        if issuer.allowed_profiles is not None and template.profile not in issuer.allowed_profiles:
            raise ValueError("Issuer does not permit the selected certificate profile")
        validate_end_entity_validity(template, issuer)
        return {
            "template": asdict(template),
            "algorithm": algorithm,
            "issuer_fingerprint": issuer.certificate.fingerprint(hashes.SHA256()).hex(),
        }

    def inventory_issues(self, records, entity_type, c):
        issues = []
        table = "people" if entity_type == "people" else "devices"
        for record in records:
            holder = record["holder"]
            if c.execute(f"SELECT id FROM {table} WHERE id = ?", (holder["unique_id"],)).fetchone():
                issues.append({"row": record["row"], "reason": "Holder ID already exists"})
            if entity_type == "people":
                if c.execute(
                    "SELECT id FROM people WHERE lower(email) = lower(?) AND archived_at IS NULL", (holder["email"],)
                ).fetchone():
                    issues.append({"row": record["row"], "reason": "Email already exists"})
            elif not c.execute(
                "SELECT id FROM people WHERE id = ? AND archived_at IS NULL", (holder["admin_id"],)
            ).fetchone():
                issues.append({"row": record["row"], "reason": "Responsible person does not exist"})
        return issues

    def operator(self, operator_id):
        user = self.pki.get_user(operator_id)
        if user.role is not Role.SUPERUSER or not user.is_active:
            raise RepositoryError("An active Certificate Operator is required")

    def revision(
        self, raw, entity_type, template_id, algorithm, operator_id, session_id=None, revision=None
    ):
        require_entitlement(self.licensing)
        self.operator(operator_id)
        parsed = parse_csv(raw, entity_type)
        return self._revision(
            parsed, entity_type, template_id, algorithm, operator_id, session_id, revision
        )

    def _revision(
        self, parsed, entity_type, template_id, algorithm, operator_id, session_id, revision
    ):
        controls = self.controls(template_id, algorithm)
        issues = list(parsed.issues)
        required, allowed = _san_rules_for_profile(controls["template"]["profile"])
        for record in parsed.records:
            identity = record["identity"]
            try:
                x509.NameAttribute(NameOID.COMMON_NAME, identity["common_name"])
                names = [x509.DNSName(v) for v in identity["dns_names"]]
                names += [x509.RFC822Name(v) for v in identity["email_addresses"]]
                if any(not any(isinstance(n, t) for n in names) for t in required):
                    raise ValueError("Identity is missing a SAN required by this template")
                if allowed is not None and any(not isinstance(n, allowed) for n in names):
                    raise ValueError("Identity has a SAN not allowed by this template")
            except ValueError as exc:
                issues.append({"row": record["row"], "reason": str(exc)})
        manifest = {
            "entity_type": entity_type,
            "records": parsed.records,
            "source_issues": parsed.issues,
            **controls,
        }
        with self.repository.database.connect() as c:
            if session_id:
                session = self.repository.lock(c, session_id, revision)
                if session["state"] not in {"draft", "review", "ready", "rejected"}:
                    raise RepositoryError("Imported revision is frozen")
                revision += 1
                c.execute(
                    "UPDATE batch_sessions SET revision = ?, state = 'draft' WHERE id = ?",
                    (revision, session_id),
                )
            else:
                session_id, revision = str(uuid4()), 1
                c.execute(
                    "INSERT INTO batch_sessions(id,revision,state,created_at,created_by) VALUES (?,?,?,?,?)",
                    (session_id, revision, "draft", stamp(), operator_id),
                )
            issues += self.inventory_issues(parsed.records, entity_type, c)
            c.execute(
                "INSERT INTO batch_revisions(session_id,revision,digest,manifest,manifest_digest,issues,created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (
                    session_id,
                    revision,
                    parsed.digest,
                    encode(manifest),
                    digest(manifest),
                    encode(issues),
                    stamp(),
                ),
            )
        return self.repository.session(session_id)

    def settings(self, session_id, revision, template_id, algorithm, operator_id):
        from .csv_input import ParsedCSV

        previous = self.repository.session(session_id)
        if previous["revision"] != revision:
            raise RepositoryError("Stale batch revision")
        require_entitlement(self.licensing)
        self.operator(operator_id)
        # Preserve exact source digest and all source-validation issues across settings changes.
        parsed = ParsedCSV(
            previous["digest"],
            previous["manifest"]["records"],
            previous["manifest"]["source_issues"],
        )
        return self._revision(
            parsed,
            previous["manifest"]["entity_type"],
            template_id,
            algorithm,
            operator_id,
            session_id,
            revision,
        )

    def validate_authorization(self, session, *, inventory=False, c=None):
        require_entitlement(self.licensing)
        manifest = session["manifest"]
        if digest(manifest) != session["manifest_digest"]:
            raise RepositoryError("Authorization manifest integrity check failed")
        current = self.controls(manifest["template"]["id"], manifest["algorithm"])
        if encode(current) != encode({k: manifest[k] for k in current}):
            raise RepositoryError("Certificate configuration changed; renewed review is required")
        approvals = [
            e
            for e in session["evidence"]
            if e["revision"] == session["revision"]
            and e["action"] in {"first_approval", "second_approval"}
        ]
        if len(approvals) != 2 or len({e["operator_id"] for e in approvals}) != 2:
            raise RepositoryError("Two distinct batch approvals are required")
        for evidence in approvals:
            self.operator(evidence["operator_id"])
            if (
                evidence["digest"] != session["digest"]
                or evidence["manifest_digest"] != session["manifest_digest"]
            ):
                raise RepositoryError("Approval binding changed")
        if session["issues"]:
            raise RepositoryError("Resolve validation issues before execution")
        if inventory and self.inventory_issues(manifest["records"], manifest["entity_type"], c):
            raise RepositoryError("Inventory conflict; no holders imported")
        return approvals

    def approve(self, session_id, revision, operator_id, statement, raw=None, reject=False):
        require_entitlement(self.licensing)
        self.operator(operator_id)
        if not isinstance(statement, str) or not statement.strip() or len(statement) > 2000:
            raise ValueError("An explicit review statement is required (maximum 2000 characters)")
        error = None
        with self.repository.database.connect() as c:
            session = self.repository.lock(c, session_id, revision)
            if session["state"] not in (
                {"draft", "review", "ready"} if reject else {"draft", "review"}
            ):
                raise RepositoryError("Revision is not awaiting approval")
            if session["issues"] and not reject:
                raise RepositoryError("Resolve validation issues before approval")
            previous = [
                e
                for e in session["evidence"]
                if e["revision"] == revision and e["action"] == "first_approval"
            ]
            file_digest = None
            if reject:
                action, state = "rejected", "rejected"
            elif previous and previous[0]["operator_id"] == operator_id:
                action, state, error = (
                    "duplicate_operator_denied",
                    session["state"],
                    "A different Certificate Operator is required",
                )
            elif previous:
                if raw is None:
                    raise ValueError("The second operator must upload the identical CSV")
                import hashlib

                file_digest = hashlib.sha256(raw).hexdigest()
                if file_digest != session["digest"]:
                    action, state, error = (
                        "file_mismatch",
                        "rejected",
                        "CSV digest mismatch; revision rejected",
                    )
                else:
                    action, state = "second_approval", "ready"
            elif raw is not None:
                raise RepositoryError("First approval must precede second-file confirmation")
            else:
                with self.pki.database.connect() as inventory_c:
                    conflicts = self.inventory_issues(
                        session["manifest"]["records"],
                        session["manifest"]["entity_type"],
                        inventory_c,
                    )
                if conflicts:
                    raise RepositoryError("Inventory conflicts require a new revision")
                action, state = "first_approval", "review"
            self.repository.evidence(c, session, operator_id, action, statement, file_digest)
            c.execute("UPDATE batch_sessions SET state = ? WHERE id = ?", (state, session_id))
        if error:
            raise RepositoryError(error)
        return self.repository.session(session_id)

    def execute(self, session_id, revision, operator_id, retry=False):
        self.operator(operator_id)
        with self.repository.database.connect() as c:
            session = self.repository.lock(c, session_id, revision)
            expected = {"paused", "running", "completed"} if retry else {"ready"}
            if session["state"] not in expected:
                raise RepositoryError("Batch is not eligible for this action")
            self.validate_authorization(session, inventory=not retry, c=c)
            if retry:
                # Uncertain signing is intentionally excluded. It requires reconciliation.
                c.execute(
                    "UPDATE batch_records SET state = 'pending', failure_reason = '' "
                    "WHERE session_id = ? AND state IN ('failed','paused')",
                    (session_id,),
                )
            else:
                for record in session["manifest"]["records"]:
                    self._insert_holder(c, record["holder"], session["manifest"]["entity_type"])
                    c.execute(
                        "INSERT INTO batch_records(id,session_id,revision,row_number,record,state) VALUES (?,?,?,?,?,?)",
                        (
                            str(uuid4()),
                            session_id,
                            revision,
                            record["row"],
                            encode(record),
                            "pending",
                        ),
                    )
            c.execute("UPDATE batch_sessions SET state = 'running' WHERE id = ?", (session_id,))
            self.repository.evidence(
                c,
                session,
                operator_id,
                "retry" if retry else "execute",
                "Import & pre-generate certificates",
            )
        return self.repository.session(session_id)

    def cancel(self, session_id, revision, record_id, operator_id, reason, *, actor=None):
        from .cancellation import cancel_record

        return cancel_record(self, session_id, revision, record_id, operator_id, reason, actor=actor)

    @staticmethod
    def _insert_holder(c, holder, entity_type):
        if entity_type == "people":
            fields = ("name", "surname", "email", "phone", "slack_handle", "company", "comments")
            c.execute(
                "INSERT INTO people(id,name,surname,email,phone,slack_handle,company,comments,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (holder["unique_id"], *(holder.get(f, "") for f in fields), stamp()),
            )
        else:
            fields = ("device_name", "fqdn", "admin_id", "comments")
            c.execute(
                "INSERT INTO devices(id,device_name,fqdn,admin_id,comments,created_at) VALUES (?,?,?,?,?,?)",
                (holder["unique_id"], *(holder.get(f, "") for f in fields), stamp()),
            )
