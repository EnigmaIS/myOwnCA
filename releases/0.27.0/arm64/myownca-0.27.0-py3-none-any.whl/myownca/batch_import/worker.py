"""Bounded leased work; interrupted signing is reconciled, never blindly repeated."""

import copy
import json
import logging
from datetime import datetime, timedelta, timezone
from uuid import uuid4

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.x509.oid import NameOID

from myownca import keygen
from myownca.ca_main.server_keys import build_csr_for_key
from myownca.domain import ApprovalRecord
from myownca.key_lifecycle.base import KeyOwnership
from myownca.key_lifecycle.repository import KeyLifecycleRepository
from myownca.storage.repositories import PKIRepository, RepositoryError
from .guards import batch_operation
from .repository import TransactionDatabase, stamp

logger = logging.getLogger(__name__)


class BatchWorker:
    def __init__(self, batch, service, vault, issue, bind_certificate_key, *, entropy=None):
        self.batch, self.service, self.vault = batch, service, vault
        self.issue, self.bind_certificate_key = issue, bind_certificate_key
        self.entropy = entropy
        self.database = batch.repository.database

    def authorize_issuance(self, record, issuer):
        session = self.batch.repository.session(record["session_id"])
        self.batch.validate_authorization(session)
        if session["state"] != "running" or record["state"] != "signing":
            raise RepositoryError("Batch execution is paused or requires reconciliation")
        manifest = session["manifest"]
        if issuer.certificate.fingerprint(hashes.SHA256()).hex() != manifest["issuer_fingerprint"]:
            raise RepositoryError("Batch issuer changed")
        request = self.service.repository.get_request(record["request_id"])
        item = json.loads(record["record"])
        expected = next(r for r in manifest["records"] if r["row"] == record["row_number"])
        if item != expected or request.template_id != manifest["template"]["id"]:
            raise RepositoryError("Batch record binding changed")
        holder = item["holder"]["unique_id"]
        actual_holder = (request.holder_person_id, request.holder_device_id)
        if actual_holder != (
            (holder, None) if manifest["entity_type"] == "people" else (None, holder)
        ):
            raise RepositoryError("Batch holder binding changed")
        csr = x509.load_pem_x509_csr(request.csr_pem.encode())
        identity = item["identity"]
        if csr.subject != x509.Name(
            [x509.NameAttribute(NameOID.COMMON_NAME, identity["common_name"])]
        ):
            raise RepositoryError("Batch subject changed")
        try:
            san = csr.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
            dns, emails = (
                san.get_values_for_type(x509.DNSName),
                san.get_values_for_type(x509.RFC822Name),
            )
            if len(san) != len(dns) + len(emails):
                raise RepositoryError("Unexpected batch SAN type")
        except x509.ExtensionNotFound:
            dns, emails = [], []
        if dns != identity["dns_names"] or emails != identity["email_addresses"]:
            raise RepositoryError("Batch SAN changed")
        pem = self.vault.load_pem(request.id)
        if pem is None:
            raise RepositoryError("Batch key is missing")
        key = serialization.load_pem_private_key(pem.encode(), password=None)
        if key.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo
        ) != csr.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo
        ):
            raise RepositoryError("Batch key binding changed")
        approvals = self.service.repository.list_approvals(request.id)
        evidence = [
            e
            for e in session["evidence"]
            if e["revision"] == session["revision"]
            and e["action"] in {"first_approval", "second_approval"}
        ]
        if {(a.superuser_id, a.approved_at.isoformat()) for a in approvals} != {
            (e["operator_id"], e["created_at"]) for e in evidence
        }:
            raise RepositoryError("Batch request approvals changed")

    def _lock_preparation(self, c, record, token, manifest):
        # Person precedes batch record, matching cancellation and retirement.
        holder = json.loads(record["record"])["holder"]["unique_id"]
        if manifest["entity_type"] == "people":
            c.execute("UPDATE people SET id = id WHERE id = ?", (holder,))
        if c.execute(
            "UPDATE batch_records SET state = state WHERE id = ? AND lease_token = ? AND state = 'preparing'",
            (record["id"], token),
        ).rowcount != 1:
            raise RepositoryError("Batch work claim lost")
        return c.execute(
            "SELECT request_id FROM batch_records WHERE id = ?", (record["id"],)
        ).fetchone()["request_id"]

    def prepare(self, record, token):
        session = self.batch.repository.session(record["session_id"])
        self.batch.validate_authorization(session)
        manifest = session["manifest"]
        with self.database.connect() as c:
            existing = self._lock_preparation(c, record, token, manifest)
            if existing:
                return existing

        key = keygen.generate_private_key(manifest["algorithm"], entropy_source=self.entropy)
        identity = json.loads(record["record"])["identity"]
        csr = build_csr_for_key(
            key, **{k: tuple(v) if isinstance(v, list) else v for k, v in identity.items()}
        )
        with self.database.connect() as c:
            existing = self._lock_preparation(c, record, token, manifest)
            if existing:
                return existing
            request_id = str(uuid4())
            scoped = TransactionDatabase(c)
            pki = PKIRepository(scoped)
            service = copy.copy(self.service)
            service.repository = pki
            vault = copy.copy(self.vault)
            vault.repository = pki
            request = service.submit_request(
                manifest["template"]["id"],
                csr,
                request_id=request_id,
                requested_by_user_id=session["created_by"],
            )
            holder = json.loads(record["record"])["holder"]["unique_id"]
            service.assign_request_holder(
                request_id,
                **(
                    {"person_id": holder}
                    if manifest["entity_type"] == "people"
                    else {"device_id": holder}
                ),
            )
            vault.store(request.id, key, manifest["algorithm"])
            lifecycle = KeyLifecycleRepository(scoped)
            registered = lifecycle.register(
                backend="request_vault",
                key_ref=request_id,
                purpose="leaf_certificate",
                ownership=KeyOwnership.MANAGED,
            )
            lifecycle.bind(
                registered.id, resource_type="certificate_request", resource_id=request_id
            )
            pki.set_request_key_registry_id(request_id, registered.id)
            for e in session["evidence"]:
                if e["revision"] == session["revision"] and e["action"] in {
                    "first_approval",
                    "second_approval",
                }:
                    pki.add_approval(
                        ApprovalRecord(
                            request_id, e["operator_id"], datetime.fromisoformat(e["created_at"])
                        )
                    )
            c.execute(
                "UPDATE batch_records SET request_id = ? WHERE id = ? AND lease_token = ?",
                (request_id, record["id"], token),
            )
        return request_id

    def pause(self, session_id, reason):
        with self.database.connect() as c:
            c.execute(
                "UPDATE batch_sessions SET state = 'paused' WHERE id = ? AND state = 'running'",
                (session_id,),
            )
            c.execute(
                "UPDATE batch_records SET state = 'paused', failure_reason = ? WHERE session_id = ? AND state = 'pending'",
                (reason, session_id),
            )

    def reconcile(self):
        with self.database.connect() as c:
            rows = c.execute(
                "SELECT * FROM batch_records WHERE (state NOT IN ('completed', 'canceled') AND request_id IS NOT NULL) OR "
                "(state = 'preparing' AND lease_until < ?)",
                (stamp(),),
            ).fetchall()
        for row in rows:
            cert = (
                self.service.repository.get_issued_certificate_by_request_id(row["request_id"])
                if row["request_id"]
                else None
            )
            if cert is not None:
                self.bind_certificate_key(cert)
                with self.database.connect() as c:
                    c.execute(
                        "UPDATE batch_records SET state = 'completed', certificate_id = ?, certificate_serial = ?, "
                        "generated_at = ?, failure_reason = '', lease_token = NULL, lease_until = NULL WHERE id = ? AND state NOT IN ('completed', 'canceled')",
                        (
                            cert.certificate_id,
                            cert.serial_number,
                            cert.issued_at.isoformat(),
                            row["id"],
                        ),
                    )
            elif row["state"] == "preparing":
                with self.database.connect() as c:
                    c.execute(
                        "UPDATE batch_records SET state = 'pending', lease_token = NULL, lease_until = NULL "
                        "WHERE id = ? AND state = 'preparing' AND lease_until < ?",
                        (row["id"], stamp()),
                    )
            elif row["state"] == "cloud_queued":
                with self.database.connect() as c:
                    jobs = c.execute(
                        "SELECT status FROM signing_jobs WHERE resource_id = ? AND operation = 'issue_certificate'",
                        (row["request_id"],),
                    ).fetchall()
                if not jobs or all(
                    j["status"] in {"failed", "canceled", "succeeded"} for j in jobs
                ):
                    self.uncertain(row["id"])
            elif row["lease_until"] and row["lease_until"] < stamp():
                self.uncertain(row["id"])
        with self.database.connect() as c:
            c.execute(
                "UPDATE batch_sessions SET state = 'completed' WHERE state = 'running' AND NOT EXISTS "
                "(SELECT 1 FROM batch_records WHERE batch_records.session_id = batch_sessions.id "
                "AND state IN ('pending','preparing','signing','cloud_queued'))"
            )

    def uncertain(self, record_id):
        with self.database.connect() as c:
            c.execute(
                "UPDATE batch_records SET state = 'uncertain', failure_reason = ? WHERE id = ? AND state NOT IN ('completed', 'canceled')",
                (
                    "Signing outcome requires reconciliation; automatic re-signing is blocked",
                    record_id,
                ),
            )

    def tick(self):
        self.reconcile()
        for _ in range(20):
            with self.database.connect() as c:
                rows = c.execute(
                    "SELECT r.* FROM batch_records r JOIN batch_sessions s ON s.id = r.session_id "
                    "WHERE s.state = 'running' AND r.state = 'pending' ORDER BY s.created_at, r.row_number LIMIT 1"
                ).fetchall()
            if not rows:
                break
            record, token = rows[0], str(uuid4())
            try:
                self.batch.validate_authorization(
                    self.batch.repository.session(record["session_id"])
                )
            except Exception:
                self.pause(
                    record["session_id"],
                    "Entitlement or authorization unavailable; explicit retry required",
                )
                continue
            with self.database.connect() as c:
                claimed = c.execute(
                    "UPDATE batch_records SET state = 'preparing', lease_token = ?, lease_until = ?, attempts = attempts + 1 "
                    "WHERE id = ? AND state = 'pending'",
                    (
                        token,
                        (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat(),
                        record["id"],
                    ),
                ).rowcount
            if not claimed:
                continue
            signing = False
            try:
                request_id = self.prepare(record, token)
                with self.database.connect() as c:
                    changed = c.execute(
                        "UPDATE batch_records SET state = 'signing' WHERE id = ? AND lease_token = ? AND state = 'preparing'",
                        (record["id"], token),
                    ).rowcount
                if not changed:
                    continue
                signing = True
                with batch_operation(request_id):
                    cert, error = self.issue(request_id)
                if error and error.get("code") == "cloud_signing_queued":
                    with self.database.connect() as c:
                        c.execute(
                            "UPDATE batch_records SET state = 'cloud_queued' WHERE id = ? AND state = 'signing'",
                            (record["id"],),
                        )
                elif cert is None:
                    # Known policy/preflight failures happen before the signer.
                    code = (error or {}).get("code")
                    if code in {
                        "license_limit_reached",
                        "license_state_unavailable",
                        "hsm_locked",
                        "no_issuer",
                    }:
                        with self.database.connect() as c:
                            c.execute(
                                "UPDATE batch_records SET state = 'paused', failure_reason = ?, lease_token = NULL, lease_until = NULL WHERE id = ?",
                                (str(code), record["id"]),
                            )
                        self.pause(record["session_id"], str(code))
                    else:
                        self.uncertain(record["id"])
            except Exception:
                logger.exception("Batch work failed for record %s", record["id"])
                if signing:
                    self.uncertain(record["id"])
                else:
                    with self.database.connect() as c:
                        c.execute(
                            "UPDATE batch_records SET state = 'failed', failure_reason = ?, lease_token = NULL, lease_until = NULL WHERE id = ? AND lease_token = ?",
                            ("Request preparation failed; retry is available", record["id"], token),
                        )
            self.reconcile()

    def cloud_issue(self, request_id, issue):
        from .guards import bound_record

        record = bound_record(self.service.repository, request_id)
        if not record:
            return issue()
        if record["state"] == "canceled":
            from myownca.cloud import PermanentSigningError

            raise PermanentSigningError("batch_record_canceled", "Batch record was canceled")
        try:
            self.batch.validate_authorization(self.batch.repository.session(record["session_id"]))
            if self.batch.repository.session(record["session_id"])["state"] != "running":
                raise RepositoryError("Batch execution is paused")
        except Exception as exc:
            from myownca.cloud import PermanentSigningError

            self.pause(
                record["session_id"],
                "Entitlement or authorization unavailable; explicit retry required",
            )
            with self.database.connect() as c:
                c.execute(
                    "UPDATE batch_records SET state = 'paused', failure_reason = ? "
                    "WHERE id = ? AND state = 'cloud_queued'",
                    ("Cloud signing preflight paused; explicit retry required", record["id"]),
                )
            raise PermanentSigningError(
                "batch_preflight_paused", "Batch authorization unavailable before signing"
            ) from exc
        with self.database.connect() as c:
            changed = c.execute(
                "UPDATE batch_records SET state = 'signing', lease_until = ? WHERE id = ? AND state = 'cloud_queued'",
                ((datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat(), record["id"]),
            ).rowcount
        if not changed:
            raise RepositoryError("Batch cloud signing requires reconciliation")
        try:
            with batch_operation(request_id):
                result = issue()
            if result[0] is None:
                self.uncertain(record["id"])
            return result
        except Exception:
            self.uncertain(record["id"])
            raise
