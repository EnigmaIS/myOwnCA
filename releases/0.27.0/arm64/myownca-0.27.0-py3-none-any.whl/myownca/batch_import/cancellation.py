"""Transactional per-record cancellation, retaining all authorization evidence."""

import json
from datetime import datetime, timezone

from myownca.audit import AuditActor, AuditCategory
from myownca.key_lifecycle.repository import KeyLifecycleRepository
from myownca.storage.repositories import RepositoryError
from .repository import TransactionDatabase


def cancel_record(batch, session_id, revision, record_id, operator_id, reason, *, actor=None):
    batch.operator(operator_id)
    if not isinstance(reason, str) or not reason.strip() or len(reason) > 2000:
        raise ValueError("A cancellation reason is required (maximum 2000 characters)")
    user = batch.pki.get_user(operator_id)
    actor = actor or AuditActor(id=user.id, email=user.email, role=user.role.value)
    with batch.audit.transaction() as transaction:
        c = transaction.connection
        session = batch.repository.lock(c, session_id, revision)
        # Read immutable holder binding, then use the same lock order as preparation
        # and retirement: Person first, record second. Claims are conditional updates.
        row = c.execute(
            "SELECT * FROM batch_records WHERE id = ? AND session_id = ?", (record_id, session_id)
        ).fetchone()
        if row is None:
            raise RepositoryError("Unknown batch record")
        if session["manifest"]["entity_type"] == "people":
            holder = json.loads(row["record"])["holder"]["unique_id"]
            c.execute("UPDATE people SET id = id WHERE id = ?", (holder,))
        c.execute("UPDATE batch_records SET state = state WHERE id = ?", (record_id,))
        suffix = " FOR UPDATE" if c._dialect != "sqlite" else ""
        row = c.execute(
            "SELECT * FROM batch_records WHERE id = ?" + suffix, (record_id,)
        ).fetchone()
        if row["revision"] != revision:
            raise RepositoryError("Stale batch revision")
        if row["state"] not in {"pending", "failed", "paused", "preparing"}:
            raise RepositoryError("Batch work must be stopped or reconciled before cancellation")
        lease = datetime.fromisoformat(row["lease_until"]) if row["lease_until"] else None
        if lease is not None and lease.tzinfo is None:
            lease = lease.replace(tzinfo=timezone.utc)
        if lease is not None and lease > datetime.now(timezone.utc):
            raise RepositoryError("Batch work has an active worker lease")
        if row["request_id"]:
            request_id = row["request_id"]
            request = c.execute(
                "SELECT * FROM certificate_requests WHERE id = ?" + suffix, (request_id,)
            ).fetchone()
            if request["status"] != "pending":
                raise RepositoryError("Only pending batch requests can be canceled")
            jobs = c.execute(
                "SELECT status FROM signing_jobs WHERE resource_id = ? AND operation = 'issue_certificate'"
                + suffix,
                (request_id,),
            ).fetchall()
            if any(job["status"] in {"queued", "running", "succeeded"} for job in jobs):
                raise RepositoryError(
                    "Cloud signing must be stopped or reconciled before cancellation"
                )
            if c.execute(
                "SELECT request_id FROM issued_certificates WHERE request_id = ?", (request_id,)
            ).fetchone():
                raise RepositoryError("Issued batch work cannot be canceled")
            c.execute(
                "UPDATE certificate_requests SET status = 'rejected' WHERE id = ?", (request_id,)
            )
            if request["key_registry_id"]:
                # Existing lifecycle policy schedules an unbound managed key with
                # its mandatory grace period. No key material is deleted here.
                KeyLifecycleRepository(TransactionDatabase(c)).unbind(
                    request["key_registry_id"],
                    resource_type="certificate_request",
                    resource_id=request_id,
                )
        previous_failure = row["failure_reason"]
        report_reason = (
            (previous_failure + "; " if previous_failure else "") + "Canceled: " + reason.strip()
        )
        c.execute(
            "UPDATE batch_records SET state = 'canceled', failure_reason = ?, "
            "lease_token = NULL, lease_until = NULL WHERE id = ?",
            (report_reason, record_id),
        )
        batch.repository.evidence(
            c, session, operator_id, "record_canceled", f"Record {record_id}: {reason.strip()}"
        )
        transaction.record(
            AuditCategory.PERMISSION,
            "batch_record_canceled",
            actor=actor,
            object_type="batch_record",
            object_id=record_id,
            details={
                "session_id": session_id,
                "revision": revision,
                "request_id": row["request_id"],
                "previous_state": row["state"],
                "reason": reason.strip(),
            },
        )
    return batch.repository.records(session_id)
