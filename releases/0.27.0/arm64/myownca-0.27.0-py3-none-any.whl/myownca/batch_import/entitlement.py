"""Fail-closed commercial entitlement, separate from normal license fallback."""

from datetime import datetime, timezone

from myownca.licensing import LicenseStateError


def require_entitlement(licensing):
    license, error = licensing._load()
    if error or license is None or not license.is_active(datetime.now(timezone.utc)):
        raise LicenseStateError("Batch import requires a currently verified commercial license")
    return license
