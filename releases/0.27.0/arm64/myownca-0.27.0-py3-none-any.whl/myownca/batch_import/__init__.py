"""Create-only holder import with durable, file-bound dual authorization."""
