"""In-process permits never accepted from clients or serialized into jobs."""

from contextlib import contextmanager
from contextvars import ContextVar

from myownca.storage.repositories import RepositoryError

_permit = ContextVar("batch_import_permit", default=None)


@contextmanager
def batch_operation(request_id):
    token = _permit.set(request_id)
    try:
        yield
    finally:
        _permit.reset(token)


def bound_record(repository, request_id):
    with repository.database.connect() as c:
        return c.execute(
            "SELECT * FROM batch_records WHERE request_id = ?", (request_id,)
        ).fetchone()


def protect_mutation(repository, request_id):
    if _permit.get() != request_id and bound_record(repository, request_id):
        raise RepositoryError("Batch requests are immutable; use the batch workflow")


def protect_pending_key_retirement(repository, request_id):
    record = bound_record(repository, request_id)
    if record and record["state"] not in {"completed", "canceled"}:
        raise RepositoryError(
            "Batch key retirement is blocked until certificate generation completes"
        )


def protect_issuance(service, request_id, issuer):
    record = bound_record(service.repository, request_id)
    if record:
        authorizer = getattr(service, "batch_authorizer", None)
        if _permit.get() != request_id or authorizer is None:
            raise RepositoryError("Batch issuance requires the authorized batch worker")
        authorizer(record, issuer)
