"""Strict bounded CSV input and resolved certificate identities."""

import csv
import hashlib
import io
import re
from dataclasses import dataclass

MAX_BYTES = 10 * 1024 * 1024
MAX_RECORDS = 10_000
REQUIRED = {
    "people": {"unique_id", "name", "surname", "email"},
    "devices": {"unique_id", "device_name", "admin_id"},
}
OPTIONAL = {
    "people": {"phone", "slack_handle", "company", "comments"},
    "devices": {"fqdn", "comments", "device_serial_number"},
}


@dataclass(frozen=True)
class ParsedCSV:
    digest: str
    records: list[dict]
    issues: list[dict]


def parse_csv(raw: bytes, entity_type: str) -> ParsedCSV:
    if entity_type not in REQUIRED:
        raise ValueError("Entity type must be people or devices")
    if len(raw) > MAX_BYTES:
        raise ValueError("CSV exceeds 10 MiB")
    digest = hashlib.sha256(raw).hexdigest()
    try:
        reader = csv.reader(io.StringIO(raw.decode("utf-8-sig"), newline=""), strict=True)
        header = next(reader)
        if len(header) != len(set(header)):
            raise ValueError("Duplicate column names")
        if not REQUIRED[entity_type] <= set(header):
            raise ValueError("Missing required columns")
        if set(header) - REQUIRED[entity_type] - OPTIONAL[entity_type]:
            raise ValueError("Unsupported columns")
        records, issues, identifiers, emails = [], [], {}, {}
        for number, values in enumerate(reader, 1):
            if number > MAX_RECORDS:
                raise ValueError("CSV exceeds 10,000 records")
            if len(values) != len(header):
                issues.append({"row": number, "reason": "Incorrect number of fields"})
                continue
            row = dict(zip(header, values))
            if any("\x00" in v or v != v.strip() for v in values):
                issues.append({"row": number, "reason": "NUL or surrounding whitespace"})
            if any(not row[k] for k in REQUIRED[entity_type]):
                issues.append({"row": number, "reason": "Empty required field"})
            if len(row["unique_id"]) > 191:
                issues.append({"row": number, "reason": "Holder ID exceeds 191 characters"})
            if entity_type == "people" and not re.fullmatch(
                r"[^\s@]+@[^\s@]+\.[^\s@]+", row["email"]
            ):
                issues.append({"row": number, "reason": "Invalid email address"})
            fqdn = row.get("fqdn", "")
            if fqdn and (
                len(fqdn) > 253
                or any(
                    not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?", label)
                    for label in fqdn.rstrip(".").split(".")
                )
            ):
                issues.append({"row": number, "reason": "Invalid FQDN"})
            identifier = row["unique_id"]
            identifiers.setdefault(identifier, []).append(number)
            if entity_type == "people":
                emails.setdefault(row["email"].lower(), []).append(number)
                cn = f"{row['name']} {row['surname']}"
                dns, email = [], [row["email"]]
            else:
                cn = row.get("fqdn") or identifier
                dns, email = ([row["fqdn"]] if row.get("fqdn") else []), []
            if not cn or len(cn.encode("utf-8")) > 64:
                issues.append({"row": number, "reason": "CN must contain 1–64 UTF-8 bytes"})
            records.append(
                {
                    "row": number,
                    "holder": row,
                    "identity": {"common_name": cn, "dns_names": dns, "email_addresses": email},
                }
            )
        for groups, label in ((identifiers, "identifier"), (emails, "email")):
            for group in groups.values():
                if len(group) > 1:
                    issues.append({"rows": group, "reason": f"Duplicate {label}"})
        if not records:
            issues.append({"reason": "CSV contains no records"})
    except (UnicodeError, csv.Error, StopIteration) as exc:
        raise ValueError("Malformed UTF-8 CSV") from exc
    return ParsedCSV(digest, records, issues)
