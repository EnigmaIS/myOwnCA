"""Reuse durable cloud jobs; terminal signing failures require reconciliation."""

from myownca.storage.repositories import RepositoryError
from .guards import bound_record


def existing_job(pki, request_id, jobs):
    if not bound_record(pki, request_id):
        return None
    with pki.database.connect() as c:
        rows = c.execute(
            "SELECT * FROM signing_jobs WHERE resource_id = ? AND resource_type = 'certificate_request' "
            "AND operation = 'issue_certificate' ORDER BY created_at DESC, id DESC",
            (request_id,),
        ).fetchall()
    if not rows:
        return None
    job = rows[0]
    if job["status"] in {"queued", "running"}:
        return jobs.get(job["id"])
    if job["status"] == "failed" and job["last_error_code"] == "batch_preflight_paused":
        return jobs.retry_failed(job["id"])
    raise RepositoryError(
        "Existing batch signing job requires reconciliation; resubmission blocked"
    )
