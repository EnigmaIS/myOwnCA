"""Batch persistence and transaction-scoped adapters for existing repositories."""

import hashlib
import json
from contextlib import contextmanager
from datetime import datetime, timezone
from uuid import uuid4

from myownca.storage.repositories import RepositoryError


def stamp():
    return datetime.now(timezone.utc).isoformat()


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str, ensure_ascii=False)


def digest(value):
    return hashlib.sha256(encode(value).encode()).hexdigest()


class TransactionDatabase:
    """Reuse existing repository logic on an already owned transaction."""

    def __init__(self, connection):
        self.connection = connection
        self.dialect = connection._dialect

    @contextmanager
    def connect(self):
        yield self.connection


class BatchRepository:
    def __init__(self, database):
        self.database = database

    def session(self, session_id, connection=None):
        if connection is None:
            with self.database.connect() as c:
                return self.session(session_id, c)
        row = connection.execute(
            "SELECT * FROM batch_sessions WHERE id = ?", (session_id,)
        ).fetchone()
        if row is None:
            raise RepositoryError("Unknown batch session")
        revision = connection.execute(
            "SELECT * FROM batch_revisions WHERE session_id = ? AND revision = ?",
            (session_id, row["revision"]),
        ).fetchone()
        row.update(revision)
        row["manifest"] = json.loads(row["manifest"])
        row["issues"] = json.loads(row["issues"])
        row["evidence"] = connection.execute(
            "SELECT * FROM batch_evidence WHERE session_id = ? ORDER BY created_at, id",
            (session_id,),
        ).fetchall()
        row["progress"] = {
            item["state"]: item["n"]
            for item in connection.execute(
                "SELECT state, count(*) AS n FROM batch_records WHERE session_id = ? GROUP BY state",
                (session_id,),
            ).fetchall()
        }
        row["revisions"] = connection.execute(
            "SELECT revision,digest,manifest_digest,created_at FROM batch_revisions WHERE session_id = ? ORDER BY revision",
            (session_id,),
        ).fetchall()
        return row

    def progress(self, session_id):
        with self.database.connect() as c:
            session = c.execute(
                "SELECT s.id,s.revision,s.state,r.manifest FROM batch_sessions s "
                "JOIN batch_revisions r ON r.session_id = s.id AND r.revision = s.revision "
                "WHERE s.id = ?", (session_id,),
            ).fetchone()
            if session is None:
                raise RepositoryError("Unknown batch session")
            counts = {
                row["state"]: row["n"] for row in c.execute(
                    "SELECT state,count(*) AS n FROM batch_records WHERE session_id = ? GROUP BY state",
                    (session_id,),
                ).fetchall()
            }
            return {
                "id": session["id"], "revision": session["revision"], "state": session["state"],
                "total": len(json.loads(session["manifest"])["records"]), "progress": counts,
            }

    def revision(self, session_id, revision):
        with self.database.connect() as c:
            row = c.execute(
                "SELECT * FROM batch_revisions WHERE session_id = ? AND revision = ?",
                (session_id, revision),
            ).fetchone()
        if row is None:
            raise RepositoryError("Unknown batch revision")
        row["manifest"] = json.loads(row["manifest"])
        row["issues"] = json.loads(row["issues"])
        return row

    def lock(self, c, session_id, revision):
        if (
            c.execute(
                "UPDATE batch_sessions SET state = state WHERE id = ? AND revision = ?",
                (session_id, revision),
            ).rowcount
            != 1
        ):
            raise RepositoryError("Stale batch revision")
        return self.session(session_id, c)

    def evidence(self, c, session, operator_id, action, statement, file_digest=None):
        c.execute(
            "INSERT INTO batch_evidence(id,session_id,revision,action,operator_id,digest,"
            "manifest_digest,statement,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (
                str(uuid4()),
                session["id"],
                session["revision"],
                action,
                operator_id,
                file_digest or session["digest"],
                session["manifest_digest"],
                statement,
                stamp(),
            ),
        )

    def list_sessions(self):
        with self.database.connect() as c:
            return c.execute(
                "SELECT * FROM batch_sessions ORDER BY created_at DESC LIMIT 200"
            ).fetchall()

    def records(self, session_id, *, search="", state="", limit=100, offset=0):
        clauses, params = ["session_id = ?"], [session_id]
        if search:
            # Escaped LIKE searches are portable across SQLite and MariaDB.
            clauses.append("record LIKE ? ESCAPE '!'")
            params.append(
                "%" + search.replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%"
            )
        if state:
            clauses.append("state = ?")
            params.append(state)
        where = " AND ".join(clauses)
        with self.database.connect() as c:
            total = c.execute(
                f"SELECT count(*) AS n FROM batch_records WHERE {where}", params
            ).fetchone()["n"]
            rows = c.execute(
                f"SELECT * FROM batch_records WHERE {where} ORDER BY row_number LIMIT ? OFFSET ?",
                [*params, limit, offset],
            ).fetchall()
        for row in rows:
            row["record"] = json.loads(row["record"])
            row.pop("lease_token", None)
        return {"total": total, "records": rows, "limit": limit, "offset": offset}
