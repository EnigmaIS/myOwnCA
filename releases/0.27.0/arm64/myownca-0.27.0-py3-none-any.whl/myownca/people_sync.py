"""Create a holder association once; subsequent email changes never rebind it."""

from __future__ import annotations


from myownca.domain import User
from myownca.storage.repositories import PKIRepository


def person_fields_from_user(user: User) -> dict[str, str]:
    """Derive a Person's name/surname/email from a login user (no name stored)."""
    local_part = user.email.split("@", 1)[0]
    return {"name": local_part or user.email, "surname": "", "email": user.email}


def ensure_person_for_user(repository: PKIRepository, user: User) -> bool:
    """Bind a registered account once. Return whether its Person was created."""
    from myownca.account_person import bind_account

    with repository.database.connect() as connection:
        return bind_account(connection, user.id, include_archived=True)


def ensure_people_for_all_users(repository: PKIRepository) -> int:
    """Backfill a Person for every login user that lacks one. Returns the count created."""
    return sum(ensure_person_for_user(repository, user) for user in repository.list_users())
