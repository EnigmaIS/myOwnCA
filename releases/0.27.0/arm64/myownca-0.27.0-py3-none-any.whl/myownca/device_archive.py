"""Transactional device retirement retaining holder and enrollment history."""

import json
from datetime import datetime, timezone

from myownca.storage.repositories import RepositoryError, _device_from_row


def archive_device(repository, device_id, *, actor_id, connection):
    c = connection
    suffix = "" if c._dialect == "sqlite" else " FOR UPDATE"
    if c._dialect == "sqlite":
        # SQLite SELECTs do not acquire a write lock in the legacy driver mode.
        c.execute("UPDATE devices SET id = id WHERE id = ? AND archived_at IS NULL", (device_id,))
    # Match ACME's account -> authorization -> device lock ordering.
    # Registration locks credentials before authorization; take these first.
    initial_enrollments = c.execute(
        "SELECT id FROM acme_server_authorizations WHERE device_id = ? ORDER BY id", (device_id,)
    ).fetchall()
    credentials = []
    for enrollment in initial_enrollments:
        # Lock the authorization's entire credential range, including insertion gaps.
        # A new registration must not acquire a credential while we hold its authorization.
        credentials.extend(
            row["id"]
            for row in c.execute(
                "SELECT id FROM acme_server_credentials WHERE authorization_id = ? ORDER BY id"
                + suffix,
                (enrollment["id"],),
            ).fetchall()
        )
    accounts = c.execute(
        "SELECT a.id FROM acme_server_accounts a JOIN acme_server_authorizations e "
        "ON e.id = a.authorization_id WHERE e.device_id = ? ORDER BY a.id",
        (device_id,),
    ).fetchall()
    for account in accounts:
        c.execute(
            "UPDATE acme_server_accounts SET generation = generation + 1 WHERE id = ?",
            (account["id"],),
        )
    enrollments = c.execute(
        "SELECT id FROM acme_server_authorizations WHERE device_id = ? ORDER BY id" + suffix,
        (device_id,),
    ).fetchall()
    if {row["id"] for row in initial_enrollments} != {row["id"] for row in enrollments}:
        raise RepositoryError("Device enrollment changed concurrently; retry archiving")
    device = c.execute("SELECT * FROM devices WHERE id = ?" + suffix, (device_id,)).fetchone()
    if device is None:
        raise RepositoryError("Unknown device")
    if device["archived_at"]:
        raise RepositoryError("Device is already archived")
    actor = c.execute("SELECT * FROM users WHERE id = ?" + suffix, (actor_id,)).fetchone()
    if not actor or not actor["is_active"] or actor["role"] not in {"admin", "superuser", "user"}:
        raise RepositoryError("An active authorized account is required")
    if actor["role"] == "user" and actor["person_id"] != device["admin_id"]:
        raise RepositoryError("Device is outside your scope")
    blockers = []
    for sql, reason in (
        (
            "SELECT certificate_id FROM certificate_inventory WHERE holder_device_id = ? AND archived_at IS NULL",
            "certificates must be archived",
        ),
        (
            "SELECT id FROM certificate_requests WHERE holder_device_id = ? AND status = 'pending'",
            "pending requests must be resolved",
        ),
    ):
        if c.execute(sql + suffix, (device_id,)).fetchone():
            blockers.append(reason)
    for row in c.execute(
        "SELECT record FROM batch_records WHERE state NOT IN ('completed', 'canceled')" + suffix
    ).fetchall():
        holder = json.loads(row["record"])["holder"]
        if holder["unique_id"] == device_id and "admin_id" in holder:
            blockers.append("unfinished batch work must be completed or canceled")
            break
    if blockers:
        raise RepositoryError("Cannot archive device: " + "; ".join(blockers))
    moment = datetime.now(timezone.utc).isoformat()
    for enrollment in enrollments:
        eid = enrollment["id"]
        c.execute(
            "UPDATE acme_server_authorizations SET enabled = 0, generation = generation + 1 WHERE id = ?",
            (eid,),
        )
        c.execute(
            "UPDATE acme_server_credentials SET enabled = 0 WHERE authorization_id = ?", (eid,)
        )
    links = c.execute(
        "SELECT id FROM secure_links WHERE certificate_id IN "
        "(SELECT certificate_id FROM certificate_inventory WHERE holder_device_id = ?)",
        (device_id,),
    ).fetchall()
    for link in links:
        c.execute(
            "UPDATE secure_links SET revoked_at = ?, session_token_hash = NULL, session_expires_at = NULL, "
            "otp_hash = NULL, otp_expires_at = NULL WHERE id = ?",
            (moment, link["id"]),
        )
    c.execute("UPDATE devices SET archived_at = ? WHERE id = ?", (moment, device_id))
    return _device_from_row(
        c.execute("SELECT * FROM devices WHERE id = ?", (device_id,)).fetchone()
    ), {
        "archived_at": moment,
        "disabled_authorization_ids": [r["id"] for r in enrollments],
        "disabled_credential_ids": credentials,
        "revoked_link_ids": [r["id"] for r in links],
    }
